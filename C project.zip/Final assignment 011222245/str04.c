#include<stdio.h>
#include<string.h>
int main()
{
    char sentence[500];

    printf("Write the sentence: ");
    fgets(sentence,sizeof(sentence),stdin);
    sentence[strcspn(sentence,"\n")]='\0';

    int count=1;
    for(int i=0; sentence[i]!='\0'; i++)
    {
        if(sentence[i]==' ')
        {
            count++;
        }
    }

    printf("Total word is: %d", count);

    return 0;
}