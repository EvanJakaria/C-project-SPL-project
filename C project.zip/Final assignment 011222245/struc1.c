#include <stdio.h>
struct person
{
    char name[20];
    int age ;
    float salary;
};

int main()
{
    int i;
    struct person person[4];

    for(i=0;i<4;i++)
    {

        printf("enter information about person %d\n",i+1);
        printf("name:");
        fflush(stdin);
        gets(person[i].name);
        printf("age:");
        scanf("%d",&person[i].age);
        printf("salary:");
        scanf("%f",&person[i].salary);

    }
    for(i=0;i<4;i++)
    {

        printf("about person %d\n",i+1);
        printf("%s",person[i].name);
        printf("%d\n",person[i].age);

        printf("%f\n",person[i].salary);

    }

    getch();
}
