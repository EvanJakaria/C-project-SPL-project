#include <stdio.h>
#include<string.h>
#include<ctype.h>
int main() 
{
    char a[1000];
    char ch;
    
    printf("Write the string: ");
    fgets(a,sizeof(a),stdin);
    
    printf("Choice a character: ");
    scanf("%c", &ch);
    
    int count=0;
    int i=0;
    while(a[i]!='\0')
    {
        if(a[i] == toupper(ch) || a[i] == tolower(ch))
        {
            count++;
        }
        i++;
    }
    
    printf("%d ",count);
    return 0;
}