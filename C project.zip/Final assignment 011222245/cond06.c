#include<stdio.h>
int main()
{
    char ch;
    printf("Enter any character: ");
    scanf("%c", &ch);
    ((ch>='a' && ch<='z') || (ch>='A' && ch<='Z')) ? printf("albhabet") : printf("not albhabet");

    return 0;
}