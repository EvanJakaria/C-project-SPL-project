#include <stdio.h>
#define MAX_SIZE 100


int maxnumber(int array[], int index, int len);   //find max number
int minnumber(int array[], int index, int len);


int main()
{
    int array[MAX_SIZE], Num, max, min;
    int i;


    printf("Enter size of the array: ");
    scanf("%d", &Num);
    printf("Enter %d elements in array: ", Num);            //okay
    for(i=0; i<Num; i++)
    {
        scanf("%d", &array[i]);
    }

    max = maxnumber(array, 0, Num);
    min = minnumber(array, 0, Num);

    printf("Minimum element in array: %d\n", min);
    printf("Maximum element in array: %d\n", max);

    return 0;
}

//recursion for maximum number
int maxnumber(int array[], int index, int len)
{
    int max;
    if(index >= len-2)
    {
        if(array[index] > array[index + 1])
            return array[index];
        else
            return array[index + 1];
    }

    max = maxnumber(array, index + 1, len);

    if(array[index] > max)
        return array[index];
    else
        return max;
}

//recursion for minimum number
int minnumber(int array[], int index, int len)
{
    int min;

    if(index >= len-2)
    {
        if(array[index] < array[index + 1])
            return array[index];
        else
            return array[index + 1];
    }

    min = minnumber(array, index + 1, len);

    if(array[index] < min)
        return array[index];
    else
        return min;
}
