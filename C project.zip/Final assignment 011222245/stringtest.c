#include <stdio.h>
#include<string.h>
int main() 
{
    char x[11], y[4];
    printf("Enter the string: ");
    gets(x);
    printf("Enter 2nd string: ");
    gets(y);
    strcat(x,y);
    puts(x);
    printf("The length of the string is: %d\n", strlen(x));

    return 0;
}