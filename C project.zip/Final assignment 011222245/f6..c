#include<stdio.h>

//function prototype
int stringLength(char *);       //stringLength

int main()
{
    char text[100];
    int length;

    printf("Enter text: ");
    scanf("%[^\n]s",text);

    length = stringLength(text);

    printf("Input text is: %s\n",text);        //okay
    printf("Length is: %d\n",length);

    return 0;
}

//function declare for string length
int stringLength(char *str)
{
    int len=0;

    for(len=0; str[len]!='\0'; len++);

    return len;
}
