#include <stdio.h>
#include <string.h>
int main()
{
    char arr[50];
    // int d;
    printf("Enter 01 strings:");
    fgets(arr, sizeof(arr), stdin);
    // printf("Enter 02 strings:");
    // gets(b);

    strrev(arr);
    puts(arr);
}