#include<stdio.h>
#include<string.h>
int main()
{
    FILE *file;
    char ch[1000];

    file = fopen("test.txt","r");

    if(file==NULL)
    {
        printf("File doesn't exist.");
    }
    else
    {
        printf("File is opened:\n");

        while(!feof(file))
        {
            fgets(ch,2,file);
            printf("%s",ch);
        }
        fclose(file);
    }

    getchar();
}