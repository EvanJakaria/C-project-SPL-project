#include <stdio.h>
int main() {
    int a;
    scanf("%d",&a);
    if(a<0)
        printf("it is negative",a);
    else if (a>0)
        printf("it is positive",a);
    else if(a==0)
        printf("it is zero",a);

return 0;
}
