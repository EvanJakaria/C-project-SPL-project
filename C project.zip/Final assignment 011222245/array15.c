#include <stdio.h>
int main() 
{
    int n,n2;
    
    printf("Enter the array-A size:");
    scanf("%d",&n);
    int arr1[n];
    
    printf("Enter array-A values:");
    for(int i=0;i<n;i++){
        scanf("%d",&arr1[i]);
    }
    
    printf("\n");
    
    printf("Enter the array-B size:");
    scanf("%d",&n2);
    int arr2[n2];
    
    printf("Enter array-B values:");
    for(int j=0;j<n2;j++){
        scanf("%d",&arr2[j]);
    }
    
    for(int j=0;j<n2;j++){
        for(int i=0;i<n;i++){
            if(arr1[i]==arr2[j]){
                n++;
                arr1[n-1]=arr2[j];
            }
            else{
                n++;
                arr1[n-1]=arr2[j];
            }
            break;
        }
    }

    for(int i=0; i<n; i++){
        for(int j=i+1; j<n; j++){
            if(arr1[i]==arr1[j]){
                for(int k=j; k<n; k++){
                    arr1[k]=arr1[k+1];
                    }
                n--;
                j--;
            }
        }
    }
   
    printf("Union Array is:");
    for(int i=0; i<n; i++){
        printf("%d ",arr1[i]);
    }
    
    return 0;
}