#include<stdio.h>
#include<string.h>
int main()
{
    char sentence[500];

    printf("Write the sentence: ");
    fgets(sentence,sizeof(sentence),stdin);
    sentence[strcspn(sentence,"\n")]='\0';

    int count=0;
    for(int i=0; sentence[i]!='\0'; i++)
    {
        count++;
    }

    printf("Total character is: %d", count);

    return 0;
}