#include <stdio.h>
 
int main()
{
    int a;
    
    printf("Enter week number:");
    scanf("%d",&a); 
 
    if(a == 1){
        printf("saturday");
    }
    else if(a == 2){
        printf("sunday");
    }
    else if(a == 3){
        printf("monday");
    }
    else if(a == 4){
        printf("tuesday");
    }
    else if(a == 5){
        printf("wednesday");
    }
    else if(a == 6){
        printf("thursday ");
    }
    else if(a == 7){
        printf("friday");
    }
    else{
        printf("wrong input");
    }
 
    return 0;
}