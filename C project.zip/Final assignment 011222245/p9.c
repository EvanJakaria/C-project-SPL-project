#include <stdio.h>
#include <string.h>
void main()
{
    char a[30], b[30];
    char *found;
    printf("Enter a string:\t");
    gets(a);
    printf("Enter the string to be searched for:\t");
    gets(b);
    found = strstr(a, b);
    // printf("%ld\n", found - a);
    // printf("%ld\n", a);
    if (found)
        printf("%s is found in %s in %d position", b, a, found - a);
    else
        printf("since the string is not found");
    getchar();
}
