#include<stdio.h>
int main()
{
/*
    * * * 
     * *
      *
*/
not complete
int i,j,r;
   printf("Enter the number of rows: ");
   scanf("%d",&r);
   for(i=r; i>0; i--){

    for(j=r;j0;j--){
        printf(" ")
    }

    for(int j=i; j>0; j--){
        printf("* ");
    }
    printf("\n");
   }
   
   return 0;
}