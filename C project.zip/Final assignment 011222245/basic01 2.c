#include<stdio.h>
void abc()
{
    printf("I am in abc function\n");
    //this function don't return anything,so we wrote (void) instead of (int)
}
void jakaria()
{
    printf("I am in jakaria function");
}

int main()
{
    printf("It's main funciton\n");

    abc(); //function call
    jakaria();
    return 0;
}
