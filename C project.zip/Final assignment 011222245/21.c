#include <stdio.h>
int main()
{
    int n,i,j,inc=1;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {

            printf("%d ",inc);
            inc++;
        }
        printf("\n");
    }
    return 0;
}
