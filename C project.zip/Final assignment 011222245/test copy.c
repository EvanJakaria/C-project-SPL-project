#include <stdio.h>
int main()
{
    printf("\nhello");
    printf("\nWorld");
    printf("\nMy");
    printf("\nName");
    printf("\nIs");
    printf("\nJakaria");
    printf("\nMolla");
    printf("\n");
}