#include <stdio.h>
//function prototype
void evenodd(int num, int limit);        //print even odd

int main()
{
    int lowerLimit, upperLimit;


    printf("Enter lower limit: ");
    scanf("%d", &lowerLimit);
    printf("Enter upper limit: ");
    scanf("%d", &upperLimit);

    printf("Even/odd Numbers from %d to %d are: ", lowerLimit, upperLimit);       //okay
    evenodd(lowerLimit, upperLimit);

    return 0;
}


//recursion for even odd
void evenodd(int num, int limit)
{
    if(cur > limit)
        return;

    printf("%d, ", num);


    evenodd(num + 2, limit);
}
