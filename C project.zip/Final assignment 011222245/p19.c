#include <stdio.h>
int a = 0, b = 0, c = 0;
int f1(int p)
{
    c = p + a;
    // printf("f1:%d %d %d\n", a, p, c);

    return c;
}
int f3(int c)
{
    c = 2;
    a *= 2;
    return c * a;
}
int f2(int x, int b)
{
    x *= 2;
    a = f3(x);
    // printf("f2: %d %d \n", x, a);
    return c * a;
}
int main()
{
    a = 2121 % 47;
    printf("main:%d\n", a);
    f3(a);
    printf("%d %d %d\n", a, b, c);
    b = f1(a);
    printf("%d %d %d\n", a, b, c);
    f2(a, b);
    printf("%d %d %d\n", a, b, c);
}
