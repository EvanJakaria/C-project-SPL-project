#include<stdio.h>
int main()
{
    int note,amount,n500,n100,n50,n20,n10,n5,n2,n1;
    printf("Please enter your amount:");
    scanf("%d",&amount);

    if(amount>500){
       n500 =amount/500;
       printf("total 500 note:%d\n",n500);
       amount=amount%500;
    }

     if(amount>100){
       n100 =amount/100;
       printf("total 100 note:%d\n",n100);
       amount=amount%100;
    }

     if(amount>50){
       n50 =amount/50;
       printf("total 50 note:%d\n",n50);
       amount=amount%50;
    }

     if(amount>20){
       n20 =amount/20;
       printf("total 20 note:%d\n",n20);
       amount=amount%20;
    }

     if(amount>10){
       n10 =amount/10;
       printf("total 10 note:%d\n",n10);
       amount=amount%10;
    }

     if(amount>5){
       n5 =amount/5;
       printf("total 5 note:%d\n",n5);
       amount=amount%5;
    }

     if(amount>2){
       n2 =amount/2;
       printf("total 2 note:%d\n",n2);
       amount=amount%2;
    }

    if(amount>=1){
       n1 =amount/1;
       printf("total 1 note:%d\n",n1);
       amount=amount%1;
    }

    return 0;
}