#include <stdio.h>
int main() {
    int x,y,z;
    printf("enter the number:"); //largest number between three number
    scanf("%d",&x);
     printf("enter the number:");
    scanf("%d",&y);
     printf("enter the number:");
    scanf("%d",&z);
    if(x>y&&x>z){
        printf("largest number=%d",x);
    }
    else if(y>x&&y>z){
        printf("largest number=%d",y);
    }
        else {
            printf("largest number=%d",z);
        }


  return 0;
}
