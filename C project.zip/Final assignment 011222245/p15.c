#include <stdio.h>
void a(int *tarr, int n)
{
    // int tarr[5];
    printf("Enter the array elements:");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &tarr[i]);
    }
}
int main()
{

    int arr[5];
    a(arr, 5);

    printf("Array: \n");
    for (int i = 0; i < 5; i++)
    {
        printf("%d ", arr[i]);
    }
}