#include<stdio.h>
int main()
{
    int a, b, c;
    printf("Enter three number: ");
    scanf("%d", &a);
    scanf("%d" );
    scanf("%d", &c);
    printf("First value=%d last value=%d", a, c);
    return 0;
}
