#include<stdio.h>
int main()
{
    float a,b;
    int n;
    
    printf("Enter two real numbers: ");
    scanf("%f %f", &a, &b);

    printf("Enter 1 for Sumation\n");
    printf("Enter 2 for Subtraction\n");
    printf("Enter 3 for Multiplication\n");
    printf("Enter 4 for Divition\n");
    scanf("%d", &n);

    if(n==1)
    {
        printf("Sumation is: %.2f", a+b);
    }
    else if(n==2)
    {
        printf("Subtraction is: %.2f", a-b);
    }
    else if(n==3)
    {
        printf("Multiplication is: %.2f", a*b);
    }
    else if(n==4)
    {
        printf("Enter 1 for Quotient\n");
        printf("Enter 2 for Reminder\n");
        scanf("%d", &n);

        if(n==1)
        {
            printf("Quotient is: %.2f", a/b);
        }
        else if(n==2)
        {
            printf("Reminder is: %d", (int)a % (int)b);
        }
    }

    return 0;
}