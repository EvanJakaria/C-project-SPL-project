#include <stdio.h>
#include <string.h>
int main()
{
    char a[100] = {"JAKARIA"};
    char b[100] = {"jakaria"};

    if (strcmp(a, b) > 0)
    {
        printf("a is big");
    }
    else if (strcmp(a, b) < 0)
    {
        printf("a is small");
    }
}