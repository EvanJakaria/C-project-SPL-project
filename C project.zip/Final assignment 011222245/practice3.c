#include <stdio.h>
int main() {





int c,d,rem;
	float a,b;
	scanf("%f %f %d", &a, &b, &c);
	if(c==1)
		printf("Addition: %f", a+b);
	else if(c==2)
		printf("Substraction: %f", a-b);
	else if(c==3)
		printf("Multiplication: %.0f", a*b);
	else if(c==4)
	{
		printf("1.Quotient 2.Remainder : ");
		scanf("%d",&d);
		if(d==1)
			printf("Quotient: %f", a/b);
		else if(d==2)
			rem= (int)a % (int)b;
			printf("Remainder: %d",rem);
	}

    return 0;
}
