#include <stdio.h>
int main()
{
  float a,b,pi=3.1416;
  printf("Enter the radius:");
  scanf("%f",&a);
  b=pi*a*a;
  printf("area is:%f",b);
  return 0;
}