#include<stdio.h>
int main()
{
    int n,temp,sum=0;
    printf("Input the number:");
    scanf("%d",&n);
    while(n!=0){
        temp=n%10;
        sum=sum+temp;
        n=n/10;
    }

    printf("sum is:%d",sum);
    return 0;
}