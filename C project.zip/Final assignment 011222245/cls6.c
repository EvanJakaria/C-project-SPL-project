#include <stdio.h>

int main()
{

    int size;    //, max = -9999, maxIndex, min = 9999, minIndex;
    scanf("%d", &size);

    int array[size];
    int max = array[0] , maxIndex = 0, min = array[0], minIndex = 0;
    for (int i = 1; i < size; i++)
    {
        scanf("%d", &array[i]);
        if (array[i] > max)
        {
            max = array[i];
            maxIndex = i;
        }
        if (array[i] < min)
        {
            min = array[i];
            minIndex = i;
        }
    }

    // printf("Sum : %d", sum);

    printf("Max: %d, Index: %d\nMin: %d, Index: %d", max,maxIndex,min,minIndex);

    // printf("Given Array :");
    // for (int i = size-1; i >= 0; i--)
    // {
    //     printf(" %d ", array[i]);
    // }

    return 0;
}
