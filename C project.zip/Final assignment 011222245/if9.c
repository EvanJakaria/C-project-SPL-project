#include<stdio.h>
#include<conio.h>

int main()
{
	 int n, i;
	 float num, sum = 0, avg;

	 printf("How many numbers?\n");
	 scanf("%d",&n);
	 i=1;
	 while(i<=n)
	 {
	  printf("Enter number-%d: ",i);
	  scanf("%f", &num);
	  sum = sum + num;
	  i++;
	 }
	 avg = sum/n;
	 printf("\nSum = %0.2f", sum);
	 printf("\nAverage = %0.2f", avg);
	 getch();
	 return(0);
}
