#include <stdio.h>
int main() {
    int a,i,j,k;
    printf("enter the value of size:");
    scanf("%d",&a);
    
    for(i=1;i<=a/2+1;i++){
        for(k=1;k<=a/2-i+1;k++){
            printf("  ");
           }
        for(j=1;j<=2*i-1;j++){
            printf("* ");
           }
        printf("\n");
    }

    return 0;
}