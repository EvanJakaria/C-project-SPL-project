#include <stdio.h>
int main()
{
    float cel,fahr;
    printf("please enter the Fahrenheit value:");
    scanf("%f",&fahr);
    cel=(fahr - 32) * 5 / 9;
    printf("celsius is:%f",cel);
    return 0;
}