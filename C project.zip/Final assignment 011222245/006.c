#include<stdio.h>
int main()
{
    float a,b;
    printf("please enter the feet:");
    scanf("%f",&a);
    b= a / 3.28;
    printf("meter is:%.2f",b);
    return 0;
}