#include<stdio.h>
int main()
{
    int a;
    float b;
    char c;
    a = 5;
    b = 3.141593;
    c = 'a';
    printf("The integer value: %d\n", a);
    printf("The floating point value: %f\n", b);
    printf("The character value: %c\n", c);
    return 0;
}
