#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int sum = 0;
    for (int i = 1; i <= n; i = i + 2)
    {
        if (n % 2 == 0)
        {
            printf("%d X %d", i, i + 1);
            sum += (i * (i + 1));
            if (i < n - 1)
                printf(" + ");
        }

        else
        {
            if (i != n)
            {
                printf("%d X %d", i, i + 1);
                sum += (i * (i + 1));
            }
            if (i < n)
                printf(" + ");
            if (i == n)
            {
                printf("%d", i);
                sum += i;
            }
        }
    }

    printf(" = %d", sum);

    return 0;
}
