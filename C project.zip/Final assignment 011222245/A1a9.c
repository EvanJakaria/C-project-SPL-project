#include <stdio.h>
#include<math.h>
int main()
{
    int num, p = 1, a, d, fac;
    float sum = 0;
    printf("Enter a number: ");
    scanf("%d", &num);
    for(int i = 0; i <= 4; i++)
    {
        fac = 1;
        for(int j = p; j >= 1; j--)
        {
            fac *= j;
        }
        a = pow(num,p);
        if(i % 2 == 0)
            sum += (float)a / fac;
        else
            sum -= (float)a / fac;
        p += 2;
    }
    printf("sum = %0.3f", sum);
    return 0;
}