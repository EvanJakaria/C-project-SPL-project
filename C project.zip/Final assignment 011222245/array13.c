#include<stdio.h>
int main()
{
    int size;
    printf("Enter the size:");
    scanf("%d",&size);
    int array[size],i,j,k;

    for(i=0; i<size; i++){
        scanf("%d",&array[i]);
    }
    
    for(i=0; i<size; i++){
        for(j=i+1; j<size; j++){
            if(array[i]==array[j]){
                for(k=j; k<size; k++){
                    array[k]=array[k+1];
                    }
                size--;
                j--;
            }
            
            
        }
        
    }
    for(i=0; i<size; i++){
        printf("%d",array[i]);
    }

    return 0;
}