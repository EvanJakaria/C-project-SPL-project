#include <stdio.h>
int main() {
    int x;
    printf("enter the number:"); //check the number is even or odd
    scanf("%d",&x);
    if(x%2==0)
        printf("the number is even");
    else
        printf("the number is odd");


  return 0;
}
