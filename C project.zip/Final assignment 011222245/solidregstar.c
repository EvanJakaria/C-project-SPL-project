#include<stdio.h>
int main()
{
/*
    * * * 
    * * * 
    * * * 
*/
    int i,j;
    int m,n;
    printf("Enter row and colum size:");
    scanf("%d %d",&m,&n);
    
    for(i=1;i<=m;i++){
        for(j=1;j<=n;j++){
            printf("* ");
        }
        printf("\n");
    }

    return 0;
}