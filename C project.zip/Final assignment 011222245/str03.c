#include<stdio.h>
#include<string.h>
int main()
{
    char sentence[500];

    printf("Write the sentence: ");
    fgets(sentence,sizeof(sentence),stdin);
    sentence[strcspn(sentence,"\n")]='\0';

    int count=0;
    for(int i=0; sentence[i]!='\0'; i++)
    {
        if(sentence[i]=='a' || sentence[i]=='e' || sentence[i]=='i' || sentence[i]=='o' || sentence[i]=='u' || sentence[i]=='A' || sentence[i]=='E' || sentence[i]=='I' || sentence[i]=='O' || sentence[i]=='U')
        {
            count++;
        }
    }

    printf("Total vowel is: %d", count);

    return 0;
}