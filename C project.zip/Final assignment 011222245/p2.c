#include<stdio.h>
#include<string.h>

struct Student
{
    char name[100];
    int id;
    float cg;
    //char t[100];
};

int main()
{
    int n,temp=0,temp2=0;
    printf("Enter the Student amount: ");
    scanf("%d",&n);
    struct Student ch[n];
    char t[n];

    for(int i=0; i<n; i++)
    {
        printf("Write the Name: ");
        fflush(stdin);
        fgets(ch[i].name,sizeof(ch[i].name),stdin);
        ch[i].name[strcspn(ch[i].name,"\n")]='\0';

        t[i]=strlen(ch[i].name);

        printf("Write the Id: ");
        scanf("%d",&ch[i].id);

        printf("Write the CGP: ");
        scanf("%f",&ch[i].cg);

        printf("\n");
        //ch[i]=v;
    }


    for(int j=0; j<n; j++)
    {
        if(temp<t[j])
        {
            temp=t[j];
        }

        if(temp>t[j])
        {
            temp2=t[j];
        }
    }


    for(int i=0; i<n; i++)
    {
        if(strlen(ch[i].name) == temp2)
        {
            printf("\nShotest Info: ");

            printf("\nName: ");
            puts(ch[i].name);
            printf("Id:%d",ch[i].id);
            printf("\nCgp:%.02f",ch[i].cg);
            printf("\n");
        }
    }


    for(int i=0; i<n; i++)
    {
        if(strlen(ch[i].name) == temp)
        {
            printf("\nLongest Info: ");

            printf("\nName: ");
            puts(ch[i].name);
            printf("Id:%d",ch[i].id);
            printf("\nCgp:%.02f",ch[i].cg);
            printf("\n");
        }
    }
}
