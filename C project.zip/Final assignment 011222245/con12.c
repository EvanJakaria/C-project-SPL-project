#include <stdio.h>
int main() {
    int x,y;
    scanf("%d%d",&x,&y);
    if(x==y)
        printf("they are equal");
    else
        printf("they are not equal");

  return 0;

}
