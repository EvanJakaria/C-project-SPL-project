#include<stdio.h>
int main()
{
    int n, num, sum=0, evenSum=0;
    int count=0, fDigit,lDigit, position, temp;

    printf("Enter the number:");
    scanf("%d",&num);
    n = num; //store the value of num to n;

    while(n!=0){
        temp=n%10; //modulus of n;

        if(n==num){
            fDigit=temp;
        }

        count++;
        n=n/10;

        if(n==0){
            lDigit=temp;
        }
    }

    position = count;
    n = num;
    while(n!=0){
        temp=n%10;
        sum= sum + temp; //sum of all digits

        if(position % 2 == 0) //when position is even (means temp work in once then its not work) means temp works even time then its work.
        { 
            evenSum= evenSum + temp;
        }
        position--; //increment of the position value
        n=n/10;
    }
    //# venus number:
    //# Sum of the Digts is divisible by 5
    //# Sum of the Even positioned Digits is divisible by 3
   // # Sum of the Last and First Digit < 11

    if (sum % 5 == 0 && evenSum % 3 == 0 && fDigit+lDigit<11)
    {
        printf("Venus Number");
    }
    else
    {
        printf("Not Venus Number");
    }

    return 0;
}