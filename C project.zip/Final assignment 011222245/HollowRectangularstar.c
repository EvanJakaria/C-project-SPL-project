#include<stdio.h>
int main()
{
/*
    * * * 
    *   * 
    * * * 
*/
    int i,j;
    int m,n;
    printf("Enter row and colum size:");
    scanf("%d %d",&m,&n);
    
    for(i=1;i<=m;i++){
        for(j=1;j<=n;j++){

            if(i==1 || i==m || j==1 || j==n){
                printf("* ");
            }
            else
            printf("  ");
        }
        printf("\n");
    }

    return 0;
}