#include<stdio.h>
int main()
{
   int n,id;
   printf("enter the number:");
   scanf("%d",&n);
   while(n>0){
       id=n%10;
       printf("%d",id);
       n=n/10;
   }
   return 0;
}