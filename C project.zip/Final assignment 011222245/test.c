#include <stdio.h>
int main() {
    
    int n;
    scanf("%d",&n);
    
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(j==n/2+1 || i==n/2+1 || (j<=n/2 && i==1) || (i>n/2+1 && j==1) || (j>n/2+1 && i==n) || (i<n/2+1 && j==n)){
                printf("* ");
            }
            
            else{
                printf("  ");
            }
        }

        printf("\n");
    }

    return 0;
}