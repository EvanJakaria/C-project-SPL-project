#include<stdio.h>
int main()
{
    int n,i,mul=1;

    printf("Enter your number:");
    scanf("%d",&n);
    while(n!=0){
        i=n%10;
        mul*=i;
        n/=10;
    }
    printf("product is:%d",mul);

    return 0;
}