#include<stdio.h>

int main(){
    char category;
    int workExperinece;
    int familyMember;
    float familyIncome;

    scanf("%c %d %d %f", &category, &workExperinece, &familyMember, &familyIncome);

    if((workExperinece>=12 && familyMember>5)|| familyIncome<1000.50){
        printf("Will receive the Bonus");
    }
    else{
        if((category == 'Y' || category == 'Z') && familyMember>8 && familyIncome<1100.78 ){
            printf("Will receive the Bonus");
        }
        else if (category == 'X' && familyMember>5){
            printf("Will receive the Bonus");
        }
        else{
            printf("Will not receive the Bonus");
        }
    }

    return 0;
}
