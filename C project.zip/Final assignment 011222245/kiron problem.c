#include<stdio.h>
int main()
{
    int n, sum = 0, i;
    printf("Enter the terms number of the series: ");
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
    {
        sum += 3 * i;
    }
    printf("Result: %d", sum);
    return 0;
}
