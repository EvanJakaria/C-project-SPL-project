#include<stdio.h>
int main()
{
    /* \" use for "
    \\ use for \ */
    printf("The question is - \"How to write a\n\\comment/ in C programming language?\"");
    return 0;
}
