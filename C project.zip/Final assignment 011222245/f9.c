#include <stdio.h>
#include <math.h>

//function prototype
double Diameter(double radius);
double Circumference(double radius);           //diameter, circumference and area of circle
double Area(double radius);


int main()
{
    float radius, diameter, circle, area;


    printf("Enter radius of circle: ");
    scanf("%f", &radius);

    diameter  = Diameter(radius);
    circle = Circumference(radius);
    area = Area(radius);

    printf("Diameter of the circle = %.2f units\n", diameter);                //okay
    printf("Circumference of the circle = %.2f units\n", circle);
    printf("Area of the circle = %.2f sq. units", area);

    return 0;
}


//function for diameter
double Diameter(double radius)
{
    return (2 * radius);
}

//function for circumference
double Circumference(double radius)
{
    return (2 * M_PI * radius);
}

//function for area

double Area(double radius)
{
    return (M_PI * radius * radius);
}
