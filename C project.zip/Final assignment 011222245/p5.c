#include <stdio.h>
#include <string.h>
int main()
{
    char arr[10];
    // int i;
    //  for (i = 0; i < 10; i++)
    //  {
    //      scanf("%c", &arr);
    //  }
    //  //scanf("%s", &arr[10]);

    // arr[i] = '\0';

    gets(arr);

    for (int i = 0; i < 10; i++)
    {
        printf("%c", arr[i]);
    }
    printf("\nfor new line\n");
    int j = 0;
    while (arr[j] != '\0')
    {
        printf("%c", arr[j]);
        j++;
    }

    printf("\nfor new line\n");
    printf("%s", arr);

    printf("\nfor new line\n");
    puts(arr);

    return 0;
}