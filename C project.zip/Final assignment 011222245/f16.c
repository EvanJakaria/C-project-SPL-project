#include <stdio.h>
//function prototype
int gcd(int x, int y);


int main()
{
    int num1, num2, hcf;                   //HCF


    printf("Enter any 2 numbers to find HCF or GCD: ");
    scanf("%d%d", &num1, &num2);

    hcf = gcd(num1, num2);

    printf("GCD of %d and %d = %d", num1, num2, hcf);        //okay

    return 0;
}
//recursion for HCF
int gcd(int x, int y)
{
    if(y == 0)
        return x;
    else
        return gcd(y, x%y);
}
