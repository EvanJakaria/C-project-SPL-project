#include<stdio.h>
int main()
{
    int age;
    printf("Enter the age:");
    scanf("%d",&age);
    if(age > 18){
        printf("Congraculation! you are eligible for vote");
    }
    else{
        printf("Sorry! you are not eligible for vote");
    }

    return 0;
}