#include<stdio.h>
int main()
{
    int a;
    float b;
    char c, ch;
    printf("Enter an integer value: ");
    scanf("%d", &a);
    printf("Enter a floating point value: ");
    scanf("%f", &b);
    printf("Enter a character value: ");
    scanf("%c", &c);
    c = getchar();
    printf("%d %f %c\n", a, b, c);
    return 0;
}
