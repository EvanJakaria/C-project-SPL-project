#include<stdio.h>
int main()
{

    int n,i,temp;
    printf("enter the number:");
    scanf("%d",&n);
   
    temp=n%10;
    printf("last digit is:%d\n",temp);

    while(n!=0){
        temp=n%10;
        n=n/10;
    }
    printf("first digit is:%d",temp);


    return 0;
}