#include <stdio.h>
int main() {
/*
    5 5 5 5 5 
    4 4 4 4 
    3 3 3 
    2 2 
    1 
*/
    int i,j,k;
    int m;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=m;i>0;i--){
        for(j=i;j>0;j--){
            printf("%d ",i);
        }
        printf("\n");
    }

    return 0;
}