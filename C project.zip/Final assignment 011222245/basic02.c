#include<stdio.h>
void abc();  //function declaration
void jakaria();

int main()  //main function
{
    printf("It's main funciton\n");

    abc();   //function call
    jakaria();
    return 0;
}

void abc()   //function defination
{
    printf("I am in abc function\n");
}

void jakaria()
{
    printf("I am in jakaria function");
}
