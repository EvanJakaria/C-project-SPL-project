#include <stdio.h>

//function prototype
int lcm(int x, int y);


int main()
{
    int num1, num2, LCM;           //LCM


    printf("Enter any 2 numbers to find LCM: ");      //okay
    scanf("%d%d", &num1, &num2);

    if(num1 > num2)
        LCM = lcm(num2, num1);
    else
        LCM = lcm(num1, num2);

    printf("LCM of %d and %d = %d", num1, num2, LCM);

    return 0;
}

//recursion for LCM
int lcm(int x, int y)
{
    static int mul = 0;

    mul += y;

    if((mul % x == 0) && (mul % y == 0))
    {
        return mul;
    }
    else
    {
        return lcm(x, y);
    }
}
