#include<stdio.h>
#include<string.h>
int main()
{
    int a=0,n=0,c=0,b;
    char ch[100];
    char ch2[100];

    printf("Write the 1st string: ");
    fgets(ch,sizeof(ch),stdin);
    ch[strcspn(ch,"\n")]='\0';

    printf("Write the 2nd string: ");
    fgets(ch2,sizeof(ch2),stdin);
    ch2[strcspn(ch2,"\n")]='\0';

    a = strlen(ch);
    b = 10-a;

    if(a<10)
    {
        for(int i=0; i<b; i++)
        {
            ch[a]=ch2[i];
            a++;
            c=1;
        }

    }
    else
        {
            puts(ch);
        }

    if(c==1)
    {
        ch[a]='\0';
        puts(ch);
    }

}
