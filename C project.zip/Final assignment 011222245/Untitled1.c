#include <stdio.h>
int main()
{
    int n=3,i,x,y;
    printf("Player-1 enter your number: ");
    scanf("%d",&x);
    printf("Player-2 enter your number: ");
    scanf("%d", &y);
    if(y!=x)
    {
        printf("Wrong, %d Chance(s) Left!",n-1);
        scanf("%d",&y);
        if(y!=x)
        {
            printf("Wrong, %d Chance(s) Left!",n-2);
            scanf("%d",&y);
            if(y!=x)
            {
                printf("Wrong, %d Chance(s) Left!\nPlayer-1 wins!",n-3);
            }
            else
            {
                printf("Right, Player-2 wins!");
            }
        }
        else
        {
            printf("Right, Player-2 wins!");
        }
    }
    else
    {
        printf("Right, Player-2 wins!");
    }
    return 0;
}
