#include <stdio.h>
int  main() {



    float c;
    float f;
    printf("take input from user");
    scanf("%f",&c,&f);
    f=9*c/5+32;
    printf("the temperature:%f",f);

    return 0;


}
