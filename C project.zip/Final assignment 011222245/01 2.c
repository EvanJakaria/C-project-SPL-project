#include<stdio.h>
int main()
{
    int a,i,n,sum=0;
    float avg;

    printf("enter a number:");
    scanf("%d",&a);

    for(i=0;i<a;i++){
        scanf("%d",&n);
        sum=sum+n;
    }

    printf("sum is %d\n",sum);
    printf("avg is %f",avg=(float)sum/a);

    return 0;
}