#include <stdio.h>
#include <string.h>
int main()
{
    char str1[50] = {'\0'}, str2[50] = "BEST", str3[50];
    strcpy(str1, "HELLO tkFELLAS");
    // gets(str3);
    int i = strlen(str1) * 0.5;
    // int j = strlen(str3);
    // printf("%d", i);

    for (int k = 0; str2[k] != '\0'; k++)
    {
        if (k == 0)
            printf("s:%d\n", i + k);

        str1[i + k] = str2[k];
    }

    puts(str1);
}