
#include <stdio.h>
int main() {
    int a,b,sum,sub,mult,mod;
    float div;

    printf("Enter first number:");
    scanf("%d",&a);
    printf("Enter second number: ");
    scanf("%d",&b);

    sum=a+b;
    sub=a-b;
    mult=a*b;
    mod=a%b;
    div=(float)a/b;
    printf("sum:%d\n",sum);
    printf("subtraction:%d\n",sub);
    printf("multiplication:%d\n",mult);
    printf("modulus:%d\n",mod);
    printf("division:%f",div);

    return 0;


}
