#include<stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for(i = 1; i <= n; i++)
    {
        if(i == 1||i == n)
            for(j = n; j >= 1; j--)
                printf("Z");
        else
        {
            for(j = n; j > i; j--)
                printf(" ");
            printf("Z");
        }
        printf("\n");
    }
    return 0;
}
