#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter three differnet numbers:");
    scanf("%d %d %d",&a,&b,&c);
    
    if(a<b){
        if(a<c){
            printf("%d is min1 number from three numbers",a);
        }
        else{
            printf("%d is min2 number from three numbers",c);
        }
        }

    else{
        if(b<c){
            printf("%d is min3 number from three numbers",b);
        }
        else{
            printf("%d is min4 number from three numbers",c);
        }
    }

  return 0;
}