#include<stdio.h>
#include<math.h>
int main()
{
    int n, x, y, first, last, count, num = 0, i;
    printf("Enter a number: ");
    scanf("%d", &n);
    x = n;
    y = n;
    count = 0;
    while(x != 0)
    {
        if(count == 0)
            first = x % 10;
        count++;
        last = x % 10;
        x /= 10;
    }
    for(i = 0; y != 0; i++)
    {
        if(i == 0)
        {
            num += last * pow(10, i);
        }
        else if(i == count - 1)
        {
            num += first * pow(10, i);
        }
        else
        {
            num += (y % 10) * pow(10, i);
        }
        y /= 10;
        //printf("when i = %d, number is: %d\n", i, num);
    }
    printf("After swap the number is: %d\n", num);
    return 0;
}
    
    
