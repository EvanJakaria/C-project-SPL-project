#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>

void Login();
void Registration();
void Loginupdate();
void insert();
void edit();
void delete();
void view();

struct LorR
{
    char fname[1000];
    char lname[1000];
    char username[100];
    char password[9];
    char date[12];
};
struct LorR x;

struct babyinfo
{
    char serialNumber[1000];
    char babyName[1000];
    char dateofBirth[1000];
    char fatherName[1000];
};
struct babyinfo y;

//main function
int main()
{
    int option;
    printf("\t\t\t\t\tBirth Data Collection Program");

    printf("\n\nADMIN PANEL\nMENU:");
    printf("\n01: If you are already a member of this athutrity, please click '1' for LOGIN.");
    printf("\n02: If you are not a member of this athutrity, please click '2' for REGISTRATION.");
    printf("\n\nChoice your option: ");
    scanf("%d",&option);

    if(option==1)
    {
        Login();
    }
    else if(option==2)
    {
        Registration();
    }
    else
    {
        int n;
        printf("Sorry! your option is not valid");
        printf("\nClick '1' for RESTART\nClick '0' for EXIT\n");
        scanf("%d",&n);
        if(n==1)
        {
            main();
        }
        else if(n==0) 
        {
            printf("Program Exit");
            return 0;
        }
        
    }

    //getchar();
}

//for login
void Login()
{
    FILE *login;
    login=fopen("in.txt","rb");

    char username[100];
    char password[9];

    fflush(stdin);
    printf("Username: ");
    fgets(username,sizeof(username),stdin);
    username[strcspn(username,"\n")]='\0';

    printf("Password: ");
    fgets(password,sizeof(password),stdin);
    password[strcspn(password,"\n")]='\0';

    while(!feof(login))
    {
        fscanf(login,"%s",x.fname);
        fscanf(login,"%s",x.lname);
        fscanf(login,"%s",x.username);
        fscanf(login,"%s",x.password);
        fscanf(login,"%s",x.date);
       
        if(strcmp(username,x.username)==0 && strcmp(password,x.password)==0)
        {
            FILE *loginupdate;
            loginupdate=fopen("loginupdate.txt","a");
            fprintf(loginupdate,"Name: %s %s\nUser Name: %s\nLast Login Date:%s\n",x.fname,x.lname,x.username,x.date);
            
            printf("\nLoged in: %s %s\nLogin date: %s",x.fname,x.lname,x.date);

            int option2;
            printf("\n\nMENU:");
            printf("\nPress '0' for View Login Details.");
            printf("\nPress '1' for Insert new data.");
            printf("\nPress '2' for Edit data.");
            printf("\nPress '3' for Delete data.");
            printf("\nPress '4' for View data.");
            printf("\nPress '5' for again go to Admin Panel.");
            printf("\n\nOption: ");
            scanf("%d",&option2);

            if(option2==0)
            {
                Loginupdate();
            }
            else if(option2==1)
            {
                insert();
            }
            else if(option2==2)
            {
                edit();
            }
            else if(option2==3)
            {
                delete();
            }
            else if(option2==4)
            {
                view();
            }
            else
            {
                printf("Sorry! your option is not valid.");
            }

        }
    }
    int option3;
    printf("WORNG! username or password");
    printf("\nPress '1' to login again");
    printf("\nPress '2' for registration\n");
    scanf("%d",&option3);

    if(option3==1)
    {
        Login();
    }
    else if(option3==2)
    {
        Registration();
    }
}

//for Registration
void Registration()
{
    char myDate[12];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon+1, tm.tm_year + 1900);
    strcpy(x.date, myDate);

    FILE *login;
    login = fopen("in.txt","a");

    if(login==NULL)
    {
        printf("File doesn't exist.");
    }
    else
    {
        printf("Login file is open.");
        printf("\n\nFirst Name: ");
        fflush(stdin);
        fgets(x.fname,sizeof(x.fname),stdin);
        x.fname[strcspn(x.fname,"\n")]='\0';

        printf("Last Name: ");
        fgets(x.lname,sizeof(x.lname),stdin);
        x.lname[strcspn(x.lname,"\n")]='\0';

        printf("User Name: ");
        fgets(x.username,sizeof(x.username),stdin);
        x.username[strcspn(x.username,"\n")]='\0';

        printf("Password (Less than 9 digit): ");
        fgets(x.password,sizeof(x.fname),stdin);
        x.password[strcspn(x.password,"\n")]='\0';

        //fprintf(login,"%s\n%s\n%s\n%s\n%s\n",x.fname,x.lname,x.username,x.password,x.date);
        //fprintf(login,"Nmae: %s %s \nUsername: %s \nPassword: %s", x.fname, x.lname, x.username, x.password);
        fclose(login);
        printf("Congratulations!\nYour registration is complete.\n");
        printf("Press 'Enter Key' for go to login");
        getchar();
        system("cls");
        Login();
    }

}

//logininfo
void Loginupdate()
{
    printf("loginupdate");
}

//insert
void insert()
{
    printf("insert");
}

//edit
void edit()
{
    printf("edit");
}

//delete
void delete()
{
    printf("delete");
}

//view
void view()
{
    printf("view");
}