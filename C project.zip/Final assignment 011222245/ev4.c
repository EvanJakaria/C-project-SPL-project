#include <stdio.h>

int count = 0;
int find_binary(int num)
{
	if ( num%2 == 1 ) {
		count++;
	}
	if (num == 0) {
		return 0;
	}
	return (num%2) + 10 * find_binary(num/2);
}

int main()
{
	int num;
	scanf("%d", &num);
	int binary = find_binary(num);
	printf("%d ", binary);
	if (count%2==0) {
		printf("YES\n");
	}
	else {
		printf("NO\n");
	}

	return 0;
}
