#include<stdio.h>
int main()
{

    int n,temp1,temp2;
    printf("enter the number:");
    scanf("%d",&n);
   
        temp1=n%10;

    while(n!=0){
        temp2=n%10;
        n=n/10;
    }
    printf("sumation of 1st and last digit is:%d + %d = %d",temp2,temp1,temp1+temp2);


    return 0;
}