#include<stdio.h>
#include<string.h>
int main()
{
    char m[10],n[10];
    fgets(m,sizeof(m),stdin);
    m[strcspn(m,"\n")]='\0';
    fgets(n,sizeof(n),stdin);
    n[strcspn(n,"\n")]='\0';

    int i=0;
    while(m[i]!='\0'){
        i++;
    }
    m[i]=' ';
    i++;

    int j=0;
    while(n[j]!='\0'){
        
        m[i+j]=n[j];
        j++;
    }

    m[i+j]='\0';
    
    puts(m);


}