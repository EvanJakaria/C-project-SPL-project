#include <stdio.h>
#include<string.h>
int main() 
{
    char a[1000];
    char b[1000];

    printf("Write the string: ");
    fgets(a,sizeof(a),stdin);
    
    int p=0;
    int i;
    
    for( i=0; i<=127; i++)
    {
        int j=0;
        while(a[j]!='\0')
        {
            if(i==a[j])
            {
                b[p]=a[j];
                p++;
            }
            j++;
        }
        b[j]='\0';
    }
    
    puts(b);
    return 0;
}