#include <stdio.h>
int main() {
    //display a string character wise
    char str[]="Afrina";
    int i=0;
    while(str[i]!='\0')
    {
        printf("%c\n",str[i]);
        i++;
    }

     return 0;


}

