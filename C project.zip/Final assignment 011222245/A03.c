#include<stdio.h>
int main()
{
   int a,i,n=1;
   printf("Enter a number:");
   scanf("%d",&a);
   for(i=1;i<=a;i++){
       if(n%2==0){
           n=n*0;
       }
       printf("%d",n);
       n++;
       if(i<a){
        printf(",");
       }
   }
     return 0;
}
