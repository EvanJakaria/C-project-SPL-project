#include<stdio.h>
#include<string.h>
int main()
{
    char sentence1[500];
    char sentence2[500];

    printf("Write the 1st sentence: ");
    fgets(sentence1, sizeof(sentence1), stdin);
    sentence1[strcspn(sentence1,"\n")]='\0';

    printf("Write the 2nd sentence: ");
    fgets(sentence2, sizeof(sentence2), stdin);
    sentence2[strcspn(sentence2,"\n")]='\0';

    int i,count=0;
    for(i=0; sentence1[i]!='\0'; i++)
    {
        count++;
    }

    sentence1[i]=' ';
    count++;

    for(int j=0; sentence1[j]!='\0'; j++)
    {
        sentence1[count+j] = sentence2[j];
    }

    puts(sentence1);
}