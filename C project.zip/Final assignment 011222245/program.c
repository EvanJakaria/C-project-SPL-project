#include <stdio.h>
int main()
{
    FILE *file;
    FILE *tfile;
    FILE *cfile;
    file = fopen("text.txt", "r");

    int i, count = 0, sum = 0, arr[100];

    if (file == NULL)
    {
        printf("File doesn't exist");
    }
    else
    {
        while (!feof(file))
        {
            fscanf(file, "%d", &i);
            arr[count] = i;
            count++;
        }
    }
    fclose(file);

    int max = -9999;
    int min = 9999;

    for (int i = 0; i < count; i++)
    {
        sum += arr[i];

        if (max < arr[i])
        {
            max = arr[i];
        }
        if (min > arr[i])
        {
            min = arr[i];
        }
    }
    tfile = fopen("text2.txt", "w");
    fprintf(tfile, "%d\n%d\n%d", max, min, sum);
    fclose(tfile);

    int j;
    file = fopen("text.txt", "r");
    cfile = fopen("text3.txt", "w");
    while (!feof(file))
    {
        fscanf(file, "%d", &j);
        fprintf(cfile, "%d\n", j);
    }

    fclose(file);
    fclose(cfile);

    return 0;
}