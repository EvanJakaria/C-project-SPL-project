#include<stdio.h>
#include<ctype.h>
int main()
{
    char category;
    int workEx;
    int familyMember;
    float familyIncome;

    printf("Category:");
    scanf("%c",&category);
    printf("Work experience:");
    scanf("%d",&workEx);
    printf("Family member:");
    scanf("%d",&familyMember);
    printf("Family income");
    scanf("%f",&familyIncome);


    int bonusStatus=0;

    category= toupper(category);

    if(category!='X' && category!='Y' && category!='Z'){
        printf("Invalid character. Please enter X/Y/Z:");
        scanf("%c",&category);
        category= toupper(category);
    }



    if((workEx>=12 && familyMember>5)|| familyIncome){
        bonusStatus=1;
    }
    else{
        if(category=='X' && familyMember>5){
            bonusStatus=1;
        }
        else{
            if(familyMember>8 && familyIncome<1100.78){
                bonusStatus=1;
            }
        }
    }




    if(bonusStatus==1){
        printf("get the bonus");
    }
    else{
        printf("will not get the bonus");
    }

 return 0;

}