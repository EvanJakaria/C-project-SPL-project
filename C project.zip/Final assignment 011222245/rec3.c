/**
 * C program to find factorial of any number using recursion
 */

#include <stdio.h>

/* Function declaration */
int fact(int num);


int main()
{
    int num;
    int factorial;

    /* Input an integer from user */
    printf("Enter any number: ");
    scanf("%d", &num);

    factorial = fact(num); // Call factorial function

    printf("Factorial of %d is %d", num, factorial);

    return 0;
}


/**
 * Function to compute and return factorial of any number recursively.
 */
int fact(int num)
{
    // Base condition
    if(num == 0)
        return 1;
    else
        return num * fact(num - 1);
}
