#include <stdio.h>
#define MAX_SIZE 100

//function prototype
int arrsum(int arr[], int start, int len);    //sum of array


int main()
{
    int arr[MAX_SIZE];
    int num, i, sum;



    printf("Enter size of the array: ");
    scanf("%d", &num);
    printf("Enter elements in the array: ");      //okay
    for(i=0; i<num; i++)
    {
        scanf("%d", &arr[i]);
    }


    sum= arrsum(arr, 0, num);
    printf("Sum of array elements: %d", sum);

    return 0;
}

 //recursion for sum of array
int arrsum(int arr[], int start, int len)
{

    if(start >= len)
        return 0;

    return (arr[start] + arrsum(arr, start + 1, len));
}
