#include<stdio.h>
int main()
{
    int x, y, i, r = 1;
    printf("Enter x, y value: ");
    scanf("%d%d", &x, &y);
    for(i = 1; i <= y; i++)
    {
        r *= x;
    }
    printf("%d", r);
    return 0;
}