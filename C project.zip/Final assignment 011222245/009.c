#include <stdio.h>
int main()
{
    char ch;
    short sh;
    int a;
    long b;
    float c;
    double d;

    printf("Size of char: %ld byte\n",sizeof(ch));
    printf("Size of Short: %ld bytes\n",sizeof(sh));
    printf("Size of int: %ld bytes\n",sizeof(a));
    printf("Size of long: %ld bytes\n",sizeof(b));
    printf("Size of float: %ld bytes\n",sizeof(c));
    printf("Size of double: %ld bytes\n",sizeof(d));
    return 0;
}