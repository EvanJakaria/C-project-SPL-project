#include <stdio.h>
int main()
{
    int b = 9; // 1519 % 11;
    int a[5] = {7, 9, 40, 13, 14};
    int *p1, t, u, v, w;

    p1 = a;
    t = (*p1)++;
    u = *p1;
    v = *++p1;
    w = *(++p1);
    printf(" %d\n", *p1);

    printf(" %d %d %d %d", t, u, v, w);
}