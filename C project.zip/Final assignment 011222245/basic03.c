//sum function
#include<stdio.h>

void sum();
int sum2();

int main()
{
    sum(1,2);

    int num1,num2,mainSum;
    printf("Enter the 1st number: ");
    scanf("%d",&num1);
    printf("Enter the 2nd number: ");
    scanf("%d",&num2);
    mainSum = sum2(num1,num2);
    printf("Sum2 is: %d",mainSum);
}

void sum(int a, int b)
{
    printf("Sum is: %d\n",a+b);
}

int sum2(int x, int y)
{
    int sum = x+y;
    return sum;
}