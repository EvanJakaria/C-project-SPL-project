#include <stdio.h>

int main() 
{
    int i,j,k;
    int m,temp=1;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=1;i<=m;i++){
        for(j=1;j<=i;j++){
            printf("%d ",temp);
            temp++;
        }
        printf("\n");
    }

    return 0;
}