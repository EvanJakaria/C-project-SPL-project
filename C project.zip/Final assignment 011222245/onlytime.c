#include <stdio.h>
// #include <conio.h>
#include <time.h>
int main()
{
    time_t t;
    t = time(NULL);
    struct tm tm;
    tm = *localtime(&t);
    printf("Current Time: %d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);
    getchar();
    return 0;
}
