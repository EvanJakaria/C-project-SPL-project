#include <stdio.h>
#include<string.h>
int main() 
{
    char a[1000];
    
    printf("Write the string: ");
    fgets(a,sizeof(a),stdin);
    
    int temp=strlen(a);
    int flag=0;
    int i=0;
    while(i<temp/2)
    {
        if(a[i]==a[temp-2-i])
        {
            flag=0;
        }
        else
        {
            flag=1;
            break;
        }
        i++;
    }
    
    if(flag==0)
    {
        printf("yes");
    }
    else
    {
        printf("no");
    }
    
    return 0;
}