#include<stdio.h>
int main()
{
    int n;
    printf("Enter the size:");
    scanf("%d",&n);
    int m=n/2+1;
    for (int i = 1; i <= m; i++)
    {
        for (int j=1; j<=m-i; j++)
        {
            printf("_");
        }
        for (int k=1; k<=2*i-1; k++)
        {
            printf("*");
        }
        printf("\n");
    }

    for (int i=m-1; i>=1; i--)
    {
        for(int j=1; j<=m-i;j++){
            printf("_");
        }

        for (int k=1; k<=2*i-1; k++)
        {
            printf("*");
        }
        printf("\n");
    }
    return 0;
}