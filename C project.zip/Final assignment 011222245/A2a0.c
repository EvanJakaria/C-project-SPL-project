#include<stdio.h>
int main()
{
int i, j=0, n, sum=0;
scanf("%d", &n);
for(i=1; i<=n; i++)
{
    j=j*10+i;
    sum=sum+j;
}
printf("%d", sum);

return 0;
}