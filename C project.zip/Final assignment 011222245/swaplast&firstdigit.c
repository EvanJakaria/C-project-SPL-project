#include<stdio.h>
int main()
{
    int num,i,count=0;
    printf("Enter the number:");
    scanf("%d",&num);
    for(int temp=0;num>0;num=num/10){
        temp=num%10;
        count++;
    }

    printf("%d\n",count);
    
}