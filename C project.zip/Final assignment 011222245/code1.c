
#include <stdio.h>
int main() {
    int counter,sum=0,n;
    scanf("%d",&n);
    for(counter=1;counter<=n;counter=counter+1)
    {
        if(counter%2==0)
            sum=sum+counter;
    }
    printf("the sum=%d\n",sum);


    return 0;
}

