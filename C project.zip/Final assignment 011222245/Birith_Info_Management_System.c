#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int temp();
int *arr();
void Login();
void Registration();
void LoginInfo();
void dataCollection();
void insert();
void edit();
void delete();
void view();
void sort();

struct LorR
{
    int age;
    char fname[1000];
    char lname[1000];
    char username[100];
    char password[9];
    char date[12];
};
struct LorR x;

struct babyinfo
{
    int idNumber;
    char babyName[1000];
    char dateofBirth[1000];
    char fatherName[1000];
    char date[12];
};
struct babyinfo y;

struct TIME
{
    char date[12];
    char clockT[12];
};
struct TIME D;

// main function
int main()
{
    int option;
    while (1)
    {
        system("clear");
        printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");

        printf("\nADMIN PANEL\nMENU:");
        printf("\n01: click '1' for Login.");
        printf("\n02: click '2' for Registration.");
        printf("\n03: Click '0' for Exit.");
        printf("\n[N.B.: Option must be a Digit or Number. Otherwise the system will not work properly.]");

        printf("\n\nChoice your option: ");
        scanf("%d", &option);

        switch (option)
        {
        case 0:
            system("clear");
            exit(0);

        case 1:
            system("clear");
            Login();
            break;

        case 2:
            system("clear");
            Registration();
            break;

        default:
            printf("\nSorry! your option is not valid");
        }
        printf("\n\nClick 'Enter Key' for System Restart...");
        fflush(stdin);
        getchar();
    }

    printf("System Close");
    return 0;
}

// for login
void Login()
{
    char myDate[12];
    char clock[12];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
    sprintf(clock, "%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);
    strcpy(D.date, myDate);
    strcpy(D.clockT, clock);

    FILE *login;
    login = fopen("registration.txt", "r"); // registration.txt open
    printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");

    char username[100];
    char password[9];

    fflush(stdin);
    printf("\n\n\nUsername: ");
    fgets(username, sizeof(username), stdin);
    username[strcspn(username, "\n")] = '\0';

    printf("\n\nPassword: ");
    fgets(password, sizeof(password), stdin);
    password[strcspn(password, "\n")] = '\0';

    while (!feof(login))
    {
        fread(&x, sizeof(x), 1, login);

        if (strcmp(username, x.username) == 0 && strcmp(password, x.password) == 0)
        {
            FILE *loginupdate;

            loginupdate = fopen("logininfo.txt", "a"); // logininfo.txt open

            fwrite(&x, sizeof(x), 1, loginupdate);
            fwrite(&D, sizeof(D), 1, loginupdate);
            fclose(loginupdate); // logininfo.txt close

            system("clear");

            fclose(login); // registration.txt close

            int option4;

            while (1)
            {
                login = fopen("registration.txt", "r");
                printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");
                printf("\nLoged in: %s %s\nLogin date: %s\n", x.fname, x.lname, myDate);
                fclose(login);

                printf("\n\nMENU:");
                printf("\n01: Click '1' for View Login Details.");
                printf("\n02: Click '2' for Baby Data Management.");
                printf("\n03: Click '0' for Exit.");
                printf("\n[N.B.: Option must be a Digit or Number. Otherwise the system will not work properly.]");
                printf("\n\nOption: ");
                scanf("%d", &option4);

                switch (option4)
                {
                case 0:
                    system("clear");
                    exit(0);

                case 1:
                    system("clear");
                    LoginInfo();
                    break;

                case 2:
                    system("clear");
                    dataCollection();
                    break;

                default:
                    printf("Sorry! your option is not valid");
                    printf("\nClick 'Enter Key' for Try Again...");
                    fflush(stdin);
                    getchar();
                    system("clear");
                }
            }
        }
    }
    printf("\nWORNG! Username or Password");
    printf("\nClick 'Enter Key' for Try Again...");
    fflush(stdin);
    getchar();
    system("clear");

    main();
}

// for Registration
void Registration()
{
    char myDate[12];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
    strcpy(x.date, myDate);

    FILE *login;
    login = fopen("registration.txt", "a");

    if (login == NULL)
    {
        printf("File doesn't exist.");
    }
    else
    {
        printf("Login file is open.");
        printf("\n\nFirst Name: ");
        fflush(stdin);
        fgets(x.fname, sizeof(x.fname), stdin);
        x.fname[strcspn(x.fname, "\n")] = '\0';

        printf("Last Name: ");
        fflush(stdin);
        fgets(x.lname, sizeof(x.lname), stdin);
        x.lname[strcspn(x.lname, "\n")] = '\0';

        while (1)
        {
            printf("Age: ");
            scanf("%d", &x.age);

            if (x.age >= 18)
            {
                break;
            }
            else
            {
                printf("\n!!!\nMinimum age should be 18.\n\n");
                continue;
            }
        }

        printf("User Name: ");
        fflush(stdin);
        fgets(x.username, sizeof(x.username), stdin);
        x.username[strcspn(x.username, "\n")] = '\0';

        printf("Password (Less than 9 digit): ");
        fflush(stdin);
        fgets(x.password, sizeof(x.fname), stdin);
        x.password[strcspn(x.password, "\n")] = '\0';

        // fprintf(login,"%s \n%s\n%s\n%s\n%s\n",x.fname,x.lname,x.username,x.password,x.date);
        fwrite(&x, sizeof(x), 1, login);

        fclose(login);
        printf("Congratulations!\nYour registration is complete.\n");
        printf("Press 'Enter Key' for Restart.");
        getchar();
        system("clear");
        main();
    }
}

// logininfo
void LoginInfo()
{
    FILE *lp;

    printf("\n%-10s %-20s %-10s %-30s %-15s %s\n\n", "Full", "Name", "Age", "User Name", "Date", "Time");
    lp = fopen("logininfo.txt", "r");

    // while (!feof(lp))
    while (fread(&x, sizeof(x), 1, lp) == 1)
    {

        // fscanf(lp, "%s%s%d%s%s", x.fname, x.lname, x.age, x.username, D.date);
        // strcat(x.fname ,x.lname);
        // 1
        // fread(&x, sizeof(x), 1, lp);
        fread(&D, sizeof(D), 1, lp);
        printf("%-10s %-20s %-10d %-30s %-15s %s\n", x.fname, x.lname, x.age, x.username, D.date, D.clockT);
    }

    fclose(lp);
    printf("\n\nPress 'Enter Key' for go to Previous Panel.");
    fflush(stdin);
    getchar();
    system("clear");
}

// data collection
void dataCollection()
{
    int option2;
    while (1)
    {
        char myDate[12];
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);

        FILE *login;
        login = fopen("registration.txt", "r");
        printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");
        printf("\nLoged in: %s %s\nLogin date: %s\n", x.fname, x.lname, myDate);
        fclose(login);

        printf("\n\nMENU:");
        printf("\n01: Press '1' for Insert new data.");
        printf("\n02: Press '2' for Edit data.");
        printf("\n03: Press '3' for Delete data.");
        printf("\n04: Press '4' for View data.");
        printf("\n05: Press '5' for again go to Admin Panel.");
        printf("\n06: Click '0' for Exit.");
        printf("\n[N.B.: Option must be a Digit or Number. Otherwise the system will not work properly.]");
        printf("\n\nOption: ");
        scanf("%d", &option2);

        switch (option2)
        {
        case 0:
            system("clear");
            exit(0);

        case 1:
            system("clear");
            insert();
            break;

        case 2:
            system("clear");
            edit();
            break;

        case 3:
            system("clear");
            delete ();
            break;

        case 4:
            system("clear");
            view();
            break;

        case 5:
            system("clear");
            main();
            break;

        default:
            printf("\nSorry! your option is not valid");
            printf("\nPress 'Enter Key' For Previous Menu.");
            fflush(stdin);
            getchar();
            system("clear");
        }
    }
}

// insert
void insert()
{
    int *a, b;
    a = arr();

    b = temp();
    char myDate[12];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);
    strcpy(y.date, myDate);

    FILE *bi;

    bi = fopen("babyinfo.txt", "a");

    if (bi == NULL)
    {
        printf("File doesn't exist.");
    }
    else
    {
        printf("Baby Information File is Open.");

        while (1)
        {

            int f = 0;

            printf("\n\nID Number: ");
            scanf("%d", &y.idNumber);
            for (int i = 0; i <= b; i++)
            {
                if (y.idNumber == a[i])
                {
                    f = 1;
                }
            }

            if (f == 0)
            {
                break;
            }
            else
            {
                printf("\nAlready Stored ID.\n\nPlesae Write Another ID Number.");
            }
        }

        printf("\n\nName: ");
        fflush(stdin);
        fgets(y.babyName, sizeof(y.babyName), stdin);
        y.babyName[strcspn(y.babyName, "\n")] = '\0';

        printf("\n\nDate of Birth: ");
        fflush(stdin);
        fgets(y.dateofBirth, sizeof(y.dateofBirth), stdin);
        y.dateofBirth[strcspn(y.dateofBirth, "\n")] = '\0';

        printf("\n\nFathers Name: ");
        fflush(stdin);
        fgets(y.fatherName, sizeof(y.fatherName), stdin);
        y.fatherName[strcspn(y.fatherName, "\n")] = '\0';

        fwrite(&y, sizeof(y), 1, bi);

        fclose(bi);
        printf("\n\nInformation insert is completed.");
        printf("\nInformation Insert Date: %s", y.date);
        printf("\nPress 'Enter Key' For Previous Menu.");
        fflush(stdin);
        getchar();
        system("clear");
    }
}

// insert array
int *arr()
{
    FILE *c;

    static int count[0];
    c = fopen("babyinfo.txt", "r");
    int size = 0;
    while (fread(&y, sizeof(y), 1, c) == 1)
    {
        count[size] = y.idNumber;
        size++;
    }
    fclose(c);
    // for (int i = 0; i < size; i++)
    // {
    //     printf("Array is:%d ", count[i]);
    // }

    return count;
}

// insert temp
int temp()
{
    FILE *c;
    int temp = 0;
    c = fopen("babyinfo.txt", "r");
    while (fread(&y, sizeof(y), 1, c) == 1)
    {
        if (temp < y.idNumber)
        {
            temp = y.idNumber;
        }
    }
    fclose(c);
    return temp;
}

// edit
void edit()
{
    int option;
    FILE *Edit;

    while (1)
    {
        int flag = 0;
        int ID;
        char ch[1000];
        char myDate[12];
        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);

        FILE *login;
        login = fopen("registration.txt", "r");
        printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");
        printf("\nLoged in: %s %s\nLogin date: %s\n", x.fname, x.lname, myDate);
        fclose(login);

        fflush(stdin);
        printf("\n\nWrite The ID Number: ");
        scanf("%d", &ID);

        printf("\nWrite The Name: ");
        fflush(stdin);
        fgets(ch, sizeof(ch), stdin);
        ch[strcspn(ch, "\n")] = '\0';

        Edit = fopen("babyinfo.txt", "r+"); // Opens the file for reading/writing/modification

        while (!feof(Edit))
        {
            int s = 0;
            fread(&y, sizeof(y), 1, Edit);
            if (ID == y.idNumber && strcmp(ch, y.babyName) == 0)
            {
                flag = 1;
                printf("\nMENU: ");
                printf("\n\n01: Click '1' for Edit Name.");
                printf("\n02: Click '2' for Edit Date of Birth.");
                printf("\n03: Click '3' for Edit Fathers Name.");
                printf("\n04: Click '4' for Edit All Details.");
                printf("\n05: Click '0' for Exit.");
                printf("\n[N.B.: Can't Change ID Number]");
                printf("\n\nOption: ");
                scanf("%d", &option);

                switch (option)
                {
                case 0:
                    system("clear");
                    exit(0);

                case 1:
                    printf("\nName: ");
                    fflush(stdin);
                    fgets(y.babyName, sizeof(y.babyName), stdin);
                    y.babyName[strcspn(y.babyName, "\n")] = '\0';
                    s = 1;
                    break;

                case 2:
                    printf("\nDate of Birth: ");
                    fflush(stdin);
                    fgets(y.dateofBirth, sizeof(y.dateofBirth), stdin);
                    y.dateofBirth[strcspn(y.dateofBirth, "\n")] = '\0';
                    s = 1;
                    break;

                case 3:
                    printf("\nFathers Name: ");
                    fflush(stdin);
                    fgets(y.fatherName, sizeof(y.fatherName), stdin);
                    y.fatherName[strcspn(y.fatherName, "\n")] = '\0';
                    s = 1;
                    break;

                case 4:
                    printf("\nName: ");
                    fflush(stdin);
                    fgets(y.babyName, sizeof(y.babyName), stdin);
                    y.babyName[strcspn(y.babyName, "\n")] = '\0';
                    printf("\nDate of Birth: ");
                    fflush(stdin);
                    fgets(y.dateofBirth, sizeof(y.dateofBirth), stdin);
                    y.dateofBirth[strcspn(y.dateofBirth, "\n")] = '\0';
                    printf("\nFathers Name: ");
                    fflush(stdin);
                    fgets(y.fatherName, sizeof(y.fatherName), stdin);
                    y.fatherName[strcspn(y.fatherName, "\n")] = '\0';
                    s = 1;
                    break;

                default:
                    printf("\nSorry! your option is not valid\nTry Again...\n");
                    break;
                }

                fseek(Edit, -sizeof(y), 1);
                fwrite(&y, sizeof(y), 1, Edit);
            }
            if (s == 1)
            {
                printf("\n\nData Update Successful.");
                break;
            }
        }

        if (flag == 0)
        {
            char n;
            printf("\n\nWRONG! ID Number or Name.");
            printf("\n\nClick 'Enter Key' for Try Again...");
            printf("\n\nClick '0' For Previous Menu.");
            scanf("%c", &n);
            if (n == '0')
            {
                system("clear");
                break;
            }

            fflush(stdin);
            system("clear");
        }

        else if (flag == 1)
        {
            printf("\nClick 'Enter Key' For Previous Menu.");
            fclose(Edit);
            fflush(stdin);
            getchar();
            system("clear");
            break;
        }
    }
}

// delete
void delete()
{
    char myDate[12];
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(myDate, "%02d/%02d/%d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900);

    FILE *login;
    login = fopen("registration.txt", "r");
    printf("\n%75s", "<<===**( BIRTH DATA MANAGEMENT SYSTEM )**===>>\n\n");
    printf("\nLoged in: %s %s\nLogin date: %s\n", x.fname, x.lname, myDate);
    fclose(login);

    int idNum, n = 0;

    printf("\n\n\nWrite ID Number To Delete Informatio: ");
    scanf("%d", &idNum);

    FILE *p;
    FILE *q;

    p = fopen("babyinfo.txt", "r");
    q = fopen("temp.txt", "w");

    while (fread(&y, sizeof(y), 1, p) == 1)
    {
        if (idNum == y.idNumber)
        {
            n = 1;
        }
        else
        {
            fwrite(&y, sizeof(y), 1, q);
        }
    }

    if (n == 1)
    {
        printf("\n\nInformation Deleted Successfully.\n");
    }
    else
    {
        printf("\n\nRecord Not Found !\n");
    }

    fclose(p);
    fclose(q);

    remove("babyinfo.txt");
    rename("temp.txt", "babyinfo.txt");

    printf("\nPress 'Enter Key' For Previous Menu.");
    fflush(stdin);
    getchar();
    system("clear");
}

// view
void view()
{

    FILE *bv;

    printf("\n%-20s %-40s %-30s %-30s %s\n\n", "ID Number", "Name", "Dathe of Birth", "Father Name", "Date");

    bv = fopen("babyinfo.txt", "r");
    while (fread(&y, sizeof(y), 1, bv) == 1)
    {
        printf("%-20d %-40s %-30s %-30s %s\n", y.idNumber, y.babyName, y.dateofBirth, y.fatherName, y.date);
    }

    fclose(bv);
    printf("\nPress 'Enter Key' For Sorting File.");
    fflush(stdin);
    getchar();
    system("clear");
    sort();
}

// sorting
void sort()
{
    int count = 0;
    FILE *mainFile;
    FILE *sortFile;

    sortFile = fopen("sort.txt", "w");
    mainFile = fopen("babyinfo.txt", "r");

    while (fread(&y, sizeof(y), 1, mainFile) == 1)
    {
        if (count < y.idNumber)
        {
            count = y.idNumber;
        }
    }
    fclose(mainFile);

    for (int i = 0; i <= count; i++)
    {
        mainFile = fopen("babyinfo.txt", "r");
        while (fread(&y, sizeof(y), 1, mainFile) == 1)
        {
            if (i == y.idNumber)
            {
                fwrite(&y, sizeof(y), 1, sortFile);
                fclose(mainFile);
                break;
            }
        }
    }
    fclose(mainFile);
    fclose(sortFile);
    sortFile = fopen("sort.txt", "r");

    printf("\nSorted By ID Number: \n\n");
    printf("\n%-20s %-40s %-30s %-30s %s\n\n", "ID Number", "Name", "Dathe of Birth", "Father Name", "Insert Date");

    while (fread(&y, sizeof(y), 1, sortFile) == 1)
    {
        printf("%-20d %-40s %-30s %-30s %s\n", y.idNumber, y.babyName, y.dateofBirth, y.fatherName, y.date);
    }

    fclose(sortFile);
    printf("\nPress 'Enter Key' For Previous Menu.");
    fflush(stdin);
    getchar();
    system("clear");
}