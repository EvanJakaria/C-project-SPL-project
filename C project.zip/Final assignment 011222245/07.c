#include <stdio.h>
int main() {
    int i,j,k;
    int m;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=m;i>0;i--){
        for(j=i;j>0;j--){
            printf("* ");
        }
        printf("\n");
    }

    return 0;
}