#include <stdio.h>
#include <string.h>
int main()
{
    char arr[5][10] = {"world", "hello", "jakaria", "molla", "Earth"};
    // puts(arr);

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            printf("%c", arr[i][j]);
        }
        printf("\n");
    }
    return 0;
}