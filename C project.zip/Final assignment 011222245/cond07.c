#include <stdio.h>
int main()
{
     int num;
     
    printf("Enter any number: ");
    scanf("%d", &num);
    
    if(num > 0){
        printf("%d number is positive",num);
    }

    else if(num < 0){
        printf("%d number is nagative",num);
    }

    else{
        printf("%d number is zero!",num);
    } 
    
    return 0;    
}
