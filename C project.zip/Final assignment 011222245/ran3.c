#include <stdio.h>
#include <string.h>
int main()
{
    char string[100];
    int c = 0, count[26] = {0};
    printf("Enter a string:\t");
    gets(string);
    while ( string[c] != '\0' )
    {
        if ( string[c] >= 'a' && string[c] <= 'z' )
            count[string[c]-'a']++;
        else if(string[c] >= 'A' && string[c] <= 'Z' )
            count[string[c]-'A']++;
        else
            printf("ERROR!!\n");
        c++;
    }
    for ( c = 0 ; c < 26 ; c++ )
    {
        if( count[c] != 0 )
            printf("%c : %d\n",c+'a',count[c]);
    }
    return 0;
}
