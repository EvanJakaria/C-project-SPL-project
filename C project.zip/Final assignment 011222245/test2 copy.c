#include <stdio.h>
#include <stdlib.h>

void n();

int main()
{
    printf("hello");
    getchar();
    system("clear");
    printf("World");
    n();
    printf("i am in main");
    getchar();
}
void n()
{
    printf("I am in n function\n");
    getchar();
}