#include <stdio.h>

void func(int x);
void func2(int x);
void func3(int x);

int main()
{
    printf("main1\n");
    func(3);
    printf("main2\n");
    return 0;
}

// x. 1st=3
//  2nd=2
//  3rd=2

void func(int x) // 1
{
    printf("1st\n");
    if (x == 1)
    {
        printf("2nd\n");

        return;
        printf("3rd\n");
    }

    else
    {
        printf("5th\n");

        printf("s %d\n", x); ///////////

        printf("6th\n");

        func2(x - 1); ///////////

        printf("7th\n");

        printf("m %d\n", x); ///////////

        printf("8th\n");
    }
}

void func2(int x)
{
    printf("F2 1st\n");
    if (x == 1)
    {
        printf("F2 2nd\n");

        return;
        printf("F2 3rd\n");
    }

    else
    {
        printf("F2 4th\n");

        printf("F2 s %d\n", x); ///////////

        printf("F2 5th\n");

        func3(x - 1); // 2

        printf("F2 6th\n");

        printf("F2 m %d\n", x); ///////////

        printf("F2 7th\n");
    }
}

void func3(int x)
{
    printf("F3 1st\n");
    if (x == 1)
    {
        printf("F3 2nd\n");

        return;
        printf("F3 3rd\n");
    }

    else
    {
        printf("F3 4th\n");

        printf("F3 s %d\n", x); ///////////

        printf("F3 5th\n");

        // func(x - 1); // 2

        printf("F3 6th\n");

        printf("F3 m %d\n", x); ///////////

        printf("F3 7th\n");
    }
}