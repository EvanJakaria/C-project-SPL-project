#include <stdio.h>

int main() {
   int i, j,k, rows, c=0;

   printf("Enter rows: ");
   scanf("%d", &rows);

   for(i=1; i<=rows; i++)
   {
   	for(j=1;j<=i;j++) { printf("%d",j); } for(k=i-1;k>=1;k--)
	{
		printf("%d",k);
	}
	printf("\n");
   }
   return(0);
}
