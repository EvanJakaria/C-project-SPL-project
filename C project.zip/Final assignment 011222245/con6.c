#include <stdio.h>
int main() {
    char c;
    scanf("%c",&c);
    if(c>='A'&&c<='Z'||c>='a'&&c<='z')
        printf("it is a alphabet");
    else
        printf("it is not a alphabet");

  return 0;

}
