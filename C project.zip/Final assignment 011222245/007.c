#include<stdio.h>
int main()
{
    float cel,fahr;
    printf("please enter the celsisus value:");
    scanf("%f",&cel);
    fahr= (1.8 * cel)+32;
    printf("fahrenheit is:%f",fahr);
    return 0;
}