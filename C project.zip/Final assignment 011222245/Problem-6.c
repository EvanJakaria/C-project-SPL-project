#include<stdio.h>
int main()
{
    int age;
    printf("Enter your age in year(s): ");
    scanf("%d", &age);
    printf("My age is: %d", age);
    return 0;
}
