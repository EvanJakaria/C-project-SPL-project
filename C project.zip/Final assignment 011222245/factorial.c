#include<stdio.h>
int main()
{
    int range1,range2;
    scanf("%d %d",&range1,&range2);
    for(int k=range1;k<=range2;k++)
    {
        int n=k;

   
    
    printf("%d!=",n);
     int fact=1;
    for(int i=n;i>=1;i--)
    {
        fact=fact*i;
        printf("%d",i);
        if(i>1)
        {
            printf("X");
        }

    }
    printf("=%d",fact);
    printf("\n");
    }
    return 0;
}