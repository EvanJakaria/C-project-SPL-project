#include<stdio.h>
#include<string.h>
int main()
{
    char m[10];
    fgets(m,sizeof(m),stdin);
    m[strcspn(m,"\n")]='\0';


    int i=0,s=0;
    while(m[i]!='\0'){

        if(m[i]==' ')
            s++;
        i++;
    }
    s=s+1;
    printf("%d",s);


}