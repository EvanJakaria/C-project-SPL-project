#include <stdio.h>
int main()
{
    int a,b,c,big;
    printf("Enter three numbers:");
    scanf("%d %d %d",&a,&b,&c);
    big= a>b? (a>b? a:b) : (b>c? b:c);
    
    printf("%d is the largest number",big);
    return 0;
}