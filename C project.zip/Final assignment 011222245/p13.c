#include <stdio.h>
int *a()
{
    static int tarr[5];
    printf("Enter the array elements:");
    for (int i = 0; i < 5; i++)
    {
        scanf("%d", &tarr[i]);
    }

    return tarr;
}
int main()
{

    int *arr;
    arr = a();
    printf("Array: \n");
    for (int i = 0; i < 5; i++)
    {
        printf("%d ", arr[i]);
    }
}