#include <stdio.h>

int findReverse(int a)
{
    printf("k\n");
    static int rev = 0;
    printf("l\n");
    if (a == 0)
    {
        return rev;
    }

    rev = (rev * 10) + (a % 10);
    rev = findReverse(a / 10);

    return rev;
}

void printReverse(int a)
{
    if (a == 0)
        return;
    printf("%d", (a % 10));
    printReverse(a / 10);
}

int main()
{

    int x;
    scanf("%d", &x);
    // printReverse(x);

    int reverseNum = findReverse(x);

    printf("%d", reverseNum);

    return 0;
}