#include <stdio.h>
int main() {
    //length of a string [strlen]
    char str[]="Riana";
    /*int len=strlen(str);
    printf("%d",len);*/


    //without using strlen
    int i=0,len=0;
    while(str[i]!='\0')
    {

        i++;
        len++;
    }
    printf("%d",len);
     return 0;


}


