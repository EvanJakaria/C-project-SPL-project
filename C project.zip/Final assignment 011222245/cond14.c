#include<stdio.h>
int main()
{
    int phy,che,math;
    printf("Input the value of Physics :");
    scanf("%d", &phy);
    printf("Input the value of Chemistry :");
    scanf("%d", &che);
    printf("Input the value of Mathematics :");
    scanf("%d", &math);
    printf("Total marks of Mathematics, Physics and Chemistry : %d\n", math + phy + che);
    printf("Total marks of Maths and  Physics : %d\n", math + phy);
    if (math>=65){
        if(phy>=55){
            if(che>=50){
                if((math+phy+che)>=180 || (math+phy)>=140)
                
                    printf("The  candidate is eligible for admission\n");
                else
                    printf("The candidate is not eligible\n");
            }
                
            else
                printf("The candidate is not eligible\n");
        }
            
        else
            printf("The candidate is not eligible\n");
    }
    else
        printf("The candidate is not eligible\n");

    return 0;
}
