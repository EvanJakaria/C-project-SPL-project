#include <stdio.h>
int main()
{
  float a,b;
  printf("Enter the side:");
  scanf("%f",&a);
  b=a*a;
  printf("area is:%.2f",b);
  return 0;
}