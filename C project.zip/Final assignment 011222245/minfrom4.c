#include<stdio.h>
int main()
{
    int a,b,c,d;
    printf("enter four differnet numbers:");
    scanf("%d %d %d %d",&a,&b,&c,&d);
    
    if(a<b){

        if(a<c){
            if(a<d){
            printf("%d is min1 number from three numbers",a);
            }
            else{
            printf("%d is min2 number from three numbers",d);
            }    
        }
        else{
            if(c<d){
            printf("%d is min3 number from three numbers",c);
            }
            else{
                printf("%d is min4 7number from three numbers",d);
            }
        }
        }
    else{

        if(b<c){
            if(b<d){
            printf("%d is min5 number from three numbers",b);
            }
            else{
                printf("%d is min6 number from three numbers",d);
            }
        }
        else{
            if(c<d){
            printf("%d is min7 number from three numbers",c);
            }
            else{
                printf("%d is min8 7number from three numbers",d);
            }
        }
    }

  return 0;
}