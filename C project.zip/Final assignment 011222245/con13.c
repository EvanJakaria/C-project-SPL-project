
#include <stdio.h>
int main()
{
    int Candiateage;
    printf("Input the age of the candidate : ");
    scanf("%d", &Candiateage);
    if (Candiateage < 18)
    {
        printf("Sorry, You are not eligible to caste your vote.\n");

    }
    else
    {
        printf("Congratulation! You are eligible for casting your vote.\n");
    }
    return 0;
}
