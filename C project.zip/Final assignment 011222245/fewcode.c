#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter N(th) terms of the series: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i != n)
            printf("%d,", i);
        else
            printf("%d", i);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j = 1;
    printf("Enter the N(th) terms of the series: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i != n)
            printf("%d,", j);
        else
            printf("%d", j);
        j += 2;
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the N(th) terms of the series: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i != n)
        {
            if (i % 2 == 1)
                printf("1,");
            else
                printf("0,");
        }
        else
        {
            if (i % 2 == 1)
                printf("1");
            else
                printf("0");
        }
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    float num, sum = 0, avg;
    printf("Enter N number value: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        scanf("%f", &num);
        sum += num;
    }
    avg = sum / n;
    printf("AVG of %d inputs: %f", n, avg);
    return 0;
}

#include <stdio.h>
int main()
{
    int x, y, i;
    printf("Enter two number: ");
    scanf("%d%d", &x, &y);
    if (x < y)
    {
        for (i = x; i <= y; i++)
        {
            if (i != y)
            {
                printf("%d,", i * i);
            }
            else
                printf("Reached!");
        }
    }
    else if (x > y)
    {
        for (i = x; i >= y; i--)
        {
            if (i != y)
                printf("%d,", i * i);
            else
                printf("Reached!");
        }
    }
    else
        printf("Reached!");
    return 0;
}

#include <stdio.h>

int main()
{
    int p1, p2, i, n;
    scanf("%d", &p1);
    scanf("%d", &n);
    int check = n;
    for (i = 1; i <= n; i++)
    {
        scanf("%d", &p2);
        check--;
        if (p2 == p1)
        {
            printf("Right,player-2 wins!\n");
            break;
        }
        else
        {
            printf("Wrong,%d chance(s) left!\n", check);
            if (check == 0)
            {
                printf("Player-1 Wins!");
                break;
            }
        }
    }
}

#include <stdio.h>

int main()
{
    char ch;
    int i = 0;
    while (scanf(" %c", &ch) == 1)
    {
        i++;
        if (ch == 'A')
            break;
        printf("Input %d: %c\n", i, ch);
    }
}

#include <stdio.h>
int main()
{
    int n, r;
    printf("Enter a number: ");
    scanf("%d", &n);
    while (n != 0)
    {
        r = n % 10;
        printf("%d", r);
        n /= 10;
    }
    return 0;
}

#include <stdio.h>
#include <conio.h>

int main()
{
    float a, b, c, d, e, sum;
    int i, n;
    printf("Enter total number of students: ");
    scanf_s("%d", &n);
    for (i = 1; i <= n; i++)
    {
        printf("Enter student-%d numbers: ", i);
        scanf_s("%f %f %f %f %f", &a, &b, &c, &d, &e);
        sum = a + b + c + (30 * d) / 50 + (40 * e) / 100;
        if (sum >= 90 && sum <= 100)
        {
            printf("Student %d: A\n", i);
        }
        else if (sum >= 86 && sum <= 89)
        {
            printf("Student %d: A-\n", i);
        }
        else if (sum >= 82 && sum <= 85)
        {
            printf("Student %d: B+\n", i);
        }
        else if (sum >= 78 && sum <= 81)
        {
            printf("Student %d: B\n", i);
        }
        else if (sum >= 74 && sum <= 77)
        {
            printf("Student %d: B-\n", i);
        }
        else if (sum >= 70 && sum <= 73)
        {
            printf("Student %d: C+\n", i);
        }
        else if (sum >= 66 && sum <= 69)
        {
            printf("Student %d: C\n", i);
        }
        else if (sum >= 62 && sum <= 65)
        {
            printf("Student %d: C-\n", i);
        }
        else if (sum >= 58 && sum <= 61)
        {
            printf("Student %d: D+\n", i);
        }
        else if (sum >= 55 && sum <= 57)
        {
            printf("Student %d: D\n", i);
        }
        else
            printf("Student %d: F\n", i);
    }
    getch();
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter the number of n(th) terms of series: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i % 2 == 1)
            sum += i;
        else
            sum -= i;
    }
    printf("Result: %d", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter the n(th) terms of the series: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        sum += i * i * (i + 1);
    }
    printf("Result: %d", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, n1 = 0, n2 = 1, n3;
    printf("Enter the n(th) terms of the series: ");
    scanf("%d", &n);
    printf("%d", n2);
    for (i = 1; i < n; i++)
    {
        n3 = n1 + n2;
        printf(",%d", n3);
        n1 = n2;
        n2 = n3;
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, f = 1;
    printf("Enter the value of N for calculate N!: ");
    scanf("%d", &n);
    printf("%d!=", n);
    for (i = n; i >= 1; i--)
    {
        if (i != 1)
            printf("%dX", i);
        else
            printf("%d", i);
        f *= i;
    }
    printf("=%d", f);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, r, n1 = 1, r1 = 1, n3, n_r = 1, result, i;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    printf("Enter the value of r: ");
    scanf("%d", &r);
    for (i = 1; i <= n; i++)
    {
        n1 *= i;
    }
    for (i = 1; i <= r; i++)
    {
        r1 *= i;
    }
    n3 = n - r;
    for (i = 1; i <= n3; i++)
    {
        n_r *= i;
    }
    result = n1 / (r1 * n_r);
    printf("%d", result);
    return 0;
}

#include <stdio.h>
int main()
{
    int x, y, i, r = 1;
    printf("Enter x, y value: ");
    scanf("%d%d", &x, &y);
    for (i = 1; i <= y; i++)
    {
        r *= x;
    }
    printf("%d", r);
    return 0;
}

#include <stdio.h>
int main()
{
    int n1, n2, n3, n4, r, LCM;
    printf("Enter two number: ");
    scanf("%d%d", &n1, &n2);
    n3 = n1;
    n4 = n2;
    while (n4 != 0)
    {
        r = n3 % n4;
        n3 = n4;
        n4 = r;
    }
    printf("GCD: %d\n", n3);
    LCM = (n1 * n2) / n3;
    printf("LCM: %d", LCM);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n == 2)
        printf("Prime");
    else if (n > 2)
    {
        for (i = 2; i < n; i++)
        {
            if (n % i == 0)
            {
                printf("Not Prime");
                return;
            }
        }
        printf("Prime");
    }
    else
        printf("Not Prime");
    return 0;
}

#include <stdio.h>
int main()
{
    int n, temp, r, sum = 0;
    printf("Enter any number: ");
    scanf("%d", &n);

    temp = n;

    while (temp != 0)
    {
        r = temp % 10;
        sum = sum * 10 + r;
        temp /= 10;
    }
    if (sum == n)
        printf("Yes");
    else
        printf("No");
    return 0;
}

int main()
{
    int num, p = 1, a, d, fac;
    float sum = 0;
    printf("Enter a number: ");
    scanf("%d", &num);
    for (int i = 0; i <= 4; i++)
    {
        fac = 1;
        for (int j = p; j >= 1; j--)
        {
            fac *= j;
        }
        a = pow(num, p);
        if (i % 2 == 0)
            sum += (float)a / fac;
        else
            sum -= (float)a / fac;
        p += 2;
    }
    printf("sum = %0.3f", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int i, j = 0, n, sum = 0;
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        j = j * 10 + i;
        sum = sum + j;
    }
    printf("%d", sum);

    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[n - i - 1]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        sum += a[i];
    }
    printf("%d", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (a[i] % 2 == 0)
            sum += a[i];
    }
    printf("%d", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    float a[n], sum = 0, avg;
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%f", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        sum += a[i];
    }
    avg = sum / n;
    printf("%0.2f", avg);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, sum = 0;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (i % 2 == 0)
            sum += a[i];
    }
    printf("%d", sum);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n], b[n], c[n];
    printf("Enter the 1st array elements\n");
    // 1st array input
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("Enter the 2nd array elements\n");
    // 2nd array input
    for (i = 0; i < n; i++)
    {
        scanf("%d", &b[i]);
    }
    // sum of 1st and 2nd array and put it in 3rd array
    for (i = 0; i < n; i++)
    {
        c[i] = a[i] + b[i];
    }
    // print 3rd array
    for (i = 0; i < n; i++)
    {
        printf("%d ", c[i]);
    }
    return 0;
}
// WAP that will take n integer numbers into an array, and then reverse all the integers within that array.Finally print them all from 0 index to last valid index.
#include <stdio.h>
int main()
{
    int n, i, temp;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n / 2; i++)
    {
        temp = a[i];
        a[i] = a[n - 1 - i];
        a[n - 1 - i] = temp;
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, temp;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    // max finding
    int max = -999;
    int l = 0;
    for (i = 0; i < n; i++)
    {
        if (a[i] > max)
        {
            temp = a[i];
            max = a[i];
            a[i] = temp;
            l = i;
        }
    }
    printf("Max: %d, index: %d\n", max, l);
    // min finding
    int min = 999;
    int m = 0;
    for (i = 0; i < n; i++)
    {
        if (a[i] < min)
        {
            temp = a[i];
            min = a[i];
            a[i] = temp;
            m = i;
        }
    }
    printf("Min: %d, index: %d\n", min, m);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, count = 0;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    char a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%c", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (a[i] == 'a' || a[i] == 'A' || a[i] == 'e' || a[i] == 'E' || a[i] == 'i' || a[i] == 'I' || a[i] == 'o' || a[i] == 'O' || a[i] == 'u' || a[i] == 'U')
            count++;
    }
    printf("%d", count);
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, num;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("FOUND at index position: ");
    for (i = 0; i < n; i++)
    {
        if (num == a[i])
        {
            printf("%d,", i);
        }
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    int a[n], b[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        b[i] = a[n - 1 - i];
    }
    printf("Array A:");
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\nArray B:");
    for (i = 0; i < n; i++)
    {
        printf("%d ", b[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, num, pos;
    printf("Enter the array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("number: ");
    scanf("%d", &num);
    printf("Position: ");
    scanf("%d", &pos);
    if (pos > n || pos < 0)
        printf("Invalid position!\n");
    else
    {
        for (i = n; i > pos; i--)
        {
            a[i] = a[i - 1];
        }
        a[pos] = num;
        n++;
        for (i = 0; i < n; i++)
        {
            printf("%d ", a[i]);
        }
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, pos;
    printf("Enter the array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("Position: ");
    scanf("%d", &pos);
    if (pos > n || pos < 0)
        printf("Deletion not possible\n");
    else
    {
        for (i = pos; i < n; i++)
        {
            a[i] = a[i + 1];
        }
        n--;
        for (i = 0; i < n; i++)
        {
            printf("%d ", a[i]);
        }
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, m, i;
    printf("Enter array A size: ");
    scanf("%d", &n);
    int a[n], temp[n];
    printf("Enter array A elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    // copy 'a' in temp
    for (i = 0; i < n; i++)
    {
        temp[i] = a[i];
    }
    printf("Enter array B size: ");
    scanf("%d", &m);
    int b[m];
    printf("Enter array B elements\n");
    for (i = 0; i < m; i++)
    {
        scanf("%d", &b[i]);
    }
    // copy 'b' in 'a'
    for (i = 0; i < m; i++)
    {
        a[i] = b[i];
    }
    // copy 'temp' in 'b'
    for (i = 0; i < n; i++)
    {
        b[i] = temp[i];
    }
    printf("Array A: ");
    for (i = 0; i < m; i++)
    {
        printf("%d ", a[i]);
    }
    printf("\nArray B: ");
    for (i = 0; i < n; i++)
    {
        printf("%d ", b[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (a[i] % 3 == 0)
            a[i] = -1;
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        if (i % 2 == 1)
            a[i] = 0;
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j, temp;
    printf("Enter array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter array elements\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for (i = 0; i < n - 1; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (a[i] > a[j])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter the array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (a[i] == a[j])
            {
                for (int k = j; k < n - 1; k++)
                {
                    a[j] = a[j + 1];
                }
                n--;
                j--;
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, m, i, j, flag = 0;
    printf("Enter 1st array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter 1st array elements\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter 2nd array size: ");
    scanf("%d", &m);
    int b[m];
    printf("Enter 2nd array elements\n");
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (a[i] == b[j])
            {
                printf("%d ", a[i]);
                flag++;
            }
        }
    }
    if (flag == 0)
        printf("Empty set\n");
    return 0;
}

#include <stdio.h>
int main()
{
    int n, m, i, j;
    printf("Enter 1st array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter 1st array elements\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter 2nd array size: ");
    scanf("%d", &m);
    int b[m];
    printf("Enter 2nd array elements\n");
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);
    for (i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (a[i] == b[j])
            {
                for (int k = j; k < m - 1; k++)
                    b[k] = b[k + 1];
                m--;
                j--;
            }
        }
    }
    for (i = 0; i < m; i++)
    {
        printf("%d ", b[i]);
    }
    return 0;
}
// WAP that will take n integers into an array A and m positive integers into array B.Now find the difference(set operation) of array A and B or (A - B).
#include <stdio.h>
int main()
{
    int n, m, i, j;
    printf("Enter 1st array size: ");
    scanf("%d", &n);
    int a[n];
    printf("Enter 1st array elements\n");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("Enter 2nd array size: ");
    scanf("%d", &m);
    int b[m];
    printf("Enter 2nd array elements\n");
    for (i = 0; i < m; i++)
        scanf("%d", &b[i]);
    for (i = 0; i < n; i++)
    {
        int flag = 0;
        for (j = 0; j < m; j++)
        {
            if (a[i] == b[j])
            {
                flag++;
            }
        }
        if (flag == 0)
            printf("%d ", a[i]);
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (int j = i; j < n + i; j++)
        {
            printf("%d", j);
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1, k = i; j <= i; j++, k++)
        {
            printf("%d", k);
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = i; j < n; j++)
        {
            printf("_");
        }
        for (int k = 1; k <= i; k++)
        {
            printf("%d", i);
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1, k = n; j <= i; j++, k--)
            printf("%d", k);
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("%d", j);
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
            printf("*");
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = n; j >= i; j--)
            printf("*");
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i % 2 == 1)
        {
            for (j = 1; j <= n; j++)
            {
                if (j % 2 == 1)
                    printf("1");
                else
                    printf("0");
            }
        }
        else
        {
            for (j = 1; j <= n; j++)
            {
                if (j % 2 == 1)
                    printf("0");
                else
                    printf("1");
            }
        }
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
#include <conio.h>
#include <windows.h>
struct Date
{
    int dd;
    int mm;
    int yy;
};
struct Date date;

struct Remainder
{
    int dd;
    int mm;
    char note[50];
};
struct Remainder R;

COORD xy = {0, 0};

void gotoxy(int x, int y)
{
    xy.X = x;
    xy.Y = y; // X and Y coordinates
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), xy);
}

// This will set the forground color for printing in a console window.
void SetColor(int ForgC)
{
    WORD wColor;
    // We will need this handle to get the current background attribute
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;

    // We use csbi for the wAttributes word.
    if (GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        // Mask out all but the background attribute, and add in the forgournd color
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}

void ClearColor()
{
    SetColor(15);
}

void ClearConsoleToColors(int ForgC, int BackC)
{
    WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);
    // Get the handle to the current output buffer...
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    // This is used to reset the carat/cursor to the top left.
    COORD coord = {0, 0};
    // A return value... indicating how many chars were written
    //    not used but we need to capture this since it will be
    //    written anyway (passing NULL causes an access violation).
    DWORD count;

    // This is a structure containing all of the console info
    //  it is used here to find the size of the console.
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    // Here we will set the current color
    SetConsoleTextAttribute(hStdOut, wColor);
    if (GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        // This fills the buffer with a given character (in this case 32=space).
        FillConsoleOutputCharacter(hStdOut, (TCHAR)32, csbi.dwSize.X * csbi.dwSize.Y, coord, &count);

        FillConsoleOutputAttribute(hStdOut, csbi.wAttributes, csbi.dwSize.X * csbi.dwSize.Y, coord, &count);
        // This will set our cursor position for the next print statement.
        SetConsoleCursorPosition(hStdOut, coord);
    }
    return;
}

void SetColorAndBackground(int ForgC, int BackC)
{
    WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);
    ;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), wColor);
    return;
}

int check_leapYear(int year)
{ // checks whether the year passed is leap year or not
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
        return 1;
    return 0;
}

void increase_month(int *mm, int *yy)
{ // increase the month by one
    ++*mm;
    if (*mm > 12)
    {
        ++*yy;
        *mm = *mm - 12;
    }
}

void decrease_month(int *mm, int *yy)
{ // decrease the month by one
    --*mm;
    if (*mm < 1)
    {
        --*yy;
        if (*yy < 1600)
        {
            printf("No record available");
            return;
        }
        *mm = *mm + 12;
    }
}

int getNumberOfDays(int month, int year)
{ // returns the number of days in given month
    switch (month)
    { // and year
    case 1:
        return (31);
    case 2:
        if (check_leapYear(year) == 1)
            return (29);
        else
            return (28);
    case 3:
        return (31);
    case 4:
        return (30);
    case 5:
        return (31);
    case 6:
        return (30);
    case 7:
        return (31);
    case 8:
        return (31);
    case 9:
        return (30);
    case 10:
        return (31);
    case 11:
        return (30);
    case 12:
        return (31);
    default:
        return (-1);
    }
}

char *getName(int day)
{ // returns the name of the day
    switch (day)
    {
    case 0:
        return ("Sunday");
    case 1:
        return ("Monday");
    case 2:
        return ("Tuesday");
    case 3:
        return ("Wednesday");
    case 4:
        return ("Thursday");
    case 5:
        return ("Friday");
    case 6:
        return ("Saturday");
    default:
        return ("Error in getName() module.Invalid argument passed");
    }
}

void print_date(int mm, int yy)
{ // prints the name of month and year
    printf("---------------------------\n");
    gotoxy(25, 6);
    switch (mm)
    {
    case 1:
        printf("January");
        break;
    case 2:
        printf("February");
        break;
    case 3:
        printf("March");
        break;
    case 4:
        printf("April");
        break;
    case 5:
        printf("May");
        break;
    case 6:
        printf("June");
        break;
    case 7:
        printf("July");
        break;
    case 8:
        printf("August");
        break;
    case 9:
        printf("September");
        break;
    case 10:
        printf("October");
        break;
    case 11:
        printf("November");
        break;
    case 12:
        printf("December");
        break;
    }
    printf(" , %d", yy);
    gotoxy(20, 7);
    printf("---------------------------");
}
int getDayNumber(int day, int mon, int year)
{ // retuns the day number
    int res = 0, t1, t2, y = year;
    year = year - 1600;
    while (year >= 100)
    {
        res = res + 5;
        year = year - 100;
    }
    res = (res % 7);
    t1 = ((year - 1) / 4);
    t2 = (year - 1) - t1;
    t1 = (t1 * 2) + t2;
    t1 = (t1 % 7);
    res = res + t1;
    res = res % 7;
    t2 = 0;
    for (t1 = 1; t1 < mon; t1++)
    {
        t2 += getNumberOfDays(t1, y);
    }
    t2 = t2 + day;
    t2 = t2 % 7;
    res = res + t2;
    res = res % 7;
    if (y > 2000)
        res = res + 1;
    res = res % 7;
    return res;
}

char *getDay(int dd, int mm, int yy)
{
    int day;
    if (!(mm >= 1 && mm <= 12))
    {
        return ("Invalid month value");
    }
    if (!(dd >= 1 && dd <= getNumberOfDays(mm, yy)))
    {
        return ("Invalid date");
    }
    if (yy >= 1600)
    {
        day = getDayNumber(dd, mm, yy);
        day = day % 7;
        return (getName(day));
    }
    else
    {
        return ("Please give year more than 1600");
    }
}

int checkNote(int dd, int mm)
{
    FILE *fp;
    fp = fopen("note.dat", "rb");
    if (fp == NULL)
    {
        printf("Error in Opening the file");
    }
    while (fread(&R, sizeof(R), 1, fp) == 1)
    {
        if (R.dd == dd && R.mm == mm)
        {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

void printMonth(int mon, int year, int x, int y)
{ // prints the month with all days
    int nod, day, cnt, d = 1, x1 = x, y1 = y, isNote = 0;
    if (!(mon >= 1 && mon <= 12))
    {
        printf("INVALID MONTH");
        getch();
        return;
    }
    if (!(year >= 1600))
    {
        printf("INVALID YEAR");
        getch();
        return;
    }
    gotoxy(20, y);
    print_date(mon, year);
    y += 3;
    gotoxy(x, y);
    printf("S   M   T   W   T   F   S   ");
    y++;
    nod = getNumberOfDays(mon, year);
    day = getDayNumber(d, mon, year);
    switch (day)
    { // locates the starting day in calender
    case 0:
        x = x;
        cnt = 1;
        break;
    case 1:
        x = x + 4;
        cnt = 2;
        break;
    case 2:
        x = x + 8;
        cnt = 3;
        break;
    case 3:
        x = x + 12;
        cnt = 4;
        break;
    case 4:
        x = x + 16;
        cnt = 5;
        break;
    case 5:
        x = x + 20;
        cnt = 6;
        break;
    case 6:
        x = x + 24;
        cnt = 7;
        break;
    default:
        printf("INVALID DATA FROM THE getOddNumber()MODULE");
        return;
    }
    gotoxy(x, y);
    if (cnt == 1)
    {
        SetColor(12);
    }
    if (checkNote(d, mon) == 1)
    {
        SetColorAndBackground(15, 12);
    }
    printf("%02d", d);
    SetColorAndBackground(15, 1);
    for (d = 2; d <= nod; d++)
    {
        if (cnt % 7 == 0)
        {
            y++;
            cnt = 0;
            x = x1 - 4;
        }
        x = x + 4;
        cnt++;
        gotoxy(x, y);
        if (cnt == 1)
        {
            SetColor(12);
        }
        else
        {
            ClearColor();
        }
        if (checkNote(d, mon) == 1)
        {
            SetColorAndBackground(15, 12);
        }
        printf("%02d", d);
        SetColorAndBackground(15, 1);
    }
    gotoxy(8, y + 2);
    SetColor(14);
    printf("Press 'n'  to Next, Press 'p' to Previous and 'q' to Quit");
    gotoxy(8, y + 3);
    printf("Red Background indicates the NOTE, Press 's' to see note: ");
    ClearColor();
}

void AddNote()
{
    FILE *fp;
    fp = fopen("note.dat", "ab+");
    system("cls");
    gotoxy(5, 7);
    printf("Enter the date(DD/MM): ");
    scanf("%d%d", &R.dd, &R.mm);
    gotoxy(5, 8);
    printf("Enter the Note(50 character max): ");
    fflush(stdin);
    scanf("%[^\n]", R.note);
    if (fwrite(&R, sizeof(R), 1, fp))
    {
        gotoxy(5, 12);
        puts("Note is saved sucessfully");
        fclose(fp);
    }
    else
    {
        gotoxy(5, 12);
        SetColor(12);
        puts("\aFail to save!!\a");
        ClearColor();
    }
    gotoxy(5, 15);
    printf("Press any key............");
    getch();
    fclose(fp);
}

void showNote(int mm)
{
    FILE *fp;
    int i = 0, isFound = 0;
    system("cls");
    fp = fopen("note.dat", "rb");
    if (fp == NULL)
    {
        printf("Error in opening the file");
    }
    while (fread(&R, sizeof(R), 1, fp) == 1)
    {
        if (R.mm == mm)
        {
            gotoxy(10, 5 + i);
            printf("Note %d Day = %d: %s", i + 1, R.dd, R.note);
            isFound = 1;
            i++;
        }
    }
    if (isFound == 0)
    {
        gotoxy(10, 5);
        printf("This Month contains no note");
    }
    gotoxy(10, 7 + i);
    printf("Press any key to back.......");
    getch();
}

int main()
{
    ClearConsoleToColors(15, 1);
    SetConsoleTitle("Calender Project - Programming-technique.blogspot.com");
    int choice;
    char ch = 'a';
    while (1)
    {
        system("cls");
        printf("1. Find Out the Day\n");
        printf("2. Print all the day of month\n");
        printf("3. Add Note\n");
        printf("4. EXIT\n");
        printf("ENTER YOUR CHOICE : ");
        scanf("%d", &choice);
        system("cls");
        switch (choice)
        {
        case 1:
            printf("Enter date (DD MM YYYY) : ");
            scanf("%d %d %d", &date.dd, &date.mm, &date.yy);
            printf("Day is : %s", getDay(date.dd, date.mm, date.yy));
            printf("\nPress any key to continue......");
            getch();
            break;
        case 2:
            printf("Enter month and year (MM YYYY) : ");
            scanf("%d %d", &date.mm, &date.yy);
            system("cls");
            while (ch != 'q')
            {
                printMonth(date.mm, date.yy, 20, 5);
                ch = getch();
                if (ch == 'n')
                {
                    increase_month(&date.mm, &date.yy);
                    system("cls");
                    printMonth(date.mm, date.yy, 20, 5);
                }
                else if (ch == 'p')
                {
                    decrease_month(&date.mm, &date.yy);
                    system("cls");
                    printMonth(date.mm, date.yy, 20, 5);
                }
                else if (ch == 's')
                {
                    showNote(date.mm);
                    system("cls");
                }
            }
            break;
        case 3:
            AddNote();
            break;
        case 4:
            exit(0);
        }
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = n; j > i; j--)
        {
            printf("_");
        }
        for (k = 1; k <= i; k++)
            printf("*");
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        for (j = n; j > i; j--)
        {
            printf("_");
        }
        if (i == 1)
        {
            for (k = 1; k <= i; k++)
                printf("*");
        }
        else
        {
            for (k = 1; k <= i + 1; k++)
                printf("*");
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
int main()
{
    int n, i, j, k, m = 1;
    printf("Enter an odd number: ");
    scanf("%d", &n);
    for (i = 1; i <= n / 2 + 1; i++)
    {
        for (j = n / 2; j >= i; j--)
            printf("_");
        for (k = 1; k <= m; k++)
        {
            printf("*");
        }
        m += 2;
        printf("\n");
    }
    int l = n - 2;
    for (i = 1; i <= n / 2; i++)
    {
        for (j = i; j >= 1; j--)
            printf("_");
        for (k = 1; k <= l; k++)
            printf("*");
        l -= 2;
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k, a;
    printf("Enter a number: ");
    scanf("%d", &n);
    if (n % 2 == 0)
        a = n + 1;
    else
        a = n;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= i; j++)
            printf("%d", j);
        for (k = 1; k <= a; k++)
            printf("_");
        if (i < n)
            for (int l = i; l >= 1; l--)
                printf("%d", l);
        else
            for (int l = i - 1; l >= 1; l--)
                printf("%d", l);
        a -= 2;
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i % 2 == 1)
            for (j = 1; j <= n; j++)
                printf("*");
        else
        {
            printf("*");
            for (k = n - 2; k >= 1; k--)
                printf("_");
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++)
    {
        if (i == 1 || i == n)
            for (j = n; j >= 1; j--)
                printf("Z");
        else
        {
            for (j = n; j > i; j--)
                printf(" ");
            printf("Z");
        }
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k, a;
    printf("Enter an odd number: ");
    scanf("%d", &n);
    a = n - 2;
    for (i = 1; i <= n / 2 + 1; i++)
    {
        for (j = i; j > 1; j--)
            printf("_");
        printf("*");
        for (k = 1; k <= a; k++)
            printf("_");
        if (i <= n / 2)
            printf("*");
        for (j = i; j > 1; j--)
            printf("_");
        a -= 2;
        printf("\n");
    }
    a = 1;
    for (i = 1; i <= n / 2; i++)
    {
        for (j = n / 2 - 1; j >= i; j--)
            printf("_");
        printf("*");
        for (k = 1; k <= a; k++)
            printf("_");
        printf("*");
        for (j = n / 2 - 1; j >= i; j--)
            printf("_");
        a += 2;
        printf("\n");
    }
    return 0;
}
#include <stdio.h>
int main()
{
    int n, i, j, k, a = 0;
    printf("Enter an odd number: ");
    scanf("%d", &n);
    for (i = 1; i <= n / 2; i++)
    {
        if (i == 1)
        {
            for (j = n / 2; j >= i; j--)
                printf("_");
            printf("$");
            for (j = n / 2; j >= i; j--)
                printf("_");
        }
        if (i > 1)
        {
            for (j = n / 2; j >= i; j--)
                printf("_");
            printf("$");
            for (k = a; k >= 1; k--)
                printf("_");
            printf("$");
            for (k = a; k >= 1; k--)
                printf("_");
            printf("$");
            for (j = n / 2; j >= i; j--)
                printf("_");
            a++;
        }
        printf("\n");
    }
    for (i = 1; i <= n; i++)
        printf("$");
    printf("\n");
    for (i = 1; i <= n / 2; i++)
    {
        if (i != n / 2)
        {
            for (j = 1; j <= i; j++)
                printf("_");
            printf("$");
            for (k = n / 2 - 2; k >= i; k--)
                printf("_");
            printf("$");
            for (k = n / 2 - 2; k >= i; k--)
                printf("_");
            printf("$");
            for (j = 1; j <= i; j++)
                printf("_");
        }
        if (i == n / 2)
        {
            for (j = 1; j <= i; j++)
                printf("_");
            printf("$");
            for (j = 1; j <= i; j++)
                printf("_");
        }
        printf("\n");
    }
    return 0;
}
// WAP that will print a pattern based on the input odd integer n.Please see the sample input output.
#include <stdio.h>
int main()
{
    int n, i, j;
    printf("Enter an odd number: ");
    scanf("%d", &n);
    for (i = 1; i <= n / 2; i++)
    {
        printf("H");
        for (j = 1; j <= (n - 1) + (n - 2); j++)
            printf(" ");
        printf("H");
        printf("\n");
    }
    for (i = 1; i <= n; i++)
        printf("H ");
    printf("\n");
    for (i = 1; i <= n / 2; i++)
    {
        printf("H");
        for (j = 1; j <= (n - 1) + (n - 2); j++)
            printf(" ");
        printf("H");
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
#include <math.h>
float CalcMean(int array[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += array[i];
    }
    return (sum / n);
}
float calc_std(int array[], int n)
{
    int sum = 0;
    float mean = CalcMean(array, n);
    for (int i = 0; i < n; i++)
    {
        sum += ((array[i] - mean) * (array[i] - mean));
    }
    return (sqrt(sum / n));
}
int main()
{
    int n, a[100], i;
    float mean, std;
    printf("Enter the array size: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    std = calc_std(a, n);
    printf("Standard deviation: %0.2f", std);
    return 0;
}

#include <stdio.h>
void printfmsg()
{
    printf("This is a function");
}
int main()
{
    printfmsg();
    return 0;
}

#include <stdio.h>
void piv(char c)
{
    printf("Value received from main: %c", c);
}
int main()
{
    char ch;
    printf("Enter a character value: ");
    scanf("%c", &ch);
    piv(ch);
    return 0;
}

#include <stdio.h>
void checkEvenOrOdd(int x)
{
    if (x % 2 == 0)
        printf("Even");
    else
        printf("Odd");
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    checkEvenOrOdd(n);
    return 0;
}

#include <stdio.h>
void checkNum(int x)
{
    if (x > 0)
        printf("Positive");
    else if (x < 0)
        printf("Negative");
    else
        printf("Zero");
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    checkNum(n);
    return 0;
}

#include <stdio.h>
void checkNum(int x, int y)
{
    if (x > y)
        printf("%d is greater than %d", x, y);
    else if (x < y)
        printf("%d is less than %d", x, y);
    else
        printf("%d is equal to %d", x, y);
}
int main()
{
    int x, y;
    printf("Enter two numbers: ");
    scanf("%d %d", &x, &y);
    checkNum(x, y);
    return 0;
}
#include <stdio.h>
int add(int x)
{
    static int add = 0;
    add += x;
    return add;
}
int main()
{
    int n, i, num, sum = 0, sumInF;
    printf("Enter how much numbers you want to sum: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        sum += num;
        sumInF = add(num);
    }
    printf("Sum in main: %d\n", sum);
    printf("Sum in Function: %d\n", sumInF);
    return 0;
}
#include <stdio.h>
int sum(int arr[], int n)
{
    int i, r = 0;
    for (i = 0; i < n; i++)
        r += arr[i];
    return r;
}
int main()
{
    int n, i, sim = 0, a[100], sif;
    printf("Enter a number: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    sif = sum(a, n);
    printf("Sum in function: %d\n", sif);
    for (i = 0; i < n; i++)
        sim += a[i];
    printf("Sum in main: %d\n", sim);
    return 0;
}

#include <stdio.h>
void reverse()
{
    int n, i, x[100];
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &x[i]);
    }
    printf("Reverse of entered array is: \n");
    for (i = n - 1; i >= 0; i--)
        printf("%d ", x[i]);
}
int main()
{
    reverse();
    return 0;
}
#include <stdio.h>
int factorial(int x)
{
    int i, fac = 1;
    for (i = x; i >= 1; i--)
    {
        fac *= i;
    }
    return fac;
}
int main()
{
    int n, fac;
    printf("Enter a number of which you want factorial: ");
    scanf("%d", &n);
    fac = factorial(n);
    printf("%d", fac);
    return 0;
}
#include <stdio.h>
int power(int x, int y)
{
    int i, cp = 1;
    for (i = 1; i <= y; i++)
    {
        cp *= x;
    }
    return cp;
}
int main()
{
    int x, y, cp;
    printf("Enter the base: ");
    scanf("%d", &x);
    printf("Enter the power: ");
    scanf("%d", &y);
    cp = power(x, y);
    printf("%d to the power %d is %d", x, y, cp);
    return 0;
}
#include <stdio.h>
#include <string.h>
int findLength(char str[])
{
    int i, count;
    i = count = 0;
    while (str[i] != '\0')
    {
        count++;
        i++;
    }
    return count;
}
int main()
{
    char str[100];
    printf("Enter a string: ");
    gets(str);
    int x = findLength(str);
    printf("%d", x);
    return 0;
}

#include <stdio.h>
void swap(int a, int b)
{
    int temp;
    temp = a;
    a = b;
    b = temp;
    printf("Value in func: %d %d", a, b);
}
int main()
{
    int x, y;
    printf("Enter two numbers: ");
    scanf("%d %d", &x, &y);
    swap(x, y);
    printf("\nValue in main: %d %d", x, y);
    return 0;
}

#include <stdio.h>
void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
    printf("Value in func: %d %d", *a, *b);
}
int main()
{
    int x, y;
    printf("Enter two numbers: ");
    scanf("%d %d", &x, &y);
    swap(&x, &y);
    printf("\nValue in main: %d %d", x, y);
    return 0;
}

// C program to print the upper triangular matrix

#include <stdio.h>

int main()
{
    int Matrix[3][3] = {
        {9, 8, 7},
        {5, 4, 6},
        {1, 2, 3}};

    int i, j;

    printf("Matrix:\n");
    for (i = 0; i < 3; ++i)
    {
        for (j = 0; j < 3; ++j)
        {
            printf("%d ", Matrix[i][j]);
        }
        printf("\n");
    }

    printf("\nUpper triangular matrix is: \n");
    for (i = 0; i < 3; i++)
    {

        for (j = 0; j < 3; j++)
        {
            if (j >= i)
                printf("%d ", Matrix[i][j]);
            else
                printf("  ");
        }
        printf("\n");
    }
    return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <windows.h>

#define Student struct Stud

void add(FILE *fp);
void modify(FILE *fp);
void display(FILE *fp);
void Indivisual(FILE *fp);
void password();
FILE *del(FILE *fp);
void printChar(char ch, int n);
void title();
FILE *tp;

void gotoxy(int x, int y)
{
    COORD CRD;
    CRD.X = x;
    CRD.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), CRD);
}

struct pass
{
    char pass[25];
} pa;

struct Stud
{
    char name[100];
    char dept[50];
    int roll;
    float sgpa[12];
    float cgpa;
};

int main()
{
    int ch, id, k, i;
    char c, add, pas[50];
    SetConsoleTitle("Student Management System | DIU");
    FILE *fp;
    Student s;
    int option;
    char another;

    if ((fp = fopen("db.txt", "rb+")) == NULL)
    {
        if ((fp = fopen("db.txt", "wb+")) == NULL)
        {
            printf("Can't create or open Database.");
            return 0;
        }
    }
    system("color 9f");
    gotoxy(42, 8);
    printf("LOGIN(If 1st login press ENTER)");
    gotoxy(42, 10);
    printf("____________________________________");
    gotoxy(42, 11);
    printf("|\tEnter password :             |");
    gotoxy(42, 12);
    printf("|__________________________________|");
    // printf("\n\t\t\t\t\t");
    gotoxy(65, 11);
    while (k < 10)
    {
        pas[k] = getch();
        char s = pas[k];
        if (s == 13)
            break;
        else
            printf("*");
        k++;
    }
    pas[k] = '\0';
    tp = fopen("F:/Password.txt", "r+");
    fgets(pa.pass, 25, tp);
    if (strcmp(pas, pa.pass) == 0)
    {
        system("cls");
        gotoxy(10, 3);
        printf("<<<< Loading Please Wait >>>>");
        for (i = 0; i < 5; i++)
        {
            printf("\t(*_*)");
            Sleep(500);
        }
        printf(" \n\n\n\n\n\t\t\t\t\t     *  *  *  *  *  *  *  *");
        printf("\n\n\t\t\t\t\t     *                    *");
        printf("\n\n\t\t\t\t\t     *       Welcome      *");
        printf("\n\n\t\t\t\t\t     *                    *");
        printf("\n\n\t\t\t\t\t     *  *  *  *  *  *  *  *");
        printf("\n\n\n\n\n\t\t\t\t\tPress any key to continue...... ");
        getch();

        title();
        printf("\n\n\t\t\t\tLab Final Spring 2017");
        printf("\n\n\t\t\t\t     The A Team");
        printf("\n\n\t\t\t  Daffodil International University\n\t\t\t");
        printChar('=', 38);
        printf("\n\n\n\t\t\t       press any key to Enter");
        getch();

        while (1)
        {
            title();
            printf("\n\t");
            printChar('*', 64);

            printf("\n\n\t\t\t\t1. Add Student");
            printf("\n\n\t\t\t\t2. Modify Student");
            printf("\n\n\t\t\t\t3. Show All Student");
            printf("\n\n\t\t\t\t4. Individual View");
            printf("\n\n\t\t\t\t5. Remove Student");
            printf("\n\n\t\t\t\t6. Change Password");
            printf("\n\n\t\t\t\t7. Logout\n\t");
            printChar('*', 64);
            printf("\n\n\t\t\t\tEnter Your Option :--> ");
            scanf("%d", &option);

            switch (option)
            {
            case 1:
                // add(fp);
                break;
            case 2:
                modify(fp);
                break;
            case 3:
                display(fp);
                break;
            case 4:
                Indivisual(fp);
                break;
            case 5:
                fp = del(fp);
                break;
            case 6:
                system("cls");
                system("color 5f");
                password();
                break;
            case 7:
                return 1;
                break;
            default:
                printf("\n\t\tNo Action Detected");
                printf("\n\t\tPress Any Key\n\n\n");
                getch();
                system("pause");
            }
        }
    }
    else
    {
        printf("Wrong Password . Get Out");
        getch();
    }
    return 1;
}

void password()
{
    char c;
    printf("\nEnter new password :");
    fflush(stdin);
    gets(pa.pass);
    printf("\nSave password (y/n) :");
    fflush(stdin);
    scanf("%c", &c);
    if (c == 'y' || c == 'Y')
    {
        tp = fopen("F:/Password.txt", "w+");
        fwrite(&pa, sizeof(pa), 1, tp);
        fclose(tp);
        printf("\n\tPassword Saved\n");
    }
    else
    {
        printf("Password not saved :\n");
        printf("Press any key to continue >>>");
        getch();
    }
}

void printChar(char ch, int n)
{
    while (n--)
    {
        putchar(ch);
    }
}

void title()
{
    system("cls");
    system("COLOR 03");
    printf("\n\n\t");
    printChar('=', 19);
    printf(" Student Management System ");
    printChar('=', 19);
    printf("\n");
}

// Insert at end

void add(FILE *fp)
{
    title();

    char another = 'y';
    Student s;
    int i;
    float cgpa;

    fseek(fp, 0, SEEK_END);
    while (another == 'y' || another == 'Y')
    {

        printf("\n\n\t\tEnter Full Name of Student: ");
        fflush(stdin);
        fgets(s.name, 100, stdin);
        s.name[strlen(s.name) - 1] = '\0';

        printf("\n\n\t\tEnter Depertment Name: ");
        fflush(stdin);
        fgets(s.dept, 50, stdin);
        s.dept[strlen(s.dept) - 1] = '\0';

        printf("\n\n\t\tEnter Roll number: ");
        scanf("%d", &s.roll);

        printf("\n\n\tEnter SGPA for 12 semesters\n");
        for (i = 0, cgpa = 0; i < 12; i++)
        {
            scanf("%f", &s.sgpa[i]);
            cgpa += s.sgpa[i];
        }

        cgpa /= 12.0;
        s.cgpa = cgpa;

        fwrite(&s, sizeof(s), 1, fp);

        printf("\n\n\t\tAdd another student?(Y/N)?");
        fflush(stdin);
        another = getchar();
    }
}

FILE *del(FILE *fp)
{
    title();

    Student s;
    int flag = 0, tempRoll, siz = sizeof(s);
    FILE *ft;

    if ((ft = fopen("temp.txt", "wb+")) == NULL)
    {
        printf("\n\n\t\t\t\\t!!! ERROR !!!\n\t\t");
        system("pause");
        return fp;
    }

    printf("\n\n\tEnter Roll number of Student to Delete the Record");
    printf("\n\n\t\t\tRoll No. : ");
    scanf("%d", &tempRoll);

    rewind(fp);

    while ((fread(&s, siz, 1, fp)) == 1)
    {
        if (s.roll == tempRoll)
        {
            flag = 1;
            printf("\n\tRecord Deleted for");
            printf("\n\n\t\t%s\n\n\t\t%s\n\n\t\t%d\n\t", s.name, s.dept, s.roll);
            continue;
        }

        fwrite(&s, siz, 1, ft);
    }

    fclose(fp);
    fclose(ft);

    remove("db.txt");
    rename("temp.txt", "db.txt");

    if ((fp = fopen("db.txt", "rb+")) == NULL)
    {
        printf("ERROR");
        return NULL;
    }

    if (flag == 0)
        printf("\n\n\t\tNO STUDENT FOUND WITH THE INFORMATION\n\t");

    printChar('-', 65);
    printf("\n\t");
    system("pause");
    return fp;
}

void modify(FILE *fp)
{
    title();

    Student s;
    int i, flag = 0, tempRoll, siz = sizeof(s);
    float cgpa;

    printf("\n\n\tEnter Roll Number of Student to MODIFY the Record : ");
    scanf("%d", &tempRoll);

    rewind(fp);

    while ((fread(&s, siz, 1, fp)) == 1)
    {
        if (s.roll == tempRoll)
        {
            flag = 1;
            break;
        }
    }

    if (flag == 1)
    {
        fseek(fp, -siz, SEEK_CUR);
        printf("\n\n\t\t\t\tRecord Found\n\t\t\t");
        printChar('=', 38);
        printf("\n\n\t\t\tStudent Name: %s", s.name);
        printf("\n\n\t\t\tStudent Roll: %d\n\t\t\t", s.roll);
        printChar('=', 38);
        printf("\n\n\t\t\tEnter New Data for the student");

        printf("\n\n\t\t\tEnter Full Name of Student: ");
        fflush(stdin);
        fgets(s.name, 100, stdin);
        s.name[strlen(s.name) - 1] = '\0';

        printf("\n\n\t\t\tEnter Department: ");
        fflush(stdin);
        fgets(s.dept, 50, stdin);
        s.dept[strlen(s.dept) - 1] = '\0';

        printf("\n\n\t\t\tEnter Roll number: ");
        scanf("%d", &s.roll);

        printf("\n\n\t\tEnter SGPA for 12 semesters\n");
        for (i = 0, cgpa = 0; i < 12; i++)
        {
            scanf("%f", &s.sgpa[i]);
            cgpa += s.sgpa[i];
        }
        cgpa = cgpa / 8.0;

        fwrite(&s, sizeof(s), 1, fp);
    }

    else
        printf("\n\n\t!!!! ERROR !!!! RECORD NOT FOUND");

    printf("\n\n\t");
    system("pause");
}

void display(FILE *fp)
{
    title();
    Student s;
    int i, siz = sizeof(s);

    rewind(fp);

    while ((fread(&s, siz, 1, fp)) == 1)
    {
        printf("\n\t\tNAME : %s", s.name);
        printf("\n\n\t\tDepertment : %s", s.dept);
        printf("\n\n\t\tROLL : %d", s.roll);
        printf("\n\n\tSGPA: ");

        for (i = 0; i < 12; i++)
            printf("| %.2f |", s.sgpa[i]);
        printf("\n\n\t\tCGPA : %.2f\n\t", s.cgpa);
        printChar('-', 65);
    }
    printf("\n\n\n\t");
    printChar('*', 65);
    printf("\n\n\t");
    system("pause");
}

void Indivisual(FILE *fp)
{
    title();

    int tempRoll, flag, siz, i;
    Student s;
    char another = 'y';

    siz = sizeof(s);

    while (another == 'y' || another == 'Y')
    {
        printf("\n\n\tEnter Roll Number: ");
        scanf("%d", &tempRoll);

        rewind(fp);

        while ((fread(&s, siz, 1, fp)) == 1)
        {
            if (s.roll == tempRoll)
            {
                flag = 1;
                break;
            }
        }

        if (flag == 1)
        {
            printf("\n\t\tNAME : %s", s.name);
            printf("\n\n\t\tDepartment : %s", s.dept);
            printf("\n\n\t\tROLL : %d", s.roll);
            printf("\n\n\tSGPA: ");

            for (i = 0; i < 12; i++)
                printf("| %.2f |", s.sgpa[i]);
            printf("\n\n\t\tCGPA : %.2f\n\t", s.cgpa);
            printChar('-', 65);
        }
        else
            printf("\n\n\t\t!!!! ERROR RECORD NOT FOUND !!!!");

        printf("\n\n\t\tShow another student information? (Y/N)?");
        fflush(stdin);
        another = getchar();
    }
}

#include <stdio.h>
void even(int a[], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        if (a[i] % 2 == 0)
        {
            printf("%d ", a[i]);
        }
    }
}
int main()
{
    int n, a[100], i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    even(a, n);
    return 0;
}
#include <stdio.h>
int minimum(int a[], int n)
{
    int min = 999, i;
    for (i = 0; i < n; i++)
    {
        if (a[i] < min)
        {
            min = a[i];
        }
    }
    return min;
}
int main()
{
    int n, a[100], i, min;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    min = minimum(a, n);
    printf("Minimum Value: %d", min);
    return 0;
}
// Function that multiplies the array elements by 2 and returns the array.
#include <stdio.h>
void multipliesby2(int a[], int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        a[i] *= 2;
    }
}
int main()
{
    int n, a[100], i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    multipliesby2(a, n);
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    return 0;
}
// Function to sort and return an input array in ascending order.
#include <stdio.h>
void sort_ascending(int a[], int n)
{
    int i, j, temp;
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (a[j] < a[i])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}
int main()
{
    int n, a[100], i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the array elements\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    sort_ascending(a, n);
    for (i = 0; i < n; i++)
        printf("%d ", a[i]);
    return 0;
}
// Function “IsPrime()” to determine whether a number is prime or not .
#include <stdio.h>
void isPrime(int x)
{
    int i;
    if (x == 1)
        printf("Not prime");
    else if (x > 1)
    {
        for (i = 2; i < x; i++)
        {
            if (x % i == 0)
            {
                printf("Not prime");
                return;
            }
        }
        printf("Prime");
    }
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    isPrime(n);
    return 0;
}

#include <stdio.h>
void isPrime(int x)
{
    int i;
    for (i = 2; i < x; i++)
    {
        if (x % i == 0)
        {
            return;
        }
    }
    printf("%d, ", x);
}
void GeneratePrime(int x)
{
    int i;
    for (i = 2; i < x; i++)
    {
        isPrime(i);
    }
}
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Prime less than %d: ", n);
    GeneratePrime(n);
    return 0;
}
// Function “GenNthPrime()” to compute the Nth prime number, where N is an integer input.
#include <stdio.h>
int GenNthPrime(int n)
{
    int i, count = 0, flag, pn;
    for (i = 2; count != n; i++)
    {
        flag = 0;
        for (int j = 2; j < i; j++)
        {
            if (i % j == 0)
                flag++;
        }
        if (flag == 0)
        {
            count++;
            pn = i;
        }
    }
    return pn;
}
int main()
{
    int n, pn;
    printf("Enter a number: ");
    scanf("%d", &n);
    pn = GenNthPrime(n);
    printf("%dth Prime: %d", n, pn);
    return 0;
}

#include <stdio.h>
#include <math.h>
float CalcMean(int array[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += array[i];
    }
    return (sum / n);
}
float calc_std(int array[], int n)
{
    int sum = 0;
    float mean = CalcMean(array, n);
    for (int i = 0; i < n; i++)
    {
        sum += ((array[i] - mean) * (array[i] - mean));
    }
    return (sqrt(sum / n));
}
int main()
{
    int n, a[100], i;
    float mean, std;
    printf("Enter the array size: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    std = calc_std(a, n);
    printf("Standard deviation: %0.2f", std);
    return 0;
}
/*Function find_substr() that takes two string arrays(a, b)
as parameters, returns 1 if string b is found anywhere in string a, or returns –1 if no match is found.*/
#include <stdio.h>
#include <string.h>
int find_substr(char str[], char str1[])
{
    int i, j, l, flag;
    i = 0;
    while (str[i] != '\0')
    {
        j = 0;
        flag = 0;
        l = 0;
        while (str1[j] != '\0')
        {
            if (str[i + j] == str1[j])
                flag++;
            l++;
            j++;
        }
        if (l == flag)
            return 1;
        i++;
    }
    return 0;
}
int main()
{
    int r;
    char str[100], str1[100];
    printf("Enter 1st string: ");
    gets(str);
    printf("Enter 2nd string: ");
    gets(str1);
    r = find_substr(str, str1);
    printf("%d", r);
    return 0;
}
/*Function find_substr() that takes two string arrays(a, b) as parameters, uses function str_length() to determine the lengths of the strings, and then looks for the smaller string anywhere in the bigger string. It returns 1 if the substring is found, or returns –1 if no match is found.
[Restriction: str_length() cannot uses built-in strlen() function]*/
#include <stdio.h>
#include <string.h>
int str_length(char str[])
{
    int i, count;
    i = count = 0;
    while (str[i] != '\0')
    {
        count++;
        i++;
    }
    return count;
}
int find_substr(char str[], char str1[])
{
    int i, j, l, flag;
    i = 0;
    while (str[i] != '\0')
    {
        j = 0;
        flag = 0;
        l = 0;
        while (str1[j] != '\0')
        {
            if (str[i + j] == str1[j])
                flag++;
            l++;
            j++;
        }
        if (l == flag)
            return 1;
        i++;
    }
    return 0;
}
int main()
{
    char a[100], b[100];
    int n, m, r;
    printf("Enter 1st string: ");
    gets(a);
    printf("Enter 2nd string: ");
    gets(b);
    n = str_length(a);
    m = str_length(b);
    if (n > m)
        r = find_substr(a, b);
    else
        r = find_substr(b, a);
    printf("%d", r);
    return 0;
}
// Program that continuously takes two positive integers as inputs and uses two functions to find their GCD(greatest common divisor) and LCM(least common multiple).Both functions take parameters and returns desired values.[Hint : Use infinite loop to process inputs]
#include <stdio.h>
int GCD(int a, int b)
{
    int i, r;
    for (i = 1; i <= a && i <= b; i++)
    {
        if (a % i == 0 && b % i == 0)
            r = i;
    }
    return r;
}
int LCM(int a, int b)
{
    int lcm = (a * b) / GCD(a, b);
    return lcm;
}
int main()
{
    while (1)
    {
        int n, m;
        printf("Enter two number: ");
        scanf("%d %d", &n, &m);
        printf("GCD: %d\n", GCD(n, m));
        printf("LCM: %d\n", LCM(n, m));
    }
    return 0;
}
// Program that implements function to perform operations on a 3X5 matrix :
#include <stdio.h>
void InputMatrix(int a[3][5])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
            scanf("%d", &a[i][j]);
    }
}
void ShowMatrix(int a[3][5])
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
            printf("%d ", a[i][j]);
        printf("\n");
    }
}
void ScalarMultiply(int a[3][5], int n)
{
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
            a[i][j] *= n;
    }
}
int main()
{
    int n, a[3][5];
    printf("Enter 3X5 matrix elements:\n");
    InputMatrix(a);
    printf("Original:\n");
    ShowMatrix(a);
    printf("\nEnter a number: ");
    scanf("%d", &n);
    ScalarMultiply(a, n);
    printf("Multiplied by %d:\n", n);
    ShowMatrix(a);
    return 0;
}
// Program that implements function to perform operations on a MXN matrix :
#include <stdio.h>
int n,
    m;
void InputMatrix(int a[n][m], int n, int m)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
            scanf("%d", &a[i][j]);
    }
}
void ShowMatrix(int a[n][m], int n, int m)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
            printf("%d ", a[i][j]);
        printf("\n");
    }
}
void ScalarMultiply(int a[n][m], int n, int m, int x)
{
    int i, j;
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
            a[i][j] *= x;
    }
}
int main()
{
    int a[100][100];
    printf("Enter number of Row of the matrix: ");
    scanf("%d", &n);
    printf("Enter number of Columns of the matrix: ");
    scanf("%d", &m);
    printf("\nEnter the matrix elements:\n");
    InputMatrix(a, n, m);
    printf("\nOriginal:\n");
    ShowMatrix(a, n, m);
    printf("\nEnter a number: ");
    int num;
    scanf("%d", &num);
    ScalarMultiply(a, n, m, num);
    printf("\nMultiplied by %d:\n", num);
    ShowMatrix(a, n, m);
    return 0;
}
// Program to convert a positive integer to another base using the following functions -
#include <stdio.h>
void Get_Number_And_Base()
{
    int n, b;
    printf("Enter a number: ");
    scanf("%d", &n);
    printf("Enter The Base(Base must be between 2 and 16): ");
    scanf("%d", &b);
    if (b >= 2 && b <= 16)
    {
        Convert_Number(n, b);
    }
    else
        printf("Base not within proper range!");
}
void Convert_Number(int n, int b)
{
    int i = 0, r, num = 0;
    while (n != 0)
    {
        r = n % b;
        num += r * pow(10, i);
        n /= b;
        i++;
    }
    Show_Converted_Number(num);
}
void Show_Converted_Number(int n)
{
    printf("%d", n);
}
int main()
{
    Get_Number_And_Base();
}

// Declare a structure of students with three member variables(name, id and cgpa), where name is a string and id are strings, and cgpa is a float value.
#include <stdio.h>
#include <string.h>
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    return 0;
}
// Declare a structure of students with three member variables(name, id and cgpa), where name is a string and id are strings, and cgpa is a float value with default values.
#include <stdio.h>
struct student
{
    char name[100];
    char id[100];
    float cgpa;
};
int main()
{
    struct student s = {"Nazmul", "011211096", 3.7};
    printf("Student Name: %s\n", s.name);
    printf("Student id: %s\n", s.id);
    printf("Student CGPA: %0.2f\n", s.cgpa);
    return 0;
}
// Given a structure student, which has three member variables(name, id and cgpa), declare a variable of structure student.
#include <stdio.h>
#include <string.h>
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student1;
    return 0;
}
// Given a structure student, which has three member variables(name, id and cgpa), declare a variable of structure student.Display the value of the member variables.
#include <stdio.h>
#include <string.h>
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student1;
    strcpy(student1.name, "Nazmul");
    strcpy(student1.id, "011211096");
    student1.cgpa = 3.7;
    printf("----------Student information----------\n");
    printf("Name: %s\n", student1.name);
    printf("ID: %s\n", student1.id);
    printf("CGPA: %f\n", student1.cgpa);
    return 0;
}

#include <stdio.h>
#include <string.h>
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student1;
    strcpy(student1.name, "Nazmul");
    strcpy(student1.id, "011211096");
    student1.cgpa = 3.7;
    return 0;
}
Given a structure student, which has three member variables(name, id and cgpa), declare a variable of structure student.Populate the member variables from the keyboard.
#include <stdio.h>
#include <string.h>
                                                                                int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student1;
    char name[100];
    char id[100];
    printf("Enter the Student name: ");
    gets(name);
    printf("Enter the Student ID: ");
    gets(id);
    strcpy(student1.name, name);
    strcpy(student1.id, id);
    printf("Enter the student CGPA: ");
    scanf("%f", &student1.cgpa);
    printf("\n\nName: %s\n", student1.name);
    printf("ID: %s\n", student1.id);
    printf("CGPA: %f\n", student1.cgpa);
    return 0;
}

#include <string.h>
#define n 2
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student[100];
    char name[100];
    char id[100];
    int i, dummy;
    for (i = 0; i < n; i++)
    {
        printf("Enter the Student name: ");
        gets(name);
        printf("Enter the Student ID: ");
        gets(id);
        strcpy(student[i].name, name);
        strcpy(student[i].id, id);
        printf("Enter the student CGPA: ");
        scanf("%f", &student[i].cgpa);

        scanf("%c", &dummy);
    }
    for (i = 0; i < n; i++)
    {
        printf("\n\nName: %s\n", student[i].name);
        printf("ID: %s\n", student[i].id);
        printf("CGPA: %f\n", student[i].cgpa);
    }
    return 0;
}

#include <string.h>
#define n 2
int main()
{
    struct student
    {
        char name[100];
        char id[100];
        float cgpa;
    };
    struct student student[100];
    char name[100];
    char id[100];
    int i, dummy;
    for (i = 0; i < n; i++)
    {
        printf("Enter the Student name: ");
        gets(name);
        printf("Enter the Student ID: ");
        gets(id);
        strcpy(student[i].name, name);
        strcpy(student[i].id, id);
        printf("Enter the student CGPA: ");
        scanf("%f", &student[i].cgpa);

        scanf("%c", &dummy);
    }
    if (student[0].cgpa > student[1].cgpa)
    {
        printf("\n\nName: %s\n", student[0].name);
        printf("ID: %s\n", student[0].id);
        printf("CGPA: %f\n", student[0].cgpa);
    }
    else
    {
        printf("\n\nName: %s\n", student[1].name);
        printf("ID: %s\n", student[1].id);
        printf("CGPA: %f\n", student[1].cgpa);
    }
    return 0;
}

#include <stdio.h>
#include <string.h>
#define n 2
struct student
{
    char name[100];
    char id[100];
    float cgpa;
};
void display(struct student student[])
{
    if (student[0].cgpa > student[1].cgpa)
    {
        printf("\n\nName: %s\n", student[0].name);
        printf("ID: %s\n", student[0].id);
        printf("CGPA: %f\n", student[0].cgpa);
    }
    else
    {
        printf("\n\nName: %s\n", student[1].name);
        printf("ID: %s\n", student[1].id);
        printf("CGPA: %f\n", student[1].cgpa);
    }
}
int main()
{
    struct student student[100];
    char name[100];
    char id[100];
    int i, dummy;
    for (i = 0; i < n; i++)
    {
        printf("Enter the Student name: ");
        gets(name);
        printf("Enter the Student ID: ");
        gets(id);
        strcpy(student[i].name, name);
        strcpy(student[i].id, id);
        printf("Enter the student CGPA: ");
        scanf("%f", &student[i].cgpa);

        scanf("%c", &dummy);
    }
    display(student);
    return 0;
}

#include <stdio.h>
#include <string.h>
#define n 3
struct triangle
{
    int id;
    int base;
    int height;
};
int main()
{
    struct triangle t[100];
    int i;
    for (i = 0; i < n; i++)
    {
        printf("Enter triangle id: ");
        scanf("%d", &t[i].id);
        printf("Enter base: ");
        scanf("%d", &t[i].base);
        printf("Enter height: ");
        scanf("%d", &t[i].height);
    }
    for (i = 0; i < n; i++)
    {
        float area = (t[i].base * t[i].height) / 2;
        printf("Area of %d = %0.1f\n", t[i].id, area);
    }
    return 0;
}

#include <stdio.h>
#define n 3
struct triangle
{
    int id;
    int base;
    int height;
    float area;
};
int find_max_area(struct triangle a[])
{
    int i;
    for (i = 0; i < n; i++)
    {
        printf("Enter triangle id: ");
        scanf("%d", &a[i].id);
        printf("Enter triangle base: ");
        scanf("%d", &a[i].base);
        printf("Enter triangle height: ");
        scanf("%d", &a[i].height);
        a[i].area = (a[i].base * a[i].height) / 2;
    }
    int max_area = a[0].area;
    int l = 0;
    for (i = 0; i < n; i++)
    {
        if (a[i].area > max_area)
        {
            max_area = a[i].area;
            l = i;
        }
    }
    return l;
}
int main()
{
    struct triangle t[100];
    int x;
    x = find_max_area(t);
    printf("\nArea of %d = %0.2f\n", t[x].id, t[x].area);
    return 0;
}

#include <stdio.h>
#include <string.h>
#define n 2 // number of players
#define m 3 // number of match
struct players
{
    char name[100];
    char country[100];
    int run[3];
    int wickets[3];
    int points[3];
};
void main()
{
    struct players p[100];
    int i, j, dummy;
    char name[100], country[100];
    for (i = 0; i < n; i++)
    {
        printf("Enter player name: ");
        fflush(stdin);
        gets(p[i].name);
        printf("Enter player country: ");
        gets(p[i].country);
        for (j = 0; j < m; j++)
        {
            printf("Enter match %d run: ", j + 1);
            scanf("%d", &p[i].run[j]);
        }
        for (j = 0; j < m; j++)
        {
            printf("Enter match %d wickets: ", j + 1);
            scanf("%d", &p[i].wickets[j]);
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (p[i].run[j] <= 25)
                p[i].points[j] = 5;
            else if (p[i].run[j] > 25 && p[i].run[j] <= 50)
                p[i].points[j] = 10;
            else if (p[i].run[j] > 50 && p[i].run[j] <= 75)
                p[i].points[j] = 15;
            else if (p[i].run[j] > 75)
                p[i].points[j] = 20;
            p[i].points[j] += p[i].wickets[j] * 12;
        }
    }
    printf("\n\n");
    for (i = 0; i < m; i++)
    {
        printf("Match %d:\n", i + 1);
        for (int j = 0; j < n; j++)
        {
            printf("%s points: %d\n", p[j].name, p[j].points[i]);
        }
        printf("\n");
    }
}

#include <stdio.h>
#include <string.h>
#define n 2 // number of players
#define m 3 // number of match
struct players
{
    char name[100];
    char country[100];
    int run[3];
    int wickets[3];
    int points[3];
};
void main()
{
    struct players p[100];
    int i, j, dummy;
    char name[100], country[100];
    for (i = 0; i < n; i++)
    {
        printf("Enter player name: ");
        fflush(stdin);
        gets(p[i].name);
        printf("Enter player country: ");
        gets(p[i].country);
        for (j = 0; j < m; j++)
        {
            printf("Enter match %d run: ", j + 1);
            scanf("%d", &p[i].run[j]);
        }
        for (j = 0; j < m; j++)
        {
            printf("Enter match %d wickets: ", j + 1);
            scanf("%d", &p[i].wickets[j]);
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            if (p[i].run[j] <= 25)
                p[i].points[j] = 5;
            else if (p[i].run[j] > 25 && p[i].run[j] <= 50)
                p[i].points[j] = 10;
            else if (p[i].run[j] > 50 && p[i].run[j] <= 75)
                p[i].points[j] = 15;
            else if (p[i].run[j] > 75)
                p[i].points[j] = 20;
            p[i].points[j] += p[i].wickets[j] * 12;
        }
    }
    printf("\n\n");
    for (i = 0; i < m; i++)
    {
        printf("Match %d:\n", i + 1);
        for (int j = 0; j < n; j++)
        {
            printf("%s points: %d\n", p[j].name, p[j].points[i]);
        }
        if (p[0].points[i] > p[1].points[i])
            printf("MOM: %s\n", p[0].name);
        else
            printf("MOM: %s\n", p[1].name);
        printf("\n");
    }
    printf("\n");
    // find man of the seris
    int tp[100];
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < m; j++)
        {
            tp[i] += p[i].points[j];
        }
    }
    int l = 0;
    int max_tp = tp[0];
    for (i = 0; i < n; i++)
    {
        if (tp[i] > tp[0])
        {
            max_tp = tp[i];
            l = i;
        }
    }
    printf("Man of the Series: %s\n", p[l].name);
}

#include <stdio.h>
int main()
{
    int n1, n2;
    int *ptr1, *ptr2;
    printf("Enter 1st number: ");
    scanf("%d", &n1);
    printf("Enter 2nd number: ");
    scanf("%d", &n2);
    ptr1 = (&n1);
    ptr2 = (&n2);
    int sum = *ptr1 + *ptr2;
    printf("The sum is: %d", sum);
    return 0;
}
#include <stdio.h>
int main()
{
    int n1, n2;
    int *p1, *p2;
    printf("Enter 1st number: ");
    scanf("%d", &n1);
    printf("Enter 2nd number: ");
    scanf("%d", &n2);
    p1 = (&n1);
    p2 = (&n2);
    if (*p1 > *p2)
        printf("%d is maximum", *p1);
    else
        printf("%d is maximum", *p2);
    return 0;
}

#include <stdio.h>
void print_array(int a[], int start, int n);
int main()
{
    int a[100], n, i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the Elements of array\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("Elements in the array: ");
    print_array(a, 0, n);
    return 0;
}
void print_array(int a[], int start, int n)
{
    if (start >= n)
        return;
    printf("%d ", a[start]);
    print_array(a, start + 1, n);
}
#include <stdio.h>
int main()
{
    char str[20], *pt;
    int i = 0;
    printf("Enter Any string: ");
    gets(str);
    pt = str;
    while (*pt != '\0')
    {
        i++;
        pt++;
    }
    printf("Length of String : %d", i);
    return 0;
}
#include <stdio.h>
int main()
{
    int n1, n2, *p1, *p2, temp;
    printf("Enter 1st number: ");
    scanf("%d", &n1);
    printf("Enter 2nd number: ");
    scanf("%d", &n2);
    p1 = &n1;
    p2 = &n2;
    temp = *p1;
    *p1 = *p2;
    *p2 = temp;
    printf("After swap\n");
    printf("1st number is: %d\n", n1);
    printf("2nd number is: %d\n", n2);
    return 0;
}
#include <stdio.h>
int main()
{
    char a[100], *p;
    int v = 0, c = 0;
    printf("Enter a string: ");
    gets(a);
    p = a;
    while (*p != '\0')
    {
        if (*p >= 'a' && *p <= 'z' || *p >= 'A' && *p <= 'Z')
        {
            if (*p == 'a' || *p == 'A' || *p == 'e' || *p == 'E' || *p == 'i' || *p == 'I' || *p == 'o' || *p == 'O' || *p == 'u' || *p == 'U')
                v++;
            else
                c++;
        }
        *p++;
    }
    printf("The number of vowels is: %d\n", v);
    printf("The number of consonants is: %d\n", c);
    return 0;
}
#include <stdio.h>
int main()
{
    int a[100], n, i, *p, sum = 0;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the elements of array\n");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    p = a;
    i = 0;
    while (i < n)
    {
        sum += *p;
        *p++;
        i++;
    }
    printf("The sum is: %d", sum);
    return 0;
}

#include <stdio.h>

void rev_array(int a[], int n);
int main()
{
    int a[100], n, i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the array elements: ");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("The reverse indexed order array is: ");
    rev_array(a, n - 1);
    return 0;
}
void rev_array(int a[], int n)
{
    if (n < 0)
        return;
    else
        printf("%d ", a[n]);
    rev_array(a, n - 1);
}

#include <stdio.h>
void print_number(int a);
int main()
{
    int n = 1;
    print_number(n);
    return 0;
}
void print_number(int a)
{
    if (a <= 10)
    {
        printf("%d ", a);
        print_number(a + 1);
    }
    else
        return;
}
// WAP that will calculate the sum of numbers from 1 to n using recursion.
#include <stdio.h>
void print_number(int a, int n);
int main()
{
    int num, n = 1;
    printf("Enter a number: ");
    scanf("%d", &num);
    print_number(num, n);
    return 0;
}
void print_number(int a, int n)
{
    if (n <= a)
    {
        printf("%d ", n);
        print_number(a, n + 1);
    }
    else
        return;
}

#include <stdio.h>
int Fibonacci(int);
int main()
{
    int n, i = 0, c;
    printf("Enter the terms of series: ");
    scanf("%d", &n);

    printf("Fibonacci series\n");

    for (c = 1; c <= n; c++)
    {
        printf("%d ", Fibonacci(i));
        i++;
    }

    return 0;
}
int Fibonacci(int n)
{
    if (n == 0)
        return 0;
    else if (n == 1)
        return 1;
    else
        return (Fibonacci(n - 1) + Fibonacci(n - 2));
}

#include <stdio.h>
void print_array(int a[], int n);
int main()
{
    int a[100], n, i;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the elements of array: ");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);
    printf("The array elements are: ");
    print_array(a, n - 1);
    return 0;
}
void print_array(int a[], int n)
{
    static int i = 0;
    if (n < 0)
        return;
    else
    {
        printf("%d ", a[i]);
        i++;
        print_array(a, n - 1);
    }
}
// WAP that will count the digits of a given number using recursion.
#include <stdio.h>
int count_digit(int n)
{
    int static c = 0;
    if (n == 0)
        return c;
    else
    {
        c++;
        n /= 10;
        count_digit(n);
    }
}
int main()
{
    int num, r;
    printf("Enter a number: ");
    scanf("%d", &num);
    r = count_digit(num);
    printf("The number of digits of the number is: %d\n", r);
    return 0;
}

#include <stdio.h>

#define MAXROW 10
#define MAXCOL 10

/*User Define Function to Read Matrix*/
void readMatrix(int m[][MAXCOL], int row, int col)
{
    int i, j;
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            printf("Enter element [%d,%d] : ", i + 1, j + 1);
            scanf("%d", &m[i][j]);
        }
    }
}

/*User Define Function to Read Matrix*/
void printMatrix(int m[][MAXCOL], int row, int col)
{
    int i, j;
    for (i = 0; i < row; i++)
    {
        for (j = 0; j < col; j++)
        {
            printf("%d\t", m[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int a[MAXROW][MAXCOL], b[MAXROW][MAXCOL], result[MAXROW][MAXCOL];
    int i, j, r1, c1, r2, c2;
    int sum, k;

    printf("Enter number of Rows of matrix a: ");
    scanf("%d", &r1);
    printf("Enter number of Cols of matrix a: ");
    scanf("%d", &c1);

    printf("\nEnter elements of matrix a: \n");
    readMatrix(a, r1, c1);

    printf("Enter number of Rows of matrix b: ");
    scanf("%d", &r2);
    printf("Enter number of Cols of matrix b: ");
    scanf("%d", &c2);

    printf("\nEnter elements of matrix b: \n");
    readMatrix(b, r2, c2);

    if (r1 == c2)
    {
        /*Multiplication of two matrices*/
        for (i = 0; i < r1; i++)
        {
            for (j = 0; j < c1; j++)
            {
                sum = 0;
                for (k = 0; k < r1; k++)
                {
                    sum = sum + (a[i][k] * b[k][j]);
                }
                result[i][j] = sum;
            }
        }

        /*print matrix*/
        printf("\nMatrix after multiplying elements (result matrix):\n");
        printMatrix(result, r1, c1);
    }
    else
    {
        printf("\nMultiplication can not be done.");
    }

    return 0;
}

// WAP that will get the largest element of an array using recursion.
#include <stdio.h>
int n;
int lar(int a[]);
int main()
{
    int a[100], i, max;
    printf("Enter the size of array: ");
    scanf("%d", &n);
    printf("Enter the elements of array: ");
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    max = lar(a);
    printf("The largest element of array is: %d", max);
    return 0;
}
int lar(int a[])
{
    static int i = 0, max = -9999;
    if (i < n)
    {
        if (a[i] > max)
            max = a[i];
        i++;
        lar(a);
    }
    return max;
}
////WAP that will print even or odd numbers in given range using recursion.
#include <stdio.h>
void even(int x, int y);
void odd(int x, int y);
int main()
{
    int n1, n2, c;
    printf("Enter the first number of range: ");
    scanf("%d", &n1);
    printf("Enter the last number of range: ");
    scanf("%d", &n2);
    printf("If you want to print even enter 1 or enter 2: ");
    scanf("%d", &c);
    if (c == 1)
        even(n1, n2);
    else if (c == 2)
        odd(n1, n2);
    return 0;
}
void even(int x, int y)
{
    if (x <= y)
    {
        if (x % 2 == 0)
            printf("%d ", x);
        even(x + 1, y);
    }
    else
        return;
}
void odd(int x, int y)
{
    if (x <= y)
    {
        if (x % 2 == 1)
            printf("%d ", x);
        odd(x + 1, y);
    }
    else
        return;
}
pal(char a[], char b[])
{
    static int i = 0;
    while (a[i] != '\0')
    {
        if (a[i] != b[i])
        {
            return 0;
        }
        else
        {
            i++;
            pal(a, b);
        }
    }
    return 1;
}
int main()
{
    char a[100], b[100];
    printf("Enter a string: ");
    gets(a);
    int l = strlen(a);
    for (int i = 0; i < l; i++)
    {
        b[i] = a[l - 1 - i];
    }
    int r = pal(a, b);
    if (r == 1)
        printf("Palindrome");
    else
        printf("Not palindrome");
    return 0;
}
#include <stdio.h>
int main()
{
    FILE *file;
    file = fopen("sample.txt", "w");
    if (file == NULL)
    {
        printf("Error! file does not exist");
    }
    else
    {
        fputs("1 Zahid\n", file);
        fputs("2 Tanvir\n", file);
        fputs("3 Akif\n", file);
        printf("File is written successfully");
        fclose(file);
    }
    return 0;
}
#include <stdio.h>
int main()
{
    FILE *file;
    char ch;
    file = fopen("sample.txt", "r");
    if (file == NULL)
    {
        printf("Error! file does not exist");
    }
    else
    {
        while (!feof(file))
        {
            ch = fgetc(file);
        }
        printf("\n\nFile read successfully\n\n");
        fclose(file);
    }
    return 0;
}
#include <stdio.h>
int main()
{
    FILE *file;
    char ch;
    file = fopen("sample.txt", "r");
    if (file == NULL)
    {
        printf("Error! file does not exist");
    }
    else
    {
        while (!feof(file))
        {
            ch = fgetc(file);
            printf("%c", ch);
        }
        printf("\n\nFile read successfully\n\n");
        fclose(file);
    }
    return 0;
}
#include <stdio.h>
int main()
{
    FILE *file;
    char ch;
    int count = 0;
    file = fopen("sample.txt", "r");
    if (file == NULL)
    {
        printf("Error! file does not exist");
    }
    else
    {
        while (!feof(file))
        {
            ch = fgetc(file);
            if (ch == '\n')
                count++;
        }
        printf("\n\nFile read successfully\n\n");
        fclose(file);
    }
    printf("The number of line in file is: %d\n", count);
    return 0;
}

#include <stdio.h>

int main()
{
    FILE *fptr;
    int i, n;
    char str[100];
    char fname[20];
    char str1;
    printf(" Input the file name to be opened : ");
    scanf("%s", fname);
    fptr = fopen(fname, "a");
    printf(" Input the number of lines to be written : ");
    scanf("%d", &n);
    printf(" The lines are : \n");
    for (i = 0; i < n + 1; i++)
    {
        fgets(str, sizeof str, stdin);
        fputs(str, fptr);
    }
    fclose(fptr);
    fptr = fopen(fname, "r");
    printf("\n The content of the file %s is  :\n", fname);
    while (!feof(fptr))
    {
        str1 = fgetc(fptr);
        printf("%c", str1);
    }
    printf("\n\n");
    fclose(fptr);
    return 0;
}

#include <stdio.h>
void demogorgenNumber(int a)
{
    int s = a;
    int z = checkerfun1(s);
    if (z == 1)
    {
        printf("%d ", a);
    }
}

int checkerfun1(int a)
{
    int n = a;
    int esum = 0, osum = 0, count = 0, temp;
    while (n != 0)
    {
        temp = n % 10;
        n = n / 10;
        count++;

        if (count % 2 != 0)
        {
            osum += n;
        }
        else if (count % 2 == 0)
        {
            esum += n;
        }
    }

    if (osum < esum)
    {
        int d;
        d = primec(a);
        if (d == 1)
        {
            return 1;
        }
        else
            return -1;
    }
}

int primec(int a)
{
    int flag = 0;
    for (int i = 2; i < a; i++)
    {
        if (a % i == 0)
        {
            flag = 1;
            break;
        }
    }

    if (flag == 0 && a > 0)
    {
        return 1;
    }
    else
        return -1;
}

int main()
{
    int r1, r2;
    scanf("%d%d", &r1, &r2);

    for (int i = r1; i <= r2; i++)
    {
        demogorgenNumber(i);
    }
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[])
{
    float valueOne;
    float valueTwo;
    char operator;
    float answer;

    printf("Enter calculation:\n\n");
    scanf("%f %c %f", &valueOne, &operator, & valueTwo);

    switch (operator)
    {
    case '/':
        answer = valueOne / valueTwo;
        break;
    case '*':
        answer = valueOne * valueTwo;
        break;
    case '+':
        answer = valueOne + valueTwo;
        break;
    case '-':
        answer = valueOne - valueTwo;
        break;
    case '^':
        answer = pow(valueOne, valueTwo);
        break;
    case ' ':
        answer = sqrt(valueTwo);
        break;
    default:
        goto fail;
    }
    printf("%.9g%c%.9g =  %.6g\n\n", valueOne, operator, valueTwo, answer);
    goto exit;
fail:
    printf("Fail.\n");
exit:
    return 0;
}

#include <stdio.h>

int main()
{
    char category;
    int tempChoice;
    int currencyChoice;
    int massChoice;
    int userinputF;          // User inputted Fahreinheit;
    int userinputC;          // User inputted Celsius;
    int userinputUSDtoEuro;  // User inputted for USD to EURO;
    int userinputUSDtoJPY;   // User inputted for USD to JPY;
    int userinputUSDtoRMB;   // User inputted for USD to RMB;
    int userinputOunce;      // User inputted for Ounce;
    int userinputGram;       // User inputted for Gram;
    int fahrenheitToCelcius; // variable that stores the converted F->C;
    int celciusToFahrenheit; // variable that stores the converted C->F;
    float USDtoEURO;         // varaible that stores the converted USD->EURO;
    float USDtoJPY;          // stores the converted USD->JPY;
    float USDtoRMB;          // stores the converted USD->RMB;
    float ounceToPounds;     // stores the converted Ounce->Pounds;
    float gramsToPounds;     // stores the vonerted Grams->Pounds;

    printf("Welcome to Unit Converter! \n");
    printf("Here is a list of conversation to choose from: \n");
    printf("Temperature(T),Currency(C),Mass(M) \n");
    printf("Please enter the letter you want to convert.\n");
    scanf("%c", &category);

    if (category == 'T')
    {
        printf("Welcome to Temperature Converter! \n");
        printf("Here is a list of conversations to choose from: \n");
        printf("Enter 1 for Fahrenheit to Celsius. \n");
        printf("Enter 2 for Celsius to Fahrenheit. \n");
        scanf("%d", &tempChoice);
        if (tempChoice == 1)
        {
            printf("Please enter the Fahrenheit degree: \n");
            scanf("%d", &userinputF);
            fahrenheitToCelcius = ((userinputF - 32) * (5.0 / 9.0));
            printf("Celcius: %d", fahrenheitToCelcius);
        }
        else if (tempChoice == 2)
        {
            printf("Please enter the Celcius degree: \n");
            scanf("%d", &userinputC);
            celciusToFahrenheit = ((9.0 / 5.0) * userinputC + 32);
            printf("Fahrenheit: %d", celciusToFahrenheit);
        }
        else
            printf("Please enter the correct choice. \n");
    }

    else if (category == 'C')
    {
        printf("Welcome to Currency Converter! \n");
        printf("Here is a list of conversations to choose from: \n");
        printf("Enter 1 for USD to Euro. \n");
        printf("Enter 2 for USD to JPY. \n");
        printf("Enter 3 for USD to RMB. \n");
        scanf("%d", &currencyChoice);
        if (currencyChoice == 1)
        {
            printf("Please enter the USD amount: \n");
            scanf("%d", &userinputUSDtoEuro);
            USDtoEURO = userinputUSDtoEuro * 0.87;
            printf("Euro: %.2f", USDtoEURO); // %.2f = rounds the float to only 2 decimal places;
        }
        else if (currencyChoice == 2)
        {
            printf("Please enter the USD amount: \n");
            scanf("%d", &userinputUSDtoJPY);
            USDtoJPY = userinputUSDtoJPY * 111.09;
            printf("JPY: %.2f", USDtoJPY);
        }
        else if (currencyChoice == 3)
        {
            printf("Please enter the USD amount: \n");
            scanf("%d", &userinputUSDtoRMB);
            USDtoRMB = userinputUSDtoRMB * 6.82;
            printf("RMB: %.2f", USDtoRMB);
        }
        else
            printf("Please enter correct choice. \n");
    }
    else if (category == 'M')
    {
        printf("Welcome to Mass Converter! \n");
        printf("Here is a list of conversations to choose from: \n");
        printf("Enter 1 for ounces to pounds. \n");
        printf("Enter 2 for gram to pounds. \n");
        scanf("%d", &massChoice);
        if (massChoice == 1)
        {
            printf("Please enter the ounce amount: \n");
            scanf("%d", &userinputOunce);
            ounceToPounds = userinputOunce * 0.0625;
            printf("Pounds: %.2f", ounceToPounds);
        }
        else if (massChoice == 2)
        {
            printf("Please enter the gram amount: \n");
            scanf("%d", &userinputGram);
            gramsToPounds = userinputGram * 0.00220462;
            printf("Pounds: %.2f", gramsToPounds);
        }
        else
            printf("Please enter the correct choice. \n");
    }
    return 0;
}
// C program to find the frequency of EVEN numbers in MATRIX

#include <stdio.h>

#define ROW 3
#define COL 3

int main()
{
    int Matrix[ROW][COL] = {
        {9, 8, 7},
        {5, 4, 6},
        {1, 2, 3}};

    int i, j, EvenFrequency = 0;

    printf("Matrix:\n");
    for (i = 0; i < ROW; ++i)
    {
        for (j = 0; j < COL; ++j)
        {
            if (Matrix[i][j] % 2 == 0)
                EvenFrequency++;
            printf(" %d", Matrix[i][j]);
        }
        printf("\n");
    }

    printf("Frequency of EVEN numbers is: %d\n", EvenFrequency);

    return 0;
}

#include <stdio.h>

#define MAXROW 10
#define MAXCOL 10

int main()
{
    int matrix[MAXROW][MAXCOL];
    int i, j, r, c;

    printf("Enter number of Rows :");
    scanf("%d", &r);
    printf("Enter number of Cols :");
    scanf("%d", &c);

    printf("\nEnter matrix elements :\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("Enter element [%d,%d] : ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }

    printf("\nMatrix is :\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n"); // new line after row elements
    }
    return 0;
}

#include <stdio.h>

#define MAXROW 10
#define MAXCOL 10

int main()
{
    int matrix[MAXROW][MAXCOL];
    int i, j, r, c;
    int sum, product;

    printf("Enter number of Rows :");
    scanf("%d", &r);
    printf("Enter number of Cols :");
    scanf("%d", &c);

    printf("\nEnter matrix elements :\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("Enter element [%d,%d] : ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }

    // sum and product of all elements
    // initializing sun and product variables
    sum = 0;
    product = 1;
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            sum += matrix[i][j];
            product *= matrix[i][j];
        }
    }

    printf("\nSum of all elements : %d \nProduct of all elements :%d", sum, product);
    return 0;
}

#include <stdio.h>

#define MAXROW 10
#define MAXCOL 10

int main()
{
    int matrix[MAXROW][MAXCOL];
    int i, j, r, c;
    int sum, product;

    printf("Enter number of Rows :");
    scanf("%d", &r);
    printf("Enter number of Cols :");
    scanf("%d", &c);

    printf("\nEnter matrix elements :\n");
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("Enter element [%d,%d] : ", i + 1, j + 1);
            scanf("%d", &matrix[i][j]);
        }
    }
    printf("\n");
    // sum of all rows
    for (i = 0; i < r; i++)
    {
        sum = 0; // initializing sum
        for (j = 0; j < c; j++)
        {
            printf("%d\t", matrix[i][j]); // print elements
            sum += matrix[i][j];
        }
        printf("\tSUM : %d", sum);
        printf("\n"); // after each row print new line
    }
}

#include <stdio.h>

#define ROW 3
#define COL 3

int main()
{
    int matrix[ROW][COL] = {{2, 3, 4}, {4, 5, 6}, {6, 7, 8}};

    printf("Lower Triangular Matrix\n");

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (i >= j)
                printf("%d ", matrix[i][j]);
            else
                printf("%d ", 0);
        }
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void main()
{
    char str[50];

    printf("\n\nAccept a string from keyboard :\n");
    printf("-----------------------------------\n");
    printf("Input the string : ");
    fgets(str, sizeof str, stdin);
    printf("The string you entered is : %s\n", str);
}

#include <stdio.h>
void main()
{
    float PerHeight;

    printf("Input the height of the person (in centimetres) :");
    scanf("%f", &PerHeight);
    if (PerHeight < 150.0)
        printf("The person is Dwarf. \n");
    else if ((PerHeight >= 150.0) && (PerHeight < 165.0))
        printf("The person is  average heighted. \n");
    else if ((PerHeight >= 165.0) && (PerHeight <= 195.0))
        printf("The person is taller. \n");
    else
        printf("Abnormal height.\n");
}

#include <stdio.h>
void main()
{
    int num1, num2, num3;

    printf("Input the values of three numbers : ");
    scanf("%d %d %d", &num1, &num2, &num3);
    printf("1st Number = %d,\t2nd Number = %d,\t3rd Number = %d\n", num1, num2, num3);
    if (num1 > num2)
    {
        if (num1 > num3)
        {
            printf("The 1st Number is the greatest among three. \n");
        }
        else
        {
            printf("The 3rd Number is the greatest among three. \n");
        }
    }
    else if (num2 > num3)
        printf("The 2nd Number is the greatest among three \n");
    else
        printf("The 3rd Number is the greatest among three \n");
}

#include <stdio.h>
void main()
{
    int p, c, m, t, mp;

    printf("Eligibility Criteria :\n");
    printf("Marks in Maths >=65\n");
    printf("and Marks in Phy >=55\n");
    printf("and Marks in Chem>=50\n");
    printf("and Total in all three subject >=190\n");
    printf("or Total in Maths and Physics >=140\n");
    printf("-------------------------------------\n");

    printf("Input the marks obtained in Physics :");
    scanf("%d", &p);
    printf("Input the marks obtained in Chemistry :");
    scanf("%d", &c);
    printf("Input the marks obtained in Mathematics :");
    scanf("%d", &m);
    printf("Total marks of Maths, Physics and Chemistry : %d\n", m + p + c);
    printf("Total marks of Maths and  Physics : %d\n", m + p);

    if (m >= 65)
        if (p >= 55)
            if (c >= 50)
                if ((m + p + c) >= 190 || (m + p) >= 140)
                    printf("The  candidate is eligible for admission.\n");
                else
                    printf("The candidate is not eligible.\n");
            else
                printf("The candidate is not eligible.\n");
        else
            printf("The candidate is not eligible.\n");
    else
        printf("The candidate is not eligible.\n");
}
#include <stdio.h>
#include <string.h>

void main()
{
    int rl, phy, che, ca, total;
    float per;
    char nm[20], div[10];
    printf("Input the Roll Number of the student :");
    scanf("%d", &rl);
    printf("Input the Name of the Student :");
    scanf("%s", nm);
    printf("Input  the marks of Physics, Chemistry and Computer Application : ");
    scanf("%d%d%d", &phy, &che, &ca);
    total = phy + che + ca;
    per = total / 3.0;
    if (per >= 60)
        strcpy(div, "First");
    else if (per < 60 && per >= 48)
        strcpy(div, "Second");
    else if (per < 48 && per >= 36)
        strcpy(div, "Pass");
    else
        strcpy(div, "Fail");

    printf("\nRoll No : %d\nName of Student : %s\n", rl, nm);
    printf("Marks in Physics : %d\nMarks in Chemistry : %d\nMarks in Computer Application : %d\n", phy, che, ca);
    printf("Total Marks = %d\nPercentage = %5.2f\nDivision = %s\n", total, per, div);
}
#include <stdio.h>
void main()
{
    int anga, angb, angc, sum; // are three angles of a triangle

    printf("Input three angles of triangle : ");
    scanf("%d %d %d", &anga, &angb, &angc);

    /* Calculate the sum of all angles of triangle */
    sum = anga + angb + angc;

    /* Check whether sum=180 then its a valid triangle otherwise not */
    if (sum == 180)
    {
        printf("The triangle is valid.\n");
    }
    else
    {
        printf("The triangle is not valid.\n");
    }
}

#include <stdio.h>
#define MAX_SIZE 100 // Maximum string size

int main()
{
    char str[MAX_SIZE];
    int i;

    // Input string from user
    printf("Enter your text : ");
    gets(str);

    for (i = 0; str[i] != '\0'; i++)
    {

        if (str[i] >= 'a' && str[i] <= 'z')
        {
            str[i] = str[i] - 32;
        }
    }

    printf("Uppercase string : %s", str);
    return 0;
}
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define str_size 100 // Declare the maximum size of the string

void main()
{
    char str[str_size];
    int i, wrd;

    printf("\n\nCount the total number of words in a string :\n");
    printf("------------------------------------------------------\n");
    printf("Input the string : ");
    fgets(str, sizeof str, stdin);

    i = 0;
    wrd = 1;

    while (str[i] != '\0')
    {
        if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
        {
            wrd++;
        }

        i++;
    }

    printf("Total number of words in the string is : %d\n", wrd - 1);
}
#include <stdio.h>
#include <stdlib.h>

void main()
{
    char str[100];
    int l = 0;

    printf("\n\nSeparate the individual characters from a string :\n");
    printf("------------------------------------------------------\n");
    printf("Input the string : ");
    fgets(str, sizeof str, stdin);
    printf("The characters of the string are : \n");
    while (str[l] != '\0')
    {
        printf("%c  ", str[l]);
        l++;
    }
    printf("\n");
}

S13.c
#include <stdio.h>
#include <string.h>

    int
    main()
{

    char S1[100], S2[100];
    fgets(S1, sizeof(S1), stdin);
    S1[strcspn(S1, "\n")] = '\0';
    fgets(S2, sizeof(S1), stdin);
    S2[strcspn(S2, "\n")] = '\0';

    int i = 0;
    while (S1[i] != '\0')
    {
        i++;
    }

    S1[i] = ' ';
    i++;

    int j = 0;
    while (S2[j] != '\0')
    {
        S1[i + j] = S2[j];
        j++;
    }

    S1[i + j] = '\0';

    puts(S1);
}
2.c
#include <stdio.h>
#include <string.h>

    typedef struct person
{
    char name[40];
    char fname[40];
    int age;
    float CGPA;
} PERSON;

int main()
{

    int n;
    scanf("%d", &n);
    // getchar();
    PERSON people[n];

    for (int i = 0; i < n; i++)
    {

        printf("Enter the value of person %d: \n", i + 1);
        printf("Name: ");
        char nameString[40], fnameString[40];

        fgets(nameString, sizeof(nameString), stdin);
        nameString[strcspn(nameString, "\n")] = '\0';
        strcpy(people[i].name, nameString);

        printf("Age: ");
        scanf("%d", &people[i].age);

        printf("CGPA: ");
        scanf("%f", &people[i].CGPA);
        getchar();

        printf("Father name: ");
        fgets(fnameString, sizeof(fnameString), stdin);
        fnameString[strcspn(fnameString, "\n")] = '\0';
        strcpy(people[i].fname, fnameString);
    }

    for (int i = 0; i < n; i++)
    {
        printf("\nPerson No. %d", i + 1);
        printf("\nName: %s", people[i].name);
        printf("\nFather name: %s", people[i].fname);
        printf("\nAge: %d", people[i].age);
        printf("\nCGPA: %.3f", people[i].CGPA);
        printf("\n");
    }

    return 0;
}

#include <stdio.h>

int main()
{
    int x, temp, sum = 0;
    scanf("%d", &x);

    for (int i = 0; i < x; i++)
    {
        scanf("%d", &temp);
        sum += temp;
        printf("Sum: %d| Average: %.2f\n", sum, ((float)sum / x));
    }
    /*
    int i =0 ;
    while(i<x)
    {
        scanf("%d",&temp );
        sum += temp;

        i++;
    }

    int i =0 ;
    do
    {
        scanf("%d",&temp );
        sum += temp;

        i++;
    }while(i<x);

    printf("Sum: %d| Average: %.2f", sum, ((float)sum/x));
    */

    return 0;
}

#include <stdio.h>
#include <ctype.h>

int main()
{
    int num;
    scanf("%d", &num);

    int rev = 0;
    int n = num;

    while (n != 0)
    {
        int digit = n % 10;
        rev = rev * 10 + digit;
        n = n / 10;
    }

    // printf("Reverse : %d", rev);

    if (num == rev)
    {
        printf("%d is a Palindrome Number", num);
    }
    else
    {
        printf("%d is not a Palindrome Number", num);
    }

    return 0;
}
