#include<stdio.h>
int main()
{
    int num1,num2,temp;
    printf("Input 1st number:");
    scanf("%d",&num1);
    printf("Input 2nd number:");
    scanf("%d",&num2);

    temp=num1;
    num1=num2;
    num2=temp;

    printf("After swaping 1st number is:%d\n",num1);
    printf("After swaping 2nd number is:%d",num2);

    return 0;
}