#include<stdio.h>
int main()
{
    int n, i, j, k, a=0;
    int count=0;
    printf("Enter the size:");
    scanf("%d", &n);
    if(n==2){
        a=1;
    }
    else if(n>=3){
        for(int t=3; t<n; t++){
            count++;
        }
        a=n+count;
    }
    
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=i; j++){
            printf("%d",j);
        }
        for(k=1; k<=a; k++){
            printf("_");
        }

        if(i<n){
            for(int l=i; l>=1; l--){
                printf("%d",l);
            }
        }
        else{
            for(int l=i-1; l>=1; l--){
                printf("%d",l);
            }
        }
        a-=2;
        printf("\n");
    }
    
return 0;

}