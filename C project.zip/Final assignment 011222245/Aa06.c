#include<stdio.h>
int main()
{
   int x,y,p,i,a;
   printf("choice a number:");
   scanf("%d",&x);
   printf("total count:");
   scanf("%d",&y);
   printf("gusess the number:");
   a=y;
   for(i=1;i<=y;i++){
       scanf("%d",&p);
       if(x==p){
           printf("Right,Player-2 wins!");
           break;
       }
       else if(x!=p && a>1){
           printf("Wrong,%dChoice(s) Left!\n",a=a-1);
       }
       else{
           printf("Player-1 wins!");
       }
   }
   return 0;
}