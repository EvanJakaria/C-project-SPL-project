#include<stdio.h>
int main()
{
    int n, i, j, k, a = 0;
    printf("Enter an odd number:");
    scanf("%d", &n);
    for(i = 1; i <= n/2; i++)
    {
        if(i == 1)
        {
            for(j = n/2; j >= i; j--)
                printf("_");
            printf("$");
            for(j = n/2; j >= i; j--)
                printf("_");
        }
        if(i > 1)
        {
            for(j = n/2; j >= i; j--)
                printf("_");
            printf("$");
            for(k = a; k >= 1; k--)
                printf("_");
            printf("$");
            for(k = a; k >= 1; k--)
                printf("_");
            printf("$");
            for(j = n/2; j >= i; j--)
                printf("_");
            a++;
        }
        printf("\n");
    }
    for(i = 1; i <= n; i++)
        printf("$");
    printf("\n");
    for(i = 1; i <= n/2; i++)
    {
        if(i != n/2)
        {
            for(j = 1; j <= i; j++)
                printf("_");
            printf("$");
            for(k = n/2 - 2; k >= i; k--)
                printf("_");
            printf("$");
            for(k = n/2 - 2; k >= i; k--)
                printf("_");
            printf("$");
            for(j = 1; j <= i; j++)
                printf("_");
        }
        if(i == n/2)
        {
            for(j = 1; j <= i; j++)
                printf("_");
            printf("$");
            for(j = 1; j <= i; j++)
                printf("_");
        }
        printf("\n");
    }
    return 0;
}
