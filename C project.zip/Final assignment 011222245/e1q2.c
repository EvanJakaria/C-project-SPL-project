#include<stdio.h>
int main()
{
    int num,i,flag=0;

    scanf("%d",&num);

    for(i=1;i<=num;i++){
        printf("%d",i);
        if(i%2!=0 && i<num){
            printf("X");
            flag++;
        }
        else{
            if(flag==1 && i<num){
                printf("-");
            }
            else if(i<num){
                printf("+");
                flag=0;
            }
        }
    }

    return 0;
}