#include <stdio.h>
int main() {
    int n,i,j,k,l;
    scanf("%d",&n);
    
    for(i=1;i<=n/2+1;i++){
        for(j=1;j<=n;j++){
            if(j==i || j==n-i+1){
                printf("* ");
            }
            else
            printf("  ");
        }
        printf("\n");
    }
    for(int i=n/2+2;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(j==n/2+1){
                printf("* ");
            }
            else
            printf("  ");
        }
        printf("\n");
    }

    return 0;
}