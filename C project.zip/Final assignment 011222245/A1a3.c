#include<stdio.h>
int main()
{
    int fact,result=1;
    printf("Enter the number of factorial:");
    scanf("%d",&fact);
    while(fact>0){
        result=result*fact;
        fact--;
    }
    printf("%d",result);
    return 0;
}