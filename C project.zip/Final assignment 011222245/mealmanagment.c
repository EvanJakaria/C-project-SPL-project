#include <stdio.h>
int main()
{
    int mahbub_deposit, habib_deposit, sakib_deposit, shojib_deposit, chomok_dposit;
    float mahbub_meal, habib_meal, sakib_meal, shojib_meal, chomok_meal;
    float total_meal, total_deposit, total_expense, per_meal_expense;
    float mahbub_cal, habib_cal, sakib_cal, shojib_cal, chomok_cal;

    printf("\n\tDeposit per Member\n");

    printf("Mahbub:");
    scanf("%d", &mahbub_deposit);
    printf("Habib:");
    scanf("%d", &habib_deposit);
    printf("Sakib:");
    scanf("%d", &sakib_deposit);
    printf("Shojib:");
    scanf("%d", &shojib_deposit);
    printf("Chomok:");
    scanf("%d", &chomok_dposit);

    printf("\n\tEaten meal per Member\n");

    printf("Mahbub:");
    scanf("%f", &mahbub_meal);
    printf("Habib:");
    scanf("%f", &habib_meal);
    printf("Sakib:");
    scanf("%f", &sakib_meal);
    printf("Shojib:");
    scanf("%f", &shojib_meal);
    printf("Chomok:");
    scanf("%f", &chomok_meal);

    total_meal = mahbub_meal + habib_meal + sakib_meal + shojib_meal + chomok_meal;
    total_deposit = mahbub_deposit + habib_deposit + sakib_deposit + shojib_deposit + chomok_dposit;

    printf("\nTotal meal count:%f\n", total_meal);
    printf("Total deposit:%f\n", total_deposit);

    printf("Total_expense:");
    scanf("%f", &total_expense);

    per_meal_expense = total_expense / total_meal;
    printf("Per meal expense:%f\n", per_meal_expense);

    printf("\n\tExpense per person\n");
    printf("Mahbub:%f\n", per_meal_expense * mahbub_meal);
    printf("Habib:%f\n", per_meal_expense * habib_meal);
    printf("Sakib:%f\n", per_meal_expense * sakib_meal);
    printf("Shojib:%f\n", per_meal_expense * shojib_meal);
    printf("chomok:%f\n", per_meal_expense * chomok_meal);

    mahbub_cal = mahbub_deposit - (per_meal_expense * mahbub_meal);
    habib_cal = habib_deposit - (per_meal_expense * habib_meal);
    sakib_cal = sakib_deposit - (per_meal_expense * sakib_meal);
    shojib_cal = shojib_deposit - (per_meal_expense * shojib_meal);
    chomok_cal = chomok_dposit - (per_meal_expense * chomok_meal);

    printf("\n\tFilal calculations\n");

    if (mahbub_cal > 0)
    {
        printf("Mahbub will get:%f\n", mahbub_cal);
    }
    if (mahbub_cal < 0)
    {
        printf("Mahbub have to pay:%f\n", mahbub_cal);
    }

    if (habib_cal > 0)
    {
        printf("Habib will get:%f\n", habib_cal);
    }
    if (habib_cal < 0)
    {
        printf("Habib have to pay:%f\n", habib_cal);
    }

    if (sakib_cal > 0)
    {
        printf("Sakib will get:%f\n", sakib_cal);
    }
    if (sakib_cal < 0)
    {
        printf("Sakib have to pay:%f\n", sakib_cal);
    }

    if (shojib_cal > 0)
    {
        printf("Shojib will get:%f\n", shojib_cal);
    }
    if (shojib_cal < 0)
    {
        printf("Shojib have to pay:%f\n", shojib_cal);
    }

    if (chomok_cal > 0)
    {
        printf("Chomok will get:%f\n", chomok_cal);
    }
    if (chomok_cal < 0)
    {
        printf("Chomok have to pay:%f\n", chomok_cal);
    }

    printf("\n\tAbout Manager\n");

    if (per_meal_expense <= 30)
    {
        printf("  Manager is a good guy");
    }
    if (per_meal_expense > 30)
    {
        printf("  Manager is a chudir vai");
    }

    return 0;
}