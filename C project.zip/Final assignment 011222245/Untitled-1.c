#include<stdio.h>
int main()
{
    int num,num2,num3,temp,temp2,sum,sum2=0,temp3,sum3=0,count=0;
    printf("Enter a number:");
    scanf("%d",&num);
    num2=num;
    num3=num;

    while(num!=0){
        temp=num%10;
        num=num/10;
        break;
    }

    while(num2!=0){
        temp2=num2%10;
        sum2=sum2+temp2;
        num2=num2/10;
        count++;
    }

    while(num3!=0){
        temp3=num3%10;
        sum3=sum3+temp3;
        if(count%2==0){
            sum3=sum3+temp3;
        }
        count--;
        num3=num3/10;
    }
    sum=temp+temp2;

    if(sum<11 && sum2/5 && sum3/3){
        printf("venus number");
    }

    else{
        printf("not");
    }

  return 0;
}