#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
  	char str[1000], result;
  	int i, len;
  	int max = -1;
  	
  	int freq[500] = {0}; 
 
  	printf("Write the String :  ");
  	fgets(str,sizeof(str),stdin);
  	
  	len = strlen(str);
  	
  	for(i = 0; i < len; i++)
  	{
  		freq[str[i]]++;
	}
  		
  	for(i = 0; i < len; i++)
  	{
		if(max < freq[str[i]])
		{
			max = freq[str[i]];
			result = str[i];
		}
	}
	printf("The Maximum Occurring Character is = %c (or %c)", toupper(result),result);
	
  	return 0;
}