#include<stdio.h>
int main()
{
    int n,temp;
    printf("Enter the number:");
    scanf("%d",&n);
    for(temp=0;n!=0;n/=10){
        temp*=10;
        temp=temp+n%10;
    }
    printf("reversed number is:%d",temp);

    return 0;
}