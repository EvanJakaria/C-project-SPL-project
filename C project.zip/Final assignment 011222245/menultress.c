#include <stdio.h>

int main() {
    int sum=0,num,i,temp=0;
    scanf("%d",&num);
    for(i=1;i<=num;i++){
        temp=temp+2;
        sum=sum+temp;
    }
    
    printf("%d",sum);

    return 0;
} 