#include<stdio.h>
#include<math.h>
int main()
{
    int n;

    printf("Enter the array size:");
    scanf("%d",&n);

    int m=sqrt(n);

    int arr[n];
    int arr2[m][m];
    
    printf("Enter the array elements: \n");
    for(int i=0; i<n; i++)
    {
        scanf("%d",&arr[i]);
    }
    
    printf("\n");
    
    int l=0;
    for(int j=0; j<m; j++)
    {
        for(int k=0; k<m; k++)
        {
            arr2[j][k]=arr[l];
            printf("%d ",arr2[j][k]);
            l++;
        }
        printf("\n");
    }
    
    return 0;
}