#include <stdio.h>
int main()  
{  
    int a,b,c,sum;  

    printf("Input three angles: ");  
    scanf("%d %d %d", &a,&b,&c);  
    sum = a+b+c;   
    if(sum == 180){  
        printf("It is a valid triangle\n");  
    }  
    else{  
        printf("It is a invalid triangle\n");  
    }  
    return 0;
}