#include <stdio.h>

//function prototype
int isPrime(int num);
void range(int lower, int upper);      //prime number giving in range

int main()
{
    int lower, upper;

    printf("Enter the lower and upper limit to list primes: ");        //okay
    scanf("%d%d", &lower, &upper);

    printPrimes(lower, upper);

    return 0;
}
 //function for  range
void range(int lower, int upper)
{
    printf("List of prime numbers between %d to %d are: ", lower, upper);

    while(lower <= upper)
    {

        if(isPrime(lower))
        {
            printf("%d ", lower);
        }

        lower++;
    }
}

//function for prime
int isPrime(int num)
{
    int i;

    for(i=2; i<=num/2; i++)
    {

        if(num % i == 0)
        {
            return 0;
        }
    }

    return 1;
}

