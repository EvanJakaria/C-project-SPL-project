#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter three differnet numbers:");
    scanf("%d %d %d",&a,&b,&c);
    
    if(a>b && a>c){
        printf("%d is max number from three numbers",a);
        }

    else if(b>a && b>c){
            printf("%d is max number from three numbers",b);
        }
    
    else{
        printf("%d is max number from three numbers",c);
    }

  return 0;
}