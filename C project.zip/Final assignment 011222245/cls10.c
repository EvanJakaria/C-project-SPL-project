/*
5
5 4 3 2 1

3
3 2 1
*/

#include <stdio.h>

int main()
{
    // user input
    //  int n;
    //  scanf("%d",&n);
    int r1, r2;
    scanf("%d %d", &r1, &r2);

    for (int k = r1; k <= r2; k++)
    {
        // if (k % 2 == 0)
        // {
        //     int fac = 1;
        //     printf("%d ! = ", k);
        //     for (int i = k; i >= 1; i--)
        //     {
        //         // i ---- > 5 4 3 2 1
        //         printf("%d", i);
        //         if (i > 1)
        //             printf(" X ");
        //         // //factorial calculation
        //         fac = fac * i;
        //     }
        //     printf(" = %d\n", fac);
        // }
        if (k % 2 != 0)
            break;
        int fac = 1;
        printf("%d ! = ", k);
        int i = k;
        while (i >= 1)
        {
            printf("%d", i);
            if (i > 1)
                printf(" X ");
            // //factorial calculation
            fac = fac * i;
            i--;
        }
        // for (int i = k; i >= 1; i--)
        // {
        //     // i ---- > 5 4 3 2 1
        //     printf("%d", i);
        //     if (i > 1)
        //         printf(" X ");
        //     // //factorial calculation
        //     fac = fac * i;
        // }

        printf(" = %d\n", fac);
    }

    return 0;
}
