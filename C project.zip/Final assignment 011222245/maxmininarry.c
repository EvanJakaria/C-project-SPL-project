#include<stdio.h>
int main()
{
    int x[5]={0,-12,3,1,9};
    int min=x[0];
    int max=x[0];

    for(int i=1;i<=4;i++){
                                                                //scanf("%d",&x[i]);
                                                                //printf("value:%d\n",x[i]);
                                                                //num=x[i];
        if(min>x[i]){
            min=x[i];
        }
        if(max<x[i]){
            max=x[i];
        }  

    }
    printf("minimum value of this array is:%d\n",min);
    printf("maximum value of this array is:%d",max);

    return 0;

}