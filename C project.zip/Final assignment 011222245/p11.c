#include <stdio.h>
int main()
{
    int *a, b, c, d;
    b = 7;
    c = 4;
    d = 2;

    a = &c;
    c = d;
    a = &b;
    printf("Number is: %d\n", c);
    printf("Number is: %d", *a);

    return 0;
}