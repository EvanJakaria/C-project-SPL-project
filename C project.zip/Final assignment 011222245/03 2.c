#include<stdio.h>
int main()
{
    int a,x;
    printf("enter the number:");
    scanf("%d",&a);

    while(a!=0){
        x=a%10;
        printf("%d",x);
        a=a/10;
    }
    return 0;
}