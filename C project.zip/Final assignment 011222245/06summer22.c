#include <stdio.h>
#include <string.h>
int main()
{
    int n = 2245 % 11 + 30;
    char str_a[31] = "Jakaria Molla, 011222245";
    // char str_b[];
    char str_b[1] = {"0"};
    int c = 0;
    // printf("%d", n);

    gets(str_a);
    // puts(str_a);
    int i = 0;
    while (str_a[i] != '\0')
    {
        // if (str_a[i] == 48 || str_a[i] == 49 || str_a[i] == 50 || str_a[i] == 51 || str_a[i] == 52 || str_a[i] == 53 || str_a[i] == 54 || str_a[i] == 55 || str_a[i] == 56 || str_a[i] == 57)

        if (str_a[i] >= '0' && str_a[i] <= '9')
        {
            str_b[c] = str_a[i];
            c++;
        }
        i++;
    }
    if (c == 0)
    {
        c++;
    }
    str_b[c] = '\0';

    puts(str_b);
}