#include<stdio.h>
int main()
{
    int n, r, n1 = 1, r1 = 1, n3,n_r = 1, result, i;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    printf("Enter the value of r: ");
    scanf("%d", &r);
    for(i = 1; i <= n; i++)
    {
        n1 *= i;
    }
    for(i = 1; i <= r; i++)
    {
        r1 *= i;
    }
    n3 = n - r;
    for(i = 1; i <= n3; i++)
    {
        n_r *= i;
    }
    result = n1 / (r1 * n_r);
    printf("%d", result);
    return 0;
}