#include<stdio.h>

int main(){
    int n;
    scanf("%d",&n); //964
    // int rev = 0;
    int sum =0;
    int i = n;
    while(i!=0){
        int rem = i%10; //9 6 4
        printf(" %d ",rem);
        sum+=rem; // 9 15 19
        // rev = (rev*10) + rem;
        i=i/10; // 76 7 0
    }

    if(sum%19==0) printf("Joker Number");
    else printf("Not Joker Number");
    // printf("\n%d",rev);


    return 0;
}
