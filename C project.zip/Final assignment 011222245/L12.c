#include<stdio.h>
int main()
{
    int n,temp=0;

    printf("Enter your number:");
    scanf("%d",&n);
    while(n!=0){
        temp*=10;
        temp=temp+n%10;
        n/=10;
    }

    printf("reversed number is:%d",temp);

    return 0;
}