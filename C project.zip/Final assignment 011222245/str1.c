#include <stdio.h>
int main() {

     char str[40];
     gets(str);
     printf("%s",str);
     return 0;


}
