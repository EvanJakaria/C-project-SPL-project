#include<stdio.h>


int rfunc1(int a, int mul){
    static int sum = 0;
    printf("I am func(%d). My Sum is %d\n",a, sum);
    // BASE CALL

    int chk;
    if(a==1){
        // printf("Base Call Activated. Ending rfunc(%d)\n", a);
        mul = a;
        //printf("%d",a);
        return mul;
    }
    // RECURSIVE CALL
    chk = rfunc1(a-1, 0);

    if(a%2==0){
        mul = chk * a;
        printf("Mul is %d\n", mul);
        sum += mul;
        //printf(" * %d",a);
    }
    else{
        mul = a;
        printf("Mul is %d\n", mul);
        //printf(" + %d",a);
    }
    printf("This is SUM : %d\n", sum);
    printf("Ending rfunc(%d)\n", a);
    return mul;

}

/*
5
1 2 3 4 5

*/

int main(){

    int n;
    scanf("%d", &n);
    rfunc1(n, 0);
    // if(n%2==0) printf(" = %d", sum);
    // else printf(" = %d", sum+n);
}
