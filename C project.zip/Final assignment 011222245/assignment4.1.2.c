#include <stdio.h>
int main() {
    int counter,n,count=0;
    for(counter=1;counter<=5;counter++)
    {
        scanf("%d",&n);
        if(n%2==0)
            count++;
    }

         printf("%d valores pares\n",count);


        return 0;


}
