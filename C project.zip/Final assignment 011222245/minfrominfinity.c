#include<stdio.h>
int main()
{
    int a,d,i,n;
    printf("How many numbers do you need?\nans:");
    scanf("%d",&n);
    printf("please enter %d numbers:\n",n);
    scanf("%d",&d);
    for(i=1;i<=n-1;i++){
        scanf("%d",&a);
        if(d>a){
            d=a;  
        }
    
    }
  printf("%d is small number",d);

    return 0;
}