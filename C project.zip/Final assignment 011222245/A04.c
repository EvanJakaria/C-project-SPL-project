#include<stdio.h>
int main()
{
   int a,i;
   float input,avg,sum=0;
   printf("Enter a number:");
   scanf("%d",&a);
   for(i=1;i<=a;i++){
       scanf("%f",&input);
       sum=sum+input;
   }
   avg=sum/a;
   printf("AVG of %d inputs:%f",a,avg);
   return 0;
}
