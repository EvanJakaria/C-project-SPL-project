#include<stdio.h>
int main()
{
    int a;  //a) Declare a variable uninitialized
    int b = 5;  //b) Declare and  initialize a variable in one statement
    int c = 2, d = 3, e = 4; //c) Declare and initialize multiple variables with different values in one statement
    int f = 6, g = 6; //d) Declare and initialize multiple variables with the same value in one statement
    return 0;
}
