#include <stdio.h>
int main() {
    //swapping two strings
     char str1[20]="shayan";
     char str2[20]="nabil";
     char dupt[20];
     strcpy(dupt,str1);
     strcpy(str1,str2);
     strcpy(str2,dupt);
     printf("%s\n %s",str1,str2);



   return 0;
}
