#include<stdio.h>
int main()
{
    int num1,num2,add,sub,mul,mod;
    float div;
    printf("Input 1st number:");
    scanf("%d",&num1);
    printf("Input 2nd number:");
    scanf("%d",&num2);

    printf("sum is:%d\n",num1+num2);
    printf("subtraction is:%d\n",num1-num2);
    printf("multiplie is:%d\n",num1*num2);
    printf("division is:%.2f\n",(float)num1/num2);
    printf("modulus is:%d\n",num1%num2);

    return 0;
}