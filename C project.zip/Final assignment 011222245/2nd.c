
#include <stdio.h>
int main(){
    // S - 1 : var dec.
    int x,y;
    // S - 2 : take input
    printf("enter the 1st number : ");
    scanf("%d",&x);
    printf("enter the 2nd number : ");
    scanf("%d",&y);


    // S -3 : calculation
    if(x>y){
       printf("max = %d",x);
    }
    else if(y>x){
       printf("max = %d",y);

    }



    return 0;
}
