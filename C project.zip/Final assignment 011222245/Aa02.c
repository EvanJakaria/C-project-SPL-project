#include<stdio.h>
int main()
{
   int a,i,n=1;
   printf("Enter a number:");
   scanf("%d",&a);
   for(i=1;i<=a;i++){
       printf("%d",n);
       n=n+2;
       if(i<a){
        printf(",");
       }
   }
   return 0;
}
