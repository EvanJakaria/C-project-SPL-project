#include <stdio.h>
#include<string.h>
int main() 
{
    char a[1000];
    
    printf("Write the string: ");
    fgets(a,sizeof(a),stdin);

    int sum=0;
    int i=0;
    while(a[i]!='\0')
    {
        if(a[i]=='0' || a[i]=='1' || a[i]=='2' || a[i]=='3' || a[i]=='4' || a[i]=='5' || a[i]=='6' || a[i]=='7' || a[i]=='8' || a[i]=='9')
        {
            
            sum+=a[i]-48;
        }
        i++;
    }
    
    printf("sum is: %d",sum);
    
    return 0;
}