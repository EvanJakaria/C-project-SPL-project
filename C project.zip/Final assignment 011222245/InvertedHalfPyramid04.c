#include<stdio.h>
int main()
{
/*
    * * * 
    * * 
    *  
*/
    int i,j;
    int m;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=1;i<=m;i++){
        for(j=m;j>=i;j--){

            printf("* ");
        }
        printf("\n");
    }

    return 0;
}