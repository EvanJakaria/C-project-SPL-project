#include<stdio.h>
#include<string.h>
int main()
{
    FILE *file;
    
    char name[1000];
    printf("Write the string: ");
    fgets(name,sizeof(name),stdin);
    name[strcspn(name,"\n")]='\0';

    file = fopen("test.txt","w");

    if(file==NULL)
    {
        printf("File doesn't exist.");
    }
    else
    {
        printf("File is opened");

        // for(int i=0; i<strlen(name); i++)
        // {
        //     fputc(name[i],file);
        // }

        fputs(name,file);
        fputs("\n",file);
        printf("\nFile is  written successfully.");
        
        fclose(file);
    }

    getchar();
}