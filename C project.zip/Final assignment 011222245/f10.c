#include <stdio.h>

int Perfect(int num);
void printALLPerfect(int start, int end);     //perfect number between giving interval



int main()
{
    int start, end;


    printf("Enter lower limit to print perfect numbers: ");
    scanf("%d", &start);
    printf("Enter upper limit to print perfect numbers: ");
    scanf("%d", &end);

    printf("All perfect numbers between %d to %d are: \n", start, end);              //okay
    printALLPerfect(start, end);

    return 0;
}

//function for perfect number
int Perfect(int num)
{
    int i, sum;


    sum = 0;
    for(i=1; i<num; i++)
    {
        if(num % i == 0)
        {
            sum += i;
        }
    }


    if(sum == num)
        return 1;
    else
        return 0;
}

//for printing all perfect number
void printALLPerfect(int start, int end)
{

    while(start <= end)
    {
        if(Perfect(start))
        {
            printf("%d ", start);
        }

        start++;
    }
}
