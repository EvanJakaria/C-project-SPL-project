#include<stdio.h>
int main()
{
    int days,year,week;
    printf("please enter days:");
    scanf("%d",&days);

    year = days / 365;
    week = (days % 365)/7;
    days = days - ((year*365)+(week * 7));

    printf("Year is: %d\n", year);
    printf("Weeks is: %d\n", week);
    printf("Days is: %d", days);

    return 0;
}