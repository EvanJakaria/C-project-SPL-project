#include<stdio.h>
int main()
{
    float num1,num2;
    printf("Input 1st number:");
    scanf("%f",&num1);
    printf("Input 2nd number:");
    scanf("%f",&num2);

    printf("%f X %f = %f",num1,num2,num1*num2);

    return 0;
}