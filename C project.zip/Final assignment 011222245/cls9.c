#include<stdio.h>

int main(){
    int n;
    scanf("%d",&n);
    int array[100];
    int i = n;
    int k = 0;
    while(i!=0){
        int rem = i%10;
        array[k] = rem;
        k++;
        i=i/10; // 76 7 0
    }
    i = 1;
    for(int j = k-1; j>=0;j--){
        printf("Digit No. %d = %d\n",i,array[j]);
        i++;
    }
    return 0;
}
