#include<stdio.h>
int main(){
    int a,i,j;
    printf("Enter the value of size:");
    scanf("%d",&a);

    for(i=1;i<=a;i++){
        for(j=1;j<=a;j++){
            if(i==j || j==a-i+1){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }
        printf("\n");
    }
    return 0;
}