#include<stdio.h>
int main()
{
    int student[5],course[4];
    int sum,count,count2;

    for(int i=0;i<5;i++){

        printf("Marks of the student-%d is:\n",i+1);
        sum=0;
        for(int j=0;j<4;j++){
            printf("mark of the course %d is:",j+1);
            scanf("%d",&course[j]);
            sum+=course[j];
        }
        student[i]=sum;
    }

    for(int i=0;i<5;i++){
        printf("student%d total number is:%d\n",i+1,student[i]);
    }

    int max=student[0];

    for(int i=0;i<5;i++){
        if(max<student[i]){
            max=student[i];//maximum number;
        }
        if(student[i]==max){
            count=i+1;
            count2=i;//index number;
        }
    }

    printf("Maximum number of result is:%d\n",max);
    printf("Student-%d holds the 1st position and her index number is:%d",count,count2);

    return 0;
}