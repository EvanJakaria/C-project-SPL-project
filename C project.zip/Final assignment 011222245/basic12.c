
#include <stdio.h>
int main() {
    int s,area=0;

    printf("side:");
    scanf("%d",&s);

    area=s*s;
    printf("area of square:%d",area);

    return 0;


}
