#include<stdio.h>
int main()
{
    int a,i,j=2,result=0;
    printf("Enter the value:");
    scanf("%d",&a);
    for(i=1;i<=a;i++){
        result=result+i*i*j;
        j++;
    }
    printf("%d",result);
    return 0;
}