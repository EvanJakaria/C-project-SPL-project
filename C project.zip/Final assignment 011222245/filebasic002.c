#include<stdio.h>
#include<string.h>
int main()
{
    FILE *file;
    file = fopen("test.txt","a");

    int num;
    char arr[1000];

    if(file==NULL)
    {
        printf("File is not exist");
    }

    else
    {
        printf("\t\t\t\tFile is opend");

        printf("\nWrite your Name: ");
        fgets(arr,sizeof(arr),stdin);
        arr[strcspn(arr,"\n")]='\0';

        printf("Enter your Age: ");
        scanf("%d",&num);



        fprintf(file,"Name: %s \nAge: %d\n\n",arr,num);

        printf("\nFile is written successfully");

        fclose(file);
    }

    getchar();
}