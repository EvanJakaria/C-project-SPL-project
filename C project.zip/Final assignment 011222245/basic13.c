
#include <stdio.h>
int main() {
    int l,b,area=0;

    printf("length:");
    scanf("%d",&l);
    printf("breadth:");
    scanf("%d",&b);
    area=(l*b);
    printf("area of rectangle:%d",area);

    return 0;


}
