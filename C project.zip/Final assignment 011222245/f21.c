#include <stdio.h>
#include <math.h>

//function prototype
int reverse(int num);         //is palindrome
int palindrome(int num);



int main()
{
    int num;


    printf("Enter any number: ");
    scanf("%d", &num);

    if(Palindrome(num) == 1)
    {
        printf("%d is palindrome number.\n", num);             //okay
    }
    else
    {
        printf("%d is NOT palindrome number.\n", num);
    }

    return 0;
}

//recursion for palindrome
int Palindrome(int num)
{

    if(num == reverse(num))
    {
        return 1;
    }

    return 0;
}

//recursion for reverse a number
int reverse(int num)
{

    int digit = (int)log10(num);


    if(num == 0)
        return 0;

    return ((num%10 * pow(10, digit)) + reverse(num/10));
}
