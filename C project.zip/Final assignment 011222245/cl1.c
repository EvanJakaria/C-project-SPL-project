#include <stdio.h>
#include <math.h>
// int pow ( int n, int r){
//     for(i=0;i<r;)
// }
int main()
{
    int r1, r2;
    scanf("%d %d", &r1, &r2);

    for (int k = r1; k < r2; k++)
    {
        int n = k;
        int sum = 0;
        int noofDigits = 0;
        int i = n;
        while (i != 0)
        {
            int rem = i % 10; // 9 6 4
            noofDigits++;
            i = i / 10; // 76 7 0
        }
        // printf("%d\n", noofDigits);
        if (noofDigits > 1)
        {
            i = n;
            while (i != 0)
            {
                int rem = i % 10; // 9 6 4
                sum += pow(rem, noofDigits);
                i = i / 10; // 76 7 0
            }
            if (sum == n)
                printf(" %d ", n);
        }
        // else
        //     printf("Not Armstrong Number");
    }
    //1 2 3 4 5 6 7 8 9 370 371 407 1634 8208 9474 return 0;
}
