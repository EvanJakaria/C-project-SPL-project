#include <stdio.h>
#include <string.h>
int main()
{
    char a[100], b[100], c[100];

    gets(a);
    scanf("%s", b);

    strncpy(c, a, 8);
    strncat(b, c, 4);
    strcpy(c, b);
    strncat(c, a, 3);

    if (strcmp(b, c) > 0)
        strncpy(a, c, 2);
    else
        strncpy(b, c, 2);

    puts(a);
    puts(b);
    puts(c);
}