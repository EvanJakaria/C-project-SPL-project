#include <stdio.h>
int main() 
{
    /*
    6 4 2
    4 2
    2
*/
    int i,j,k;
    int m;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=m;i>0;i--){
        for(j=i;j>0;j--){
            printf("%d ",i);
        }
        printf("\n");
    }

    return 0;
}