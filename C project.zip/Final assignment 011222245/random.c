#include <stdio.h>
int main() {
char source[]="hello world";
char target[20];
strcpy(target,source);

printf("%s",source);
printf("%s",target);



    return 0;
}
