#include<stdio.h>
int main()
{
    int n,i,sum=0;

    printf("Enter the value of n:");
    scanf("%d",&n);

    for(i=2;i<=n;i+=2){
        sum+=i;
    }

    printf("sum is(even numbers of 1 to %d):%d",n,sum);

    return 0;
}