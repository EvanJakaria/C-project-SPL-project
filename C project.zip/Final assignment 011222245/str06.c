#include<stdio.h>
#include<string.h>
int main()
{
    char s[500];

    printf("Write the string: ");
    fgets(s,sizeof(s),stdin);
    s[strcspn(s,"\n")]='\0';

    for(int i=0; i <= strlen(s); i++)
    {
        if(s[i]>=97 && s[i]<=122)
        {
            s[i]=s[i]-32;
        }
    }

    puts(s);

    return 0;
}