
#include <stdio.h>
int main() {
    float c,f;;

    printf("celcius:");
    scanf("%f",&c);


    f=((9*c)/5)+32;
    printf("Farenheit:%f",f);

    return 0;


}
