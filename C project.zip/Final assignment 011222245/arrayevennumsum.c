#include<stdio.h>
int main()
{
    int size,sum=0;
    printf("Enter the size:");
    scanf("%d",&size);
    int n[size],i;
    for(i=0;i<size;i++){
        scanf("%d",&n[i]);
        if(n[i]%2==0){
            sum=sum+n[i];
        }
    }
    
    printf("%d",sum);
}