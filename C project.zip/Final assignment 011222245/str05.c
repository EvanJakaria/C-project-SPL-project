#include<stdio.h>
#include<string.h>
int main()
{
    char sentence1[500];
    char sentence2[500];

    printf("Write the sentence: ");
    fgets(sentence1,sizeof(sentence1),stdin);
    sentence1[strcspn(sentence1,"\n")]='\0';

    int count=0;
    for(int i=0; sentence1[i]!='\0'; i++)
    {
        count++;
    }

    for(int j=0; sentence1[j]!='\0'; j++)
    {
        sentence2[j]= sentence1[count-1-j];
    }

    puts(sentence2);
    
    return 0;
}