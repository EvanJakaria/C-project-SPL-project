#include <stdio.h>
#define MAX_SIZE 100

//function prototype
void Array(int arr[], int start, int len);      //print an array


int main()
{
    int arr[MAX_SIZE];
    int num, i;


    printf("Enter size of the array: ");
    scanf("%d", &num);
    printf("Enter elements in the array: ");         //okay
    for(i=0; i<num; i++)
    {
        scanf("%d", &arr[i]);
    }


    printf("Elements in the array: ");
    Array(arr, 0, num);

    return 0;
}

//recursion for declaring an ARRAY

void Array(int arr[], int start, int len)
{

    if(start >= len)
        return;


    printf("%d ", arr[start]);


    Array(arr, start + 1, len);
}
