#include<stdio.h>
int main()
{
    printf("Hello World.\nThis is my first program.\tC is fun.");
    return 0;
}
