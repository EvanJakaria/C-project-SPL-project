#include <stdio.h>
int main(){
    //variable dec:
    int n,counter;
    printf("Enter the number:");
    //take input:
    scanf("%d",&n);
    //calculation&print:

    for(counter=1;counter<=n;counter=counter+1)
    {
       if(counter%2==1)
       printf("1,");
       else
        printf("0,");
    }



      return 0;


}
