#include <stdio.h>
int main() 
{
    int size,i,j;
    
    printf("Enter the array size:");
    scanf("%d",&size);
    
    int arrA[size];
    int arrB[size];
    
    printf("Enter the Array Values:");
    for(i=0; i<size; i++){
        scanf("%d",&arrA[i]);
    }
    for(j=0; j<size; j++){
        arrB[j]=arrA[size-1-j];
    }

    printf("ArrayA:");
    for(i=0; i<size; i++){
        printf("%d ",arrA[i]);
    }

    printf("\n");

    printf("ArrayB:");
    for(j=0; j<size; j++){
        printf("%d ",arrB[j]);
    }
    
    
    return 0;
}