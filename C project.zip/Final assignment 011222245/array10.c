#include <stdio.h>
int main() 
{
    int n,n2;
    printf("Enter the array-A size:");
    scanf("%d",&n);
    printf("Enter the array-B size:");
    scanf("%d",&n2);
    int arr1[n],arr2[n2],temp[n];
    
    printf("Enter array-A values:");
    for(int i=0;i<n;i++){
        scanf("%d",&arr1[i]);
        temp[i]=arr1[i];
    }
    
    printf("Enter array-B values:");
    for(int i=0;i<n2;i++){
        scanf("%d",&arr2[i]);
    }
    
    printf("Array-A is:");
    for(int i=0;i<n2;i++){
        arr1[i]=arr2[i];
        printf("%d ",arr1[i]);
    }
    
    printf("\n");
    
    printf("Array-B is:");
    for(int i=0;i<n;i++){
        arr2[i]=temp[i];
        printf("%d ",arr2[i]);
    }
    
    return 0;
}