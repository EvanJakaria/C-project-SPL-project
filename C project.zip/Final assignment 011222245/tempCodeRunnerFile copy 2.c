while(!feof(file))
        // {
        // //     fgets(ch,2,file);
        // //     printf("%s",ch);
        //        fscanf(file,"%c",&ch);
        //        printf("%c",ch);
        // }