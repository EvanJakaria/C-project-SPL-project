#include <stdio.h>
#include <string.h>
int main()
{
    char a[50], b[50];
    int d;
    printf("Enter 2 strings:");
    gets(a);
    gets(b);

    if (strncmp(a, b, 3) == 0)
    {
        printf("%s is (alphabetically) equal to %s", a, b);
    }
    else if (strncmp(a, b, 3) > 0)
    {
        printf("%s is (alphabetically) greater than %s", b, a);
    }
    else if (strncmp(a, b, 3) < 0)
    {
        printf("%s is (alphabetically) less than %s", b, a);
    }
}