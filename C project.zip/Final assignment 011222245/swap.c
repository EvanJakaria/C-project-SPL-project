#include <stdio.h>
int main() {
    //s-1

    int a,b,c;

     //s-2

    printf("enter an integer number:");
    scanf("%d",&a);
    printf("enter an integer number:");
    scanf("%d",&b);
    //calculation
    c=a;
    a=b;
    b=c;

    //s-4
    printf("the number =%d",a);
    printf("\n");
    printf("the number = %d",b);



     return 0;




}
