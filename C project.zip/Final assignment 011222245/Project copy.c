#include <stdio.h>
#include <stdlib.h>
int main()
{
    int i;
    for (i = 1; i <= 10; i++)
    {
        int num;
        printf("\n   ***************************************************************************************************\n");
        printf("   ********************             UIU SPORTS MANAGEMENT SYSTEM               ***********************\n");
        printf("   ***************************************************************************************************\n");
        printf("\n\n                    1. Sports categories\n");
        printf("                    2. Instructions and schedule management\n");
        printf("                    3. Players Registration\n");
        printf("                    4. Admins Registration\n");
        printf("                    5. Players Registration Details\n");
        printf("                    6. Players Verification\n");
        printf("                    7. Stadium management\n");
        printf("                    8. Teams management\n");
        printf("                    9. Schedule management\n");
        printf("                    10. Kit management\n");
        printf("                    11. Competition management\n");
        printf("                    12. Prize distribution management\n\n");

        printf("Choose of your choice: ");
        scanf("%d", &num);

        FILE *fp1;
        FILE *fp2;
        FILE *fp5;
        FILE *fp6;
        FILE *fp7;
        FILE *fp8;
        FILE *fp9;
        FILE *fp10;
        FILE *fp12;

        char filename1[100], s;
        char filename2[100], i;
        char filename5[100], r;
        char filename6[100], d;
        char filename7[100], x, z;
        char filename8[100], t;
        char filename9[100], sc;
        char filename10[100], k;
        char filename12[100], p;

        int j, password, passcode;
        int pass, o;
        char sport, user;
        switch (num)
        {
        case 1:
            printf("Enter the filename to open the sports categories: ");
            scanf("%s", filename1);

            printf("\n             ***********************************\n");
            printf("             *******  SPORTS CATEGORIES  *******\n");
            printf("             ***********************************\n");
            fp1 = fopen(filename1, "r");

            if (fp1 == NULL)
            {
                printf("Cannot open file \n");

                exit(0);
            }
            s = fgetc(fp1);
            while (s != EOF)
            {
                printf("%c", s);

                s = fgetc(fp1);
            }
            break;
        case 2:
            printf("Enter the file name to open the instructions and schedule: ");
            scanf("%s", filename2);

            fp2 = fopen(filename2, "r");
            if (fp2 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            i = fgetc(fp2);
            while (i != EOF)
            {
                printf("%c", i);
                i = fgetc(fp2);
            }
            break;
        case 3:
            printf("User ID: ");
            scanf("%s", &z);
            printf("Password: ");
            scanf("%d", &pass);
            break;
        case 4:
            printf("Password: ");
            scanf("%d", &o);
            break;
        case 5:

            printf("Only the management staff can see the registration details of the students.\n");
            printf("If you are the staff member then use the password to open it.\n");
            printf("Password: ");
            scanf("%d", &password);

            if (password == o)
            {

                printf("\nYES. You are the staff member.\n");
                printf("So, enter the file name to open the registration details: ");
                scanf("%s", filename5);
                printf("\n");
                printf("\n");

                printf("            ****************************************\n");
                printf("            ********  REGISTRATION DETAILS  ********\n");
                printf("            ****************************************\n");

                fp5 = fopen(filename5, "r");

                if (fp5 == NULL)
                {
                    printf("Cannot open file \n");

                    exit(0);
                }

                r = fgetc(fp5);

                while (r != EOF)
                {
                    printf("%c", r);

                    r = fgetc(fp5);
                }
            }
            else
            {
                printf("Your not the staff member. So you can't see the registration details.");
            }

            break;
        case 6:

            printf("\nThe students can check their details by texting their userID and password!!\n");
            printf("User ID: ");
            scanf("%s", &user);
            printf("\nPassword: ");
            scanf("%d", &passcode);

            if (passcode == pass)
            {

                printf("By entering your file name and register number You can check ur details: ");

                scanf("%s", filename6);

                fp6 = fopen(filename6, "r");

                char d[100];

                int i = 0, b, j;

                scanf("%d", &b);

                printf("R.NO     NAME        D.OF BIRTH       PLACE          SPORT             D.OF.R       TEAM\n");

                while (fgets(d, sizeof(d), fp6))
                {

                    i++;

                    if (i == b)
                    {

                        printf("%s", d);
                    }
                }
            }

            else
            {
                printf("Sorry your userID or password is wrong.Please check the details again\n");
            }

            break;
        case 7:
            printf("Enter the filename to open the stadium management: ");
            scanf("%s", filename7);
            fp7 = fopen(filename7, "r");
            if (fp7 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            x = fgetc(fp7);
            while (x != EOF)
            {
                printf("%c", x);
                x = fgetc(fp7);
            }
            break;
        case 8:
            printf("\nEnter the filename to open the details of teams: ");
            scanf("%s", filename8);
            fp8 = fopen(filename8, "r");
            if (fp8 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            t = fgetc(fp8);
            while (t != EOF)
            {
                printf("%c", t);
                t = fgetc(fp8);
            }
            printf("\n");
            break;
        case 9:
            printf("\nEnter the filename to open the schedule: ");
            scanf("%s", filename9);
            fp9 = fopen(filename9, "r");
            if (fp9 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            sc = fgetc(fp9);
            while (sc != EOF)
            {
                printf("%c", sc);
                sc = fgetc(fp9);
            }
            break;
        case 10:
            printf("Enter the filename to open the kit management details: ");
            scanf("%s", filename10);
            fp10 = fopen(filename10, "r");
            if (fp10 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            k = fgetc(fp10);
            while (k != EOF)
            {
                printf("%c", k);
                k = fgetc(fp10);
            }
            break;
        case 11:
            printf("\nThe details of every sports has to be displayed: \n");
            printf("    c. CHESS\n");
            printf("    f. FOOTBALL\n");
            printf("    b. BADMINTON\n");
            printf("    k. CRICKET\n");
            printf("    t. TABLE TENNIS\n");
            printf("Choose the sport code to display the details: ");
            FILE *fp4, *fp5, *fp6, *fp7, *fp8;
            char g, p, q, r, s;
            int k;
            for (k = 1; k <= 10; k++)
            {
                scanf("%c", &sport);
                switch (sport)
                {
                case 'c':
                    fp4 = fopen("chess.txt", "r");
                    if (fp4 == NULL)
                    {
                        printf("Cannot open file \n");
                        exit(0);
                    }
                    g = fgetc(fp4);
                    while (g != EOF)
                    {
                        printf("%c", g);
                        g = fgetc(fp4);
                    }
                    fclose(fp4);
                    break;
                case 'b':
                    fp5 = fopen("badminton.txt", "r");
                    if (fp5 == NULL)
                    {
                        printf("Cannot open file \n");
                        exit(0);
                    }
                    p = fgetc(fp5);
                    while (p != EOF)
                    {
                        printf("%c", p);
                        p = fgetc(fp5);
                    }
                    fclose(fp5);
                    break;
                case 't':
                    fp6 = fopen("tennis.txt", "r");
                    if (fp6 == NULL)
                    {
                        printf("Cannot open file \n");
                        exit(0);
                    }
                    q = fgetc(fp6);
                    while (q != EOF)
                    {
                        printf("%c", q);
                        q = fgetc(fp6);
                    }
                    fclose(fp6);
                    break;
                case 'f':
                    fp7 = fopen("football.txt", "r");
                    if (fp7 == NULL)
                    {
                        printf("Cannot open file \n");
                        exit(0);
                    }
                    r = fgetc(fp7);
                    while (r != EOF)
                    {
                        printf("%c", r);
                        r = fgetc(fp7);
                    }
                    fclose(fp7);
                    break;
                case 'k':
                    fp8 = fopen("cricket.txt", "r");
                    if (fp8 == NULL)
                    {
                        printf("Cannot open file \n");
                        exit(0);
                    }
                    s = fgetc(fp8);
                    while (s != EOF)
                    {
                        printf("%c", s);
                        s = fgetc(fp8);
                    }
                    fclose(fp8);
                }
            }
            break;
        case 12:
            printf("\nEnter the filename to open prize distribution details: ");
            scanf("%s", filename12);
            fp12 = fopen(filename12, "r");
            if (fp12 == NULL)
            {
                printf("Cannot open file \n");
                exit(0);
            }
            p = fgetc(fp12);
            while (p != EOF)
            {
                printf("%c", p);
                p = fgetc(fp12);
            }
            fclose(fp12);
            break;
            fclose(fp9);
            fclose(fp8);
            fclose(fp6);
            fclose(fp5);
        }
    }
    return 0;
}