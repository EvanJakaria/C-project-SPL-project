#include<stdio.h>
int main()
{
   int a,i,n=0,n1=1,n2;
   printf("enter the value:");
   scanf("%d",&a);
   printf("%d ",n1);
   for(i=1;i<a;i++){
       n2=n+n1;
       printf("%d ",n2);
       n=n1;
       n1=n2;
   }
   return 0;
}