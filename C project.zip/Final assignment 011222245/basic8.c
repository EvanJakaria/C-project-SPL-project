
#include <stdio.h>
int main() {
    float c,f;;

    printf("farenheit:");
    scanf("%f",&f);


    c=(5*(f-32))/9;
    printf("celcius:%f",c);

    return 0;


}
