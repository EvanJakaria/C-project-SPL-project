#include<stdio.h>
int main()
{
/*
    6 4 2
    4 2
    2
*/
    int i,j;
    int m;
    printf("Enter row and colum size:");
    scanf("%d",&m);
    
    for(i=m;i>0;i--){
        for(j=i;j>0;j--){
            printf("%d ",j*2);
        }
        printf("\n");
    }

    return 0;
}
