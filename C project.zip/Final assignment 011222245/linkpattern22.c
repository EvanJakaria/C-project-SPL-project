#include<stdio.h> 
int main() 
{
   int i,j;
   char n, al= 'A';
   printf("Enter any uppercase character:");
   scanf("%c",&n);
   for (i=1; i<=(n-'A'+1); i++) {
      for (j=1; j<=i; j++) {
         printf("%c ",al);
      }
      al++;
      printf("\n");
   }
   
   return 0;
}