#include <stdio.h>
#include <ctype.h>
/*Venus Number:# Sum of the Digts is divisible by 5# Sum of the Even positioned Digits is divisible by 3# Sum of the Last and First Digit < 11*/
int main()
{
    int num, sum = 0, evenSum = 0;
    scanf("%d", &num);
    int digitCount = 0, fDigit, lDigit;
    int n = num;
    while (n != 0)
    {
        int digit = n % 10;
        if (n == num)
            lDigit = digit;

        digitCount++;
        n = n / 10;
        
        if (n == 0)
            fDigit = digit;
    }




    int position = digitCount;
    n = num;
    while (n != 0)
    {
        int digit = n % 10;
        sum += digit;
        if (position % 2 == 0)
        {
            evenSum += digit;
        }
        position--;
        n = n / 10;
    }

    if (sum % 5 == 0 && evenSum % 3 == 0 && fDigit+lDigit<11)
    {
        printf("Venus Number");
    }
    else
    {
        printf("Not Venus Number");
    }
    // printf("%d", sum);
    return 0;
}
