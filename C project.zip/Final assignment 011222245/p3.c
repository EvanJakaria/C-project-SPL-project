#include<stdio.h>
void getMinMax(int *A, int n, int *min, int *max)
{
    for(int i=0; i<n; i++)
    {
        if(max<A[i])
        {
            max=A[i];
        }
        if(min>A[i])
        {
            min=A[i];
        }
    }
    printf("\nMin: %d\nMax: %d",min,max);

}


int main()
{
    int n,max=0 , min=5;

    printf("Enter the size: ");
    scanf("%d",&n);
    int a[n];

    for(int i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }


   //printf("%d %d",max,min);

   getMinMax(a,n,min,max);
}

