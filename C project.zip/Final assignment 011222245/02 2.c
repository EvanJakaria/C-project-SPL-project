#include<stdio.h>
int main()
{
    int n;

    printf("Enter a number:");
    scanf("%d",&n);

    for(int i=3;i<=n*3;i=i+3){

        printf("%d ",i);
        if(i!=3*n){
            printf(",");
        }
    }

    return 0;
}