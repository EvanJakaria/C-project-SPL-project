#include <stdio.h>
int main() {
    float x,y;
    printf("enter an integer number");
    scanf("%f",&y);
    x=2+(5*y/10)+(2*y*y+3)-50;
    printf("the value of x is=%f",x);
    printf("\n");
    if (x>0)
    printf("x is positive.");
    else printf("x is negative.");


    return 0;
}
