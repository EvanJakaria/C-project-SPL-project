#include<stdio.h>
int main()
{
   char ch;
   int i=0,sum=0;
   while(1){
       scanf(" %c",&ch);
       i++;
       if(ch=='A')break;
       printf("Input %d: %c\n",i,ch);  
   }
   return 0;
}