#include<stdio.h>
int main()
{
    int size;
    printf("Enter the size:");
    scanf("%d",&size);
    int n[size],i;

    for(i=0; i<size; i++){
        scanf("%d",&n[i]);
    }
    int temp;


     for(i=0; i<size/2; i++){

        
        temp=n[i];
        n[i]=n[size-1-i];
        n[size-1-i]=temp;
    }
    for(i=0; i<size; i++){
        printf("%d",n[i]);
    }
    
    
    
}