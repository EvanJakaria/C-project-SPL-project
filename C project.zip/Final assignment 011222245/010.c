#include <stdio.h>
int main()
{
    char ch;
    printf("please enter a character: ");
    scanf("%c", &ch);
    printf("ascii value of %c = %d",ch,ch);
    return 0;
}