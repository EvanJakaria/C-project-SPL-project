#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter two numbers:");
    scanf("%d %d",&a,&b);

    printf("Addition of two integer is:%d",a+b);

    return 0;
}