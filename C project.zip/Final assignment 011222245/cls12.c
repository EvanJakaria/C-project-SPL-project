#include <stdio.h>

int main()
{
    int r1, r2;
    scanf("%d %d", &r1, &r2);

    for (int k = r1; k <= r2; k++)
    {
        int first_digit, last_digit;
        int sum = 0;
        int n = k;
        while (n != 0)
        {
            int rem = n % 10;
            sum += rem;
            if (n == k)
                last_digit = rem;
            n = n / 10;
            if (n == 0)
                first_digit = rem;
        }

        // printf("%d %d %d\n", first_digit, last_digit, sum);

        if (first_digit == 1 && last_digit == 1 && sum != 11 && (sum * sum) % 8 == 0)
            printf("%d ", k);
    }

    return 0;
}
