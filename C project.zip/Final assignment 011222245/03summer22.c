#include <stdio.h>
int main()
{
    FILE *file;

    int i, sum, a = 9;
    int num[] = {a, a % 10, a % 20, a % 30, a % 40};
    file = fopen("ques.txt", "w");
    fprintf(file, "%s\n", "Hello Vaxxers!");

    for (i = 4; i >= 0; i--)
    {
        fprintf(file, "%d\n", num[i]);
    }

    fclose(file);
    // if (file == NULL)
    // {
    //     printf("File doesn't exist.");
    // }
    // else
    // {
    //     printf("File is opened.");
    //     fclose(file);
    // }
    // getchar();
}