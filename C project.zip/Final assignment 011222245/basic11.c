
#include <stdio.h>
int main() {
    float r,area=0;

    printf("radius:");
    scanf("%f",&r);

    area=(r*r*3.14);
    printf("area of circle:%f",area);

    return 0;


}
